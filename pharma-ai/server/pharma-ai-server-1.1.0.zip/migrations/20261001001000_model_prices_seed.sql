insert into public.model_prices
  (provider, model_id, display_name, tier, classifier, input_per_mtok, output_per_mtok, valid_from, valid_to, is_example, notes)
values
  ('anthropic', 'claude-haiku-4-5-20251001', 'Claude Haiku 4.5', 'economy', true, 1.00, 5.00, null, null, true, 'Economy + classifier'),
  ('anthropic', 'claude-sonnet-5-5', 'Claude Sonnet 5.5', 'standard', false, 2.00, 10.00, null, null, true, 'Standard'),
  ('anthropic', 'claude-opus-5-5', 'Claude Opus 5.5', 'premium', false, 4.00, 20.00, null, null, true, 'Premium'),
  ('anthropic', 'claude-fable-5-1', 'Claude Fable 5.1', 'premium', false, 10.00, 50.00, null, null, true, 'Premium (top)'),
  ('google', null, 'Gemini 3.5 Flash-Lite', 'economy', true, 0.30, 2.50, null, null, true, 'Economy + classifier; enter the model id at set-up'),
  ('google', null, 'Gemini 3.8 Flash', 'standard', false, 0.75, 3.75, null, '2026-12-31', true, 'Standard; price until 31 Dec 2026; enter the model id at set-up'),
  ('google', null, 'Gemini 3.8 Flash', 'standard', false, 1.50, 7.50, '2027-01-01', null, true, 'Standard; price from 1 Jan 2027; enter the model id at set-up'),
  ('google', null, 'Gemini 3.1 Pro (preview)', 'premium', false, 2.00, 12.00, null, null, true, 'Premium; enter the model id at set-up'),
  ('openai', null, 'GPT-5.6 Luna', 'economy', true, 0.20, 1.20, null, null, true, 'Economy + classifier; enter the model id at set-up'),
  ('openai', null, 'GPT-5.6 Sol', 'premium', false, 5.00, 30.00, null, null, true, 'Premium; enter the model id at set-up'),
  ('openai', null, 'GPT-6 Astra', 'premium', false, null, null, null, null, true, 'Premium; enter the model id and the current price at set-up')
on conflict do nothing;
insert into public.notification_rules (type, label, enabled, locked)
values
  ('upload', 'New upload', true, true),
  ('level2_used', 'Level-2 password used', true, true),
  ('level2_locked', 'Uploads locked after wrong Level-2 passwords', true, false),
  ('account_locked', 'Account locked after wrong passwords', true, false),
  ('failed_logins', 'Burst of failed sign-ins', true, false),
  ('blocked_prompts', 'Burst of blocked questions', true, false),
  ('budget_80', 'Budget 80% reached', true, false),
  ('budget_100', 'Budget 100% reached', true, false),
  ('provider_error', 'Repeated AI provider or key errors', true, false),
  ('licence', 'Licence warnings', true, false),
  ('seat', 'PC seat warnings', true, false),
  ('new_version', 'New app version', true, false),
  ('deletion', 'Records deleted', true, false),
  ('recovery_used', 'Recovery code used', true, false)
on conflict (type) do nothing;
