create function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1
    from public.profiles p
    where p.id = auth.uid()
      and p.role in ('admin', 'backup_admin')
      and p.status = 'active'
  );
$$;
create function public.my_domain()
returns text
language sql
stable
security definer
set search_path = ''
as $$
  select p.domain_id
  from public.profiles p
  where p.id = auth.uid()
    and p.status = 'active';
$$;
create function public.realtime_topic_allowed(p_topic text)
returns boolean
language sql
stable
set search_path = ''
as $$
  select coalesce(
    p_topic = 'tenant:branding'
    or p_topic = 'user:' || auth.uid()::text
    or (auth.jwt() ->> 'device_id' is not null and p_topic = 'device:' || (auth.jwt() ->> 'device_id'))
    or (p_topic = 'admin:notifications' and public.is_admin()),
    false
  );
$$;

revoke execute on function public.is_admin() from public, anon, authenticated, service_role;
revoke execute on function public.my_domain() from public, anon, authenticated, service_role;
revoke execute on function public.realtime_topic_allowed(text) from public, anon, authenticated, service_role;
grant execute on function public.is_admin() to authenticated;
grant execute on function public.my_domain() to authenticated;
grant execute on function public.realtime_topic_allowed(text) to authenticated;
revoke all on all tables in schema public from anon, authenticated;
revoke all on all tables in schema private from public, anon, authenticated;

grant select on
  public.branding, public.tenant_settings, public.domains, public.domain_policies, public.profiles,
  public.ai_providers, public.ai_routes, public.model_prices, public.budgets, public.usage_daily,
  public.notifications, public.notification_rules, public.legal_holds, public.devices,
  public.force_logout, public.notices,
  public.login_events, public.prompt_log, public.prompt_result, public.answer_store,
  public.upload_log, public.export_log, public.admin_actions, public.deletion_log
to authenticated;
alter default privileges for role postgres in schema public revoke all on tables from anon, authenticated;
alter default privileges for role postgres in schema public revoke all on sequences from anon, authenticated;
alter default privileges for role postgres in schema public revoke all on functions from anon, authenticated;
revoke update, delete, truncate on
  public.login_events, public.prompt_log, public.prompt_result, public.upload_log,
  public.export_log, public.admin_actions, public.deletion_log
from service_role;
do $$
declare
  r record;
begin
  for r in
    select n.nspname, c.relname
    from pg_class c
    join pg_namespace n on n.oid = c.relnamespace
    where n.nspname in ('public', 'private') and c.relkind in ('r', 'p')
  loop
    execute format('alter table %I.%I enable row level security', r.nspname, r.relname);
  end loop;
end;
$$;
create policy branding_select on public.branding
  for select to authenticated using (true);

create policy domains_select on public.domains
  for select to authenticated using (true);

create policy domain_policies_select on public.domain_policies
  for select to authenticated using (active or (select public.is_admin()));
create policy profiles_select on public.profiles
  for select to authenticated using (id = (select auth.uid()) or (select public.is_admin()));
do $$
declare
  t text;
begin
  foreach t in array array['tenant_settings', 'ai_providers', 'ai_routes', 'model_prices', 'budgets',
                           'usage_daily', 'answer_store', 'notifications', 'notification_rules',
                           'legal_holds', 'devices', 'admin_actions', 'deletion_log']
  loop
    execute format(
      'create policy %I on public.%I for select to authenticated using ((select public.is_admin()))',
      t || '_select_admin', t);
  end loop;
end;
$$;
do $$
declare
  t text;
begin
  foreach t in array array['login_events', 'prompt_log', 'prompt_result', 'upload_log', 'export_log']
  loop
    execute format(
      'create policy %I on public.%I for select to authenticated '
      'using (user_id = (select auth.uid()) or (select public.is_admin()))',
      t || '_select_own', t);
  end loop;
end;
$$;
create policy force_logout_select on public.force_logout
  for select to authenticated using (
    target_user_id = (select auth.uid())
    or target_device_id = (select auth.jwt() ->> 'device_id')
    or (select public.is_admin())
  );
create policy notices_select on public.notices
  for select to authenticated using (
    (select public.is_admin())
    or (
      (domain_id is null or domain_id = (select public.my_domain()))
      and (expires_at is null or expires_at > now())
    )
  );
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values
  ('uploads', 'uploads', false, 20971520, array[
    'application/pdf',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    'text/plain', 'text/csv', 'image/png', 'image/jpeg'
  ]),
  ('branding', 'branding', true, 2097152, array['image/png'])
on conflict (id) do update set
  public = excluded.public,
  file_size_limit = excluded.file_size_limit,
  allowed_mime_types = excluded.allowed_mime_types;
create policy pharmaai_uploads_select on storage.objects
  for select to authenticated using (
    bucket_id = 'uploads'
    and (
      (storage.foldername(name))[1] = (select auth.uid())::text
      or (select public.is_admin())
    )
  );
create policy pharmaai_realtime_receive on realtime.messages
  for select to authenticated using ((select public.realtime_topic_allowed((select realtime.topic()))));

do $$
begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'notifications'
  ) then
    alter publication supabase_realtime add table public.notifications;
  end if;
end;
$$;
