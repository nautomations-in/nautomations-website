create function private.configure_server(
  p_public_backend_url text,
  p_functions_base_url text,
  p_licence_service_url text,
  p_setup_secret_sha256 text,
  p_cron_secret text,
  p_client_slug text,
  p_server_version text)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  c_https_origin constant text :=
    '^https://(\[[0-9a-f:.]+\]|[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?(\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)*)(:[1-9][0-9]{0,4})?$';
  v_completed_at timestamptz;
  v_port integer;
  r record;
begin
  select s.setup_completed_at into v_completed_at from public.tenant_settings s where s.id for update;
  if not found then
    raise exception 'The server settings row is missing' using errcode = 'P0002';
  end if;
  if v_completed_at is not null then
    raise exception 'setup is finished' using errcode = '22023';
  end if;

  for r in
    select t.label, t.url, t.kong_allowed
    from (values ('public backend URL', p_public_backend_url, false),
                 ('functions base URL', p_functions_base_url, true),
                 ('licence service URL', p_licence_service_url, false)) as t (label, url, kong_allowed)
  loop
    continue when r.kong_allowed and r.url = 'http://kong:8000';
    if r.url is null or char_length(r.url) > 2048 or r.url !~ c_https_origin then
      raise exception 'The % must be an https origin (no path, no trailing slash)', r.label using errcode = '22023';
    end if;
    v_port := substring(r.url from ':([0-9]+)$')::integer;
    if v_port is not null and (v_port > 65535 or v_port = 443) then
      raise exception 'The % has an invalid or default port', r.label using errcode = '22023';
    end if;
  end loop;

  if p_setup_secret_sha256 is null or p_setup_secret_sha256 !~ '^[0-9A-Fa-f]{64}$' then
    raise exception 'The setup secret hash must be a SHA-256 in hex (64 characters)' using errcode = '22023';
  end if;
  if p_cron_secret is null or p_cron_secret !~ '^[A-Za-z0-9_-]{42}[AEIMQUYcgkosw048]$' then
    raise exception 'The cron secret must be 32 bytes in base64url (43 characters)' using errcode = '22023';
  end if;
  if p_client_slug is null or p_client_slug !~ '^[a-z0-9][a-z0-9-]{1,39}$' then
    raise exception 'The client slug must be 2 - 40 lowercase letters, digits or hyphens' using errcode = '22023';
  end if;
  if p_server_version is null
     or p_server_version !~ '^[0-9]{1,5}\.[0-9]{1,5}\.[0-9]{1,5}([-+][0-9A-Za-z.-]{1,40})?$' then
    raise exception 'The server version must follow the app version rule (for example 1.1.0)' using errcode = '22023';
  end if;

  insert into private.config (key, value) values
    ('public_backend_url', p_public_backend_url),
    ('functions_base_url', p_functions_base_url),
    ('licence_service_url', p_licence_service_url),
    ('setup_secret_sha256', lower(p_setup_secret_sha256))
  on conflict (key) do update set value = excluded.value;
  perform pg_advisory_xact_lock(hashtext('pharmaai_cron_secret'));
  if not exists (select 1 from vault.secrets s where s.name = 'pharmaai_cron_secret') then
    perform vault.create_secret(p_cron_secret, 'pharmaai_cron_secret', 'Pharma AI scheduled jobs (x-pharmaai-cron-secret)');
  end if;

  update public.tenant_settings s
  set client_slug = p_client_slug, server_version = p_server_version, updated_at = now()
  where s.id;
end;
$$;

comment on function private.configure_server(text, text, text, text, text, text, text) is
  'Setup wizard database step (00-interfaces 5.3): stores public_backend_url, functions_base_url, '
  'licence_service_url and setup_secret_sha256 in private.config, creates the Vault cron secret only when missing, '
  'sets client_slug and server_version. 22023 for any invalid input and "setup is finished" once setup_completed_at '
  'is set. postgres only (Management API database/query, self-hosted /pg/query).';
create function private.set_server_version(p_version text)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  if p_version is null or p_version !~ '^[0-9]{1,5}\.[0-9]{1,5}\.[0-9]{1,5}([-+][0-9A-Za-z.-]{1,40})?$' then
    raise exception 'The server version must follow the app version rule (for example 1.1.0)' using errcode = '22023';
  end if;
  update public.tenant_settings s set server_version = p_version, updated_at = now() where s.id;
  if not found then
    raise exception 'The server settings row is missing' using errcode = 'P0002';
  end if;
end;
$$;

comment on function private.set_server_version(text) is
  'Company-server update mode (00-interfaces 7.9): sets tenant_settings.server_version (APP_VERSION rule, 22023 '
  'otherwise). postgres only.';
create function private.setup_secret_matches(p_secret text)
returns boolean
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
  v_hash text;
begin
  if p_secret is null or p_secret = '' or char_length(p_secret) > 512 then
    return false;
  end if;
  if exists (select 1 from public.tenant_settings s where s.setup_completed_at is not null) then
    return false;
  end if;
  select c.value into v_hash from private.config c where c.key = 'setup_secret_sha256';
  if v_hash is null then
    return false;
  end if;
  return encode(extensions.digest(p_secret, 'sha256'), 'hex') = v_hash;
end;
$$;

comment on function private.setup_secret_matches(text) is
  'setup-company x-pharmaai-setup-secret check: true when the SHA-256 of the value equals private.config '
  'setup_secret_sha256 and setup has not finished; false otherwise. Edge Functions only.';
create function private.finish_setup()
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  update public.tenant_settings s
  set setup_completed_at = coalesce(s.setup_completed_at, now()), updated_at = now()
  where s.id;
  if not found then
    raise exception 'The server settings row is missing' using errcode = 'P0002';
  end if;
  delete from private.config where key = 'setup_secret_sha256';
end;
$$;

comment on function private.finish_setup() is
  'Ends the setup (setup-company installLicence): sets tenant_settings.setup_completed_at once and deletes '
  'private.config setup_secret_sha256. Edge Functions only.';
create function private.pc_connection_code_rotate(p_admin_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_secret text := translate(rtrim(encode(extensions.gen_random_bytes(32), 'base64'), '='), '+/', '-_');
  v_created_at bigint := floor(extract(epoch from now()))::bigint;
  v_id uuid;
begin
  perform pg_advisory_xact_lock(hashtext('pharmaai_pc_connection_secret'));
  select s.id into v_id from vault.secrets s where s.name = 'pharmaai_pc_connection_secret';
  if v_id is null then
    perform vault.create_secret(v_secret, 'pharmaai_pc_connection_secret', 'Pharma AI PC connection secret');
  else
    perform vault.update_secret(v_id, v_secret, 'pharmaai_pc_connection_secret', 'Pharma AI PC connection secret');
  end if;

  insert into private.config (key, value) values ('pc_connection_code_created_at', v_created_at::text)
  on conflict (key) do update set value = excluded.value;

  insert into public.admin_actions (admin_id, action, target_type, target_id, details)
  values (p_admin_id, 'licence.rotate_connection_code', 'licence', null, jsonb_build_object('createdAt', v_created_at));

  return jsonb_build_object('secret', v_secret, 'createdAt', v_created_at);
end;
$$;

comment on function private.pc_connection_code_rotate(uuid) is
  'New PC connection secret (32 random bytes, base64url) in Vault pharmaai_pc_connection_secret (updated in place), '
  'its time in private.config pc_connection_code_created_at, audited as licence.rotate_connection_code (admin null '
  'during setup). Returns { secret, createdAt } (Unix seconds). Edge Functions only (admin-licence, setup-company).';
create function private.pc_connection_code_current()
returns jsonb
language sql
stable
security definer
set search_path = ''
as $$
  select case when v.secret is null or v.created_at is null then null
              else jsonb_build_object('secret', v.secret, 'createdAt', v.created_at::bigint) end
  from (select (select s.decrypted_secret from vault.decrypted_secrets s
                where s.name = 'pharmaai_pc_connection_secret') as secret,
               (select c.value from private.config c where c.key = 'pc_connection_code_created_at') as created_at) v;
$$;

comment on function private.pc_connection_code_current() is
  'The current PC connection secret { secret, createdAt } (Unix seconds) or null. Edge Functions only '
  '(admin-licence connectionCodeShow, register-device).';
revoke execute on function private.configure_server(text, text, text, text, text, text, text)
  from public, anon, authenticated, service_role;
revoke execute on function private.set_server_version(text) from public, anon, authenticated, service_role;
revoke execute on function private.setup_secret_matches(text) from public, anon, authenticated, service_role;
revoke execute on function private.finish_setup() from public, anon, authenticated, service_role;
revoke execute on function private.pc_connection_code_rotate(uuid) from public, anon, authenticated, service_role;
revoke execute on function private.pc_connection_code_current() from public, anon, authenticated, service_role;
grant execute on function private.configure_server(text, text, text, text, text, text, text) to postgres;
grant execute on function private.set_server_version(text) to postgres;
grant execute on function private.setup_secret_matches(text) to service_role;
grant execute on function private.finish_setup() to service_role;
grant execute on function private.pc_connection_code_rotate(uuid) to service_role;
grant execute on function private.pc_connection_code_current() to service_role;
