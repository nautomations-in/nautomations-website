insert into public.tenant_settings (
  id, client_slug, timezone, answer_retention_days, log_retention_days, upload_max_mb, allowed_types,
  idle_timeout_min, session_max_hours, lockout_threshold, allow_copy, admin_approved_pcs_only,
  update_policy, catalogue_version, seat_plan, usd_inr_rate, employee_notice_text
)
values (
  true, 'test-client', 'Asia/Kolkata', 0, 1095, 20,
  array['pdf', 'docx', 'xlsx', 'pptx', 'txt', 'csv', 'png', 'jpg'],
  15, 12, 5, true, false,
  'admin_approved', '1.0.0', 'per_pc', 88,
  $notice$[Company] provides this AI assistant for work in your department. Your sign-ins, questions and uploaded files are recorded in [Company]’s own systems for security, quality and audit purposes and are visible to the system administrators. AI answers are not stored. Do not enter personal data of others unless your work requires it. Questions: [company privacy contact].$notice$
)
on conflict (id) do nothing;

insert into public.branding (id, company_name, app_display_name, logo_path, logo_version)
values (true, 'N Automations — Test Client', 'Pharma AI', null, 0)
on conflict (id) do nothing;
select cron.schedule('pharmaai-nightly-purge', '30 20 * * *', $$select private.invoke_edge_function('purge')$$);
select cron.schedule('pharmaai-daily-usage-report', '30 0 * * *', $$select private.invoke_edge_function('usage-report')$$);
