create or replace function private.upload_ticket_check(p_token_sha256 text, p_user_id uuid, p_device_id text)
returns jsonb
language sql
stable
set search_path = ''
as $$
  select jsonb_build_object(
    'id', t.id,
    'expires_at', extract(epoch from t.expires_at)::bigint,
    'prepared', t.prepared_at is not null,
    'upload_id', t.upload_id,
    'storage_path', t.storage_path,
    'file_name', t.file_name,
    'mime_type', t.mime_type,
    'size_bytes', t.size_bytes,
    'sha256', t.sha256
  )
  from private.upload_tickets t
  where t.token_sha256 = p_token_sha256
    and t.user_id = p_user_id
    and t.device_id = p_device_id
    and t.used_at is null
    and t.expires_at > now()
    and not exists (select 1 from private.level2_secrets s where s.user_id = t.user_id and s.locked);
$$;

create or replace function private.upload_ticket_prepare(
  p_token_sha256 text,
  p_user_id uuid,
  p_device_id text,
  p_upload_id uuid,
  p_storage_path text,
  p_file_name text,
  p_mime_type text,
  p_size_bytes bigint,
  p_sha256 text
)
returns boolean
language plpgsql
set search_path = ''
as $$
begin
  update private.upload_tickets t
  set prepared_at = now(), upload_id = p_upload_id, storage_path = p_storage_path, file_name = p_file_name,
      mime_type = p_mime_type, size_bytes = p_size_bytes, sha256 = p_sha256
  where t.token_sha256 = p_token_sha256
    and t.user_id = p_user_id
    and t.device_id = p_device_id
    and t.used_at is null
    and t.prepared_at is null
    and t.expires_at > now()
    and not exists (select 1 from private.level2_secrets s where s.user_id = t.user_id and s.locked);
  return found;
end;
$$;

create or replace function private.upload_ticket_consume(
  p_token_sha256 text,
  p_user_id uuid,
  p_device_id text,
  p_upload_id uuid
)
returns boolean
language plpgsql
set search_path = ''
as $$
begin
  update private.upload_tickets t
  set used_at = now()
  where t.token_sha256 = p_token_sha256
    and t.user_id = p_user_id
    and t.device_id = p_device_id
    and t.upload_id = p_upload_id
    and t.prepared_at is not null
    and t.used_at is null
    and not exists (select 1 from private.level2_secrets s where s.user_id = t.user_id and s.locked);
  return found;
end;
$$;
create function private.upload_orphans(p_limit integer default 20)
returns table (ticket_id uuid, storage_path text)
language sql
stable
set search_path = ''
as $$
  select t.id, t.storage_path
  from private.upload_tickets t
  where t.prepared_at is not null
    and t.created_at < now() - interval '3 hours'
    and not exists (select 1 from public.upload_log u where u.storage_path = t.storage_path)
  order by t.created_at
  limit greatest(1, least(coalesce(p_limit, 20), 100));
$$;
create function private.upload_orphans_forget(p_ticket_ids uuid[])
returns integer
language plpgsql
set search_path = ''
as $$
declare
  v_count integer;
begin
  delete from private.upload_tickets t
  where t.id = any(p_ticket_ids)
    and t.prepared_at is not null
    and t.created_at < now() - interval '3 hours'
    and not exists (select 1 from public.upload_log u where u.storage_path = t.storage_path);
  get diagnostics v_count = row_count;
  return v_count;
end;
$$;

comment on function private.upload_orphans(integer) is
  'Unconfirmed upload objects (prepared ticket, no upload_log row, older than 3 hours). Edge Functions only.';
comment on function private.upload_orphans_forget(uuid[]) is
  'Drops orphan upload tickets after their objects were removed through the Storage API. Edge Functions only.';

revoke execute on function private.upload_orphans(integer) from public, anon, authenticated, service_role;
revoke execute on function private.upload_orphans_forget(uuid[]) from public, anon, authenticated, service_role;
grant execute on function private.upload_orphans(integer) to service_role;
grant execute on function private.upload_orphans_forget(uuid[]) to service_role;
create or replace function private.cleanup_expired()
returns jsonb
language plpgsql
set search_path = ''
as $$
declare
  v_tickets integer;
  v_changes integer;
  v_uploads integer;
  v_nonces integer;
  v_rates integer;
  v_sessions integer;
  v_answers integer;
  v_hours integer;
begin
  delete from private.login_tickets t where t.created_at < now() - interval '1 day';
  get diagnostics v_tickets = row_count;
  delete from private.change_tickets t where t.created_at < now() - interval '1 day';
  get diagnostics v_changes = row_count;
  delete from private.upload_tickets t
  where t.created_at < now() - interval '1 day'
    and (t.prepared_at is null
         or exists (select 1 from public.upload_log u where u.storage_path = t.storage_path));
  get diagnostics v_uploads = row_count;
  delete from private.used_nonces n where n.created_at < now() - interval '1 hour';
  get diagnostics v_nonces = row_count;
  delete from private.rate_limits r where r.window_start < now() - interval '1 day';
  get diagnostics v_rates = row_count;
  select s.session_max_hours + 12 into v_hours from public.tenant_settings s;
  delete from private.session_devices d
  where d.created_at < now() - make_interval(hours => coalesce(v_hours, 24));
  get diagnostics v_sessions = row_count;

  delete from public.answer_store a where a.expires_at < now();
  get diagnostics v_answers = row_count;
  if v_answers > 0 then
    insert into public.deletion_log (admin_id, table_name, filter, record_count, reason)
    values (null, 'answer_store', jsonb_build_object('expired_before', now()), v_answers,
            'Answer retention period ended');
  end if;

  return jsonb_build_object(
    'login_tickets', v_tickets, 'change_tickets', v_changes, 'upload_tickets', v_uploads,
    'used_nonces', v_nonces, 'rate_limits', v_rates, 'session_devices', v_sessions, 'answer_store', v_answers
  );
end;
$$;
create or replace function private.notify_upload()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_domain text;
  v_user text;
  v_pc text;
begin
  select d.name into v_domain from public.domains d where d.id = new.domain_id;
  select coalesce(p.display_name, p.username) into v_user from public.profiles p where p.id = new.user_id;
  select coalesce(nullif(btrim(v.device_name), ''), v.device_id) into v_pc
  from public.devices v where v.device_id = new.device_id;

  insert into public.notifications (type, title, body, ref_table, ref_id)
  values (
    'upload',
    left(case when v_domain is null then 'New upload' else 'New upload in ' || v_domain end, 200),
    left(format('%s uploaded "%s" (%s, %s bytes) on PC %s. SHA-256: %s. Reason: %s. Description: %s',
                coalesce(v_user, 'A user'), new.file_name, new.mime_type, new.size_bytes,
                coalesce(v_pc, new.device_id, 'unknown'), new.sha256, new.reason, new.description), 2000),
    'upload_log',
    new.id::text
  );
  return new;
end;
$$;
