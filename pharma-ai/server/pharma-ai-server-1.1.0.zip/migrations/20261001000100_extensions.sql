create schema if not exists extensions;

create extension if not exists pgcrypto with schema extensions;
create extension if not exists pg_cron with schema pg_catalog;
grant usage on schema cron to postgres;
grant all privileges on all tables in schema cron to postgres;
create extension if not exists pg_net with schema extensions;
create extension if not exists pgtap with schema extensions;
create extension if not exists supabase_vault with schema vault;
