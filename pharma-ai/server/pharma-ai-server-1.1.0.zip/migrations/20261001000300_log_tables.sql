create table public.login_events (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles (id),
  username_attempted text check (username_attempted is null or char_length(username_attempted) <= 64),
  domain_id text references public.domains (id),
  event text not null check (event in (
    'success', 'fail', 'locked', 'refused', 'logout', 'timeout', 'forced_logout', 'recovery_used',
    'level2_success', 'level2_fail', 'level2_locked'
  )),
  device_id text check (device_id is null or device_id ~ '^[0-9a-f]{32}$'),
  device_name text check (device_name is null or char_length(device_name) <= 120),
  app_version text check (app_version is null or char_length(app_version) <= 40),
  created_at timestamptz not null default now()
);

create index login_events_user_created_idx on public.login_events (user_id, created_at desc);
create index login_events_created_at_idx on public.login_events (created_at);
create index login_events_domain_id_idx on public.login_events (domain_id);

create table public.prompt_log (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles (id),
  role text not null check (role in ('user', 'admin', 'backup_admin')),
  domain_id text references public.domains (id),
  session_id text check (session_id is null or session_id ~ '^[A-Za-z0-9_-]{1,64}$'),
  conversation_id text check (conversation_id is null or conversation_id ~ '^[A-Za-z0-9_-]{1,64}$'),
  prompt_text text not null,
  prompt_chars integer not null default 0 check (prompt_chars >= 0),
  upload_ids uuid[] not null default '{}',
  decision text not null check (decision in ('allowed', 'blocked', 'clarify')),
  decision_stage text check (decision_stage is null or decision_stage in ('licence', 'rate', 'limit', 'rules', 'classifier')),
  decision_reason text,
  policy_version text,
  catalogue_version text,
  provider text,
  model text,
  device_id text check (device_id is null or device_id ~ '^[0-9a-f]{32}$'),
  created_at timestamptz not null default now()
);

create index prompt_log_user_created_idx on public.prompt_log (user_id, created_at desc);
create index prompt_log_user_conversation_idx on public.prompt_log (user_id, conversation_id);
create index prompt_log_created_at_idx on public.prompt_log (created_at);
create index prompt_log_domain_created_idx on public.prompt_log (domain_id, created_at);

create table public.prompt_result (
  prompt_id uuid primary key references public.prompt_log (id),
  user_id uuid not null references public.profiles (id),
  input_tokens integer not null default 0 check (input_tokens >= 0),
  cached_tokens integer not null default 0 check (cached_tokens >= 0),
  output_tokens integer not null default 0 check (output_tokens >= 0),
  est_cost numeric(14, 6) not null default 0 check (est_cost >= 0),
  answer_sha256 text check (answer_sha256 is null or answer_sha256 ~ '^[0-9a-f]{64}$'),
  answer_chars integer not null default 0 check (answer_chars >= 0),
  latency_ms integer check (latency_ms is null or latency_ms >= 0),
  status text not null check (status in ('ok', 'stopped', 'error', 'filtered')),
  created_at timestamptz not null default now()
);

create index prompt_result_user_created_idx on public.prompt_result (user_id, created_at desc);
create index prompt_result_created_at_idx on public.prompt_result (created_at);
create index prompt_result_answer_sha256_idx on public.prompt_result (user_id, answer_sha256);

create table public.answer_store (
  prompt_id uuid primary key references public.prompt_log (id),
  answer_text text not null,
  created_at timestamptz not null default now(),
  expires_at timestamptz not null
);

create index answer_store_expires_at_idx on public.answer_store (expires_at);

comment on table public.answer_store is
  'Answer text, only when tenant_settings.answer_retention_days > 0 (AUD-02). Removed after expires_at by private.cleanup_expired().';

create table public.upload_log (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles (id),
  domain_id text references public.domains (id),
  file_name text not null check (char_length(file_name) between 1 and 255),
  mime_type text not null check (char_length(mime_type) between 1 and 200),
  size_bytes bigint not null check (size_bytes > 0),
  sha256 text not null check (sha256 ~ '^[0-9a-f]{64}$'),
  storage_path text not null unique check (char_length(storage_path) between 1 and 1024),
  reason text not null check (char_length(btrim(reason)) between 1 and 200),
  description text not null check (char_length(btrim(description)) between 1 and 200),
  device_id text check (device_id is null or device_id ~ '^[0-9a-f]{32}$'),
  created_at timestamptz not null default now()
);

create index upload_log_user_created_idx on public.upload_log (user_id, created_at desc);
create index upload_log_created_at_idx on public.upload_log (created_at);
create index upload_log_domain_created_idx on public.upload_log (domain_id, created_at);

create table public.export_log (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles (id),
  domain_id text references public.domains (id),
  prompt_id uuid,
  export_type text not null check (export_type in (
    'docx', 'xlsx', 'pptx', 'pdf', 'png', 'svg', 'jpg', 'eml', 'txt', 'csv'
  )),
  file_name text not null check (char_length(file_name) between 1 and 255),
  sha256 text not null check (sha256 ~ '^[0-9a-f]{64}$'),
  device_id text check (device_id is null or device_id ~ '^[0-9a-f]{32}$'),
  created_at timestamptz not null default now()
);

create index export_log_user_created_idx on public.export_log (user_id, created_at desc);
create index export_log_created_at_idx on public.export_log (created_at);
create index export_log_domain_created_idx on public.export_log (domain_id, created_at);
create index export_log_prompt_id_idx on public.export_log (prompt_id);

create table public.admin_actions (
  id uuid primary key default gen_random_uuid(),
  admin_id uuid references public.profiles (id),
  action text not null check (char_length(action) between 1 and 80),
  target_type text,
  target_id text,
  details jsonb not null default '{}'::jsonb check (jsonb_typeof(details) = 'object'),
  reason text,
  created_at timestamptz not null default now()
);

create index admin_actions_admin_created_idx on public.admin_actions (admin_id, created_at desc);
create index admin_actions_created_at_idx on public.admin_actions (created_at);

comment on column public.admin_actions.details is 'Never contains secrets, passwords or keys.';

create table public.deletion_log (
  id uuid primary key default gen_random_uuid(),
  admin_id uuid references public.profiles (id),
  table_name text not null,
  filter jsonb not null,
  record_count integer not null check (record_count >= 0),
  reason text not null check (char_length(btrim(reason)) >= 3),
  created_at timestamptz not null default now()
);

create index deletion_log_admin_created_idx on public.deletion_log (admin_id, created_at desc);
create index deletion_log_created_at_idx on public.deletion_log (created_at);
create schema if not exists private;
create function private.log_set_created_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.created_at := now();
  return new;
end;
$$;
create function private.log_guard_purgeable()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  if tg_op = 'DELETE' and coalesce(current_setting('pharmaai.purge', true), '') = 'on' then
    return old;
  end if;
  raise exception 'Log table %.% is append-only (% refused)', tg_table_schema, tg_table_name, tg_op
    using errcode = '42501', hint = 'Records are deleted only through admin_purge() with a reason.';
end;
$$;
create function private.log_guard_permanent()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  raise exception 'Log table %.% is permanent (% refused)', tg_table_schema, tg_table_name, tg_op
    using errcode = '42501';
end;
$$;
create function private.log_guard_truncate()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  raise exception 'Log table %.% cannot be truncated', tg_table_schema, tg_table_name
    using errcode = '42501';
end;
$$;

do $$
declare
  t text;
begin
  foreach t in array array['login_events', 'prompt_log', 'prompt_result', 'upload_log', 'export_log',
                           'admin_actions', 'deletion_log']
  loop
    execute format(
      'create trigger %I before insert on public.%I for each row execute function private.log_set_created_at()',
      t || '_set_created_at', t);
    execute format(
      'create trigger %I before truncate on public.%I for each statement execute function private.log_guard_truncate()',
      t || '_no_truncate', t);
  end loop;

  foreach t in array array['login_events', 'prompt_log', 'prompt_result', 'upload_log', 'export_log']
  loop
    execute format(
      'create trigger %I before update or delete on public.%I for each row execute function private.log_guard_purgeable()',
      t || '_append_only', t);
  end loop;

  foreach t in array array['admin_actions', 'deletion_log']
  loop
    execute format(
      'create trigger %I before update or delete on public.%I for each row execute function private.log_guard_permanent()',
      t || '_permanent', t);
  end loop;
end;
$$;
create function private.prompt_result_set_user()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  select p.user_id into new.user_id from public.prompt_log p where p.id = new.prompt_id;
  if new.user_id is null then
    raise exception 'Unknown prompt %', new.prompt_id using errcode = '23503';
  end if;
  return new;
end;
$$;

create trigger prompt_result_set_user
  before insert on public.prompt_result
  for each row execute function private.prompt_result_set_user();
