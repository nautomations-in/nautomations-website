alter table public.tenant_settings
  add column licence_type text check (licence_type is null or licence_type in ('trial', 'one_year', 'lifetime')),
  add column licence_certificate text check (
    licence_certificate is null
    or (char_length(licence_certificate) <= 8192 and licence_certificate ~ '^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$')),
  add column server_version text check (
    server_version is null or server_version ~ '^[0-9]{1,5}\.[0-9]{1,5}\.[0-9]{1,5}([-+][0-9A-Za-z.-]{1,40})?$'),
  add column setup_completed_at timestamptz;
alter table public.tenant_settings drop constraint tenant_settings_licence_status_check;
update public.tenant_settings set licence_status = 'ended' where licence_status = 'revoked';
alter table public.tenant_settings
  add constraint tenant_settings_licence_status_check
  check (licence_status is null or licence_status in ('active', 'paused', 'ended'));

alter table public.tenant_settings drop column seat_plan;

comment on column public.tenant_settings.licence_token is
  'Verified tenant licence token v2 (PAI-LIC-2, 00-interfaces 1). Replaced only by a verified token of the same '
  'licence and backend with a later issuedAt (setup-company installLicence, usage-report, admin-licence refresh).';
comment on column public.tenant_settings.licence_type is
  'Licence type of the stored licence token v2 (trial / one_year / lifetime), written with every newer token.';
comment on column public.tenant_settings.licence_status is
  'Licence status from the stored token / certificate (active / paused / ended), written with every newer '
  'certificate; the check of the Edge Functions evaluates the verified certificate itself.';
comment on column public.tenant_settings.licence_certificate is
  'Licence status certificate (PAI-LSC-1, 00-interfaces 2): signed by the Licence Service with every daily report, '
  'valid for 30 days; replaced only by a verified certificate of the same licence and backend with a later issuedAt.';
comment on column public.tenant_settings.server_version is
  'Pharma AI version of this company server (APP_VERSION rule), set by private.configure_server / '
  'set_server_version; sent as appVersion in the daily report.';
comment on column public.tenant_settings.setup_completed_at is
  'When the setup wizard finished (private.finish_setup); from then on setup-company answers SETUP_DONE.';
alter table public.devices
  add column device_public_key text check (
    device_public_key is null or device_public_key ~ '^[A-Za-z0-9_-]{42}[AEIMQUYcgkosw048]$'),
  add column registered_at timestamptz,
  drop column seat_expires_at,
  drop column seat_floor_at;

comment on column public.devices.device_public_key is
  'Ed25519 public key of the PC (register-device with the PC connection code, or setup-company for the Admin''s '
  'PC). A PC without a key is not registered: the device check answers DEVICE_NOT_REGISTERED.';
comment on column public.devices.registered_at is
  'When the PC was last registered with its device key (register-device / setup-company).';
comment on column public.devices.released_at is
  'Set by admin-licence releasePc, cleared only by allowPc (D3). While set, register-device, auth-login and the '
  'device check of ai-chat, verify-level2 and register-upload refuse the PC (DEVICE_RELEASED).';
alter table public.profiles drop column user_seat_token;
drop table public.offline_seat_requests;
drop function private.usage_report_counts(date);
create table private.account_status_history (
  id bigint generated always as identity primary key,
  user_id uuid not null,
  role text not null check (role in ('user', 'admin', 'backup_admin')),
  status text not null check (status in ('active', 'disabled', 'locked')),
  valid_from timestamptz not null,
  valid_to timestamptz,
  check (valid_to is null or valid_to >= valid_from)
);

create unique index account_status_history_open on private.account_status_history (user_id) where valid_to is null;
create index account_status_history_range on private.account_status_history (valid_from, valid_to);

comment on table private.account_status_history is
  'Role and status periods of every account (valid_to null = current), written only by the trigger '
  'private.track_account_status() on public.profiles; read by private.account_report_counts(date). No foreign key: '
  'rows outlive a deleted profile.';
alter table private.account_status_history enable row level security;
revoke all on table private.account_status_history from public, anon, authenticated, service_role;
revoke all on sequence private.account_status_history_id_seq from public, anon, authenticated, service_role;
create function private.track_account_status()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if tg_op = 'UPDATE' then
    if new.status is not distinct from old.status and new.role is not distinct from old.role
       and new.id is not distinct from old.id then
      return null;
    end if;
  end if;
  if tg_op in ('UPDATE', 'DELETE') then
    update private.account_status_history h
    set valid_to = now()
    where h.user_id = old.id and h.valid_to is null;
  end if;
  if tg_op in ('INSERT', 'UPDATE') then
    insert into private.account_status_history (user_id, role, status, valid_from)
    values (new.id, new.role, new.status, now());
  end if;
  return null;
end;
$$;

alter function private.track_account_status() owner to postgres;

comment on function private.track_account_status() is
  'Trigger on public.profiles: records every insert, status / role change and delete in '
  'private.account_status_history (00-interfaces 5.2). SECURITY DEFINER, owner postgres.';
create trigger profiles_track_account_status
  after insert or update of status, role or delete on public.profiles
  for each row execute function private.track_account_status();
insert into private.account_status_history (user_id, role, status, valid_from)
select p.id, p.role, p.status, least(p.created_at, now())
from public.profiles p;
create function private.account_report_counts(p_day date)
returns jsonb
language sql
stable
strict
security definer
set search_path = ''
as $$
  with bounds as (
    select p_day::timestamp at time zone 'Asia/Kolkata' as day_start,
           (p_day + 1)::timestamp at time zone 'Asia/Kolkata' as day_end
  ),
  overlapping as (
    select h.user_id, h.status
    from private.account_status_history h
    cross join bounds b
    where h.valid_from < b.day_end
      and (h.valid_to is null or h.valid_to > b.day_start)
      and (h.valid_to is null or h.valid_to > h.valid_from)
  )
  select jsonb_build_object(
    'activeAccounts', count(distinct o.user_id) filter (where o.status <> 'disabled'),
    'totalAccounts', count(distinct o.user_id),
    'disabledAccounts', count(distinct o.user_id) - count(distinct o.user_id) filter (where o.status <> 'disabled'))
  from overlapping o;
$$;

comment on function private.account_report_counts(date) is
  'Active user accounts of one IST day { activeAccounts, disabledAccounts, totalAccounts } (00-interfaces 5.2). '
  'Edge Functions only (usage-report v2).';
create function public.licence_active_accounts_today()
returns integer
language plpgsql
stable
security definer
set search_path = ''
as $$
begin
  if not public.is_admin() then
    raise exception 'Only an Administrator can do this' using errcode = '42501';
  end if;
  return (private.account_report_counts((now() at time zone 'Asia/Kolkata')::date) ->> 'activeAccounts')::int;
end;
$$;

comment on function public.licence_active_accounts_today() is
  'Active user accounts of today''s IST date so far (A2; admin-licence status returns the same figure). '
  'Administrators only (42501 otherwise).';

revoke execute on function private.track_account_status() from public, anon, authenticated, service_role;
revoke execute on function private.account_report_counts(date) from public, anon, authenticated, service_role;
revoke execute on function public.licence_active_accounts_today() from public, anon, authenticated, service_role;
grant execute on function private.account_report_counts(date) to service_role;
grant execute on function public.licence_active_accounts_today() to authenticated;
create function private.licence_config()
returns jsonb
language sql
stable
security definer
set search_path = ''
as $$
  select jsonb_build_object(
    'licenceServiceUrl', (select c.value from private.config c where c.key = 'licence_service_url'),
    'reportSecret', (select s.decrypted_secret from vault.decrypted_secrets s
                     where s.name = 'pharmaai_licence_report_secret'));
$$;

comment on function private.licence_config() is
  'Licence configuration { licenceServiceUrl, reportSecret } from private.config and Vault (nulls when missing). '
  'Edge Functions only (usage-report, admin-licence refresh).';
create function private.set_licence_report_secret(p_secret text)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_id uuid;
begin
  if p_secret is null or p_secret !~ '^[A-Za-z0-9_-]{42}[AEIMQUYcgkosw048]$' then
    raise exception 'The licence report secret must be 32 bytes in base64url (43 characters)' using errcode = '22023';
  end if;
  perform pg_advisory_xact_lock(hashtext('pharmaai_licence_report_secret'));
  select s.id into v_id from vault.secrets s where s.name = 'pharmaai_licence_report_secret';
  if v_id is null then
    perform vault.create_secret(p_secret, 'pharmaai_licence_report_secret', 'Pharma AI daily licence report secret');
  else
    perform vault.update_secret(v_id, p_secret, 'pharmaai_licence_report_secret', 'Pharma AI daily licence report secret');
  end if;
end;
$$;

comment on function private.set_licence_report_secret(text) is
  'Stores the licence report secret (32 bytes, canonical base64url) in Vault as pharmaai_licence_report_secret, '
  'created once and updated in place. Edge Functions only (setup-company installLicence).';
create function private.cron_secret_matches(p_secret text)
returns boolean
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
  v_secret text;
begin
  if p_secret is null or p_secret = '' or char_length(p_secret) > 512 then
    return false;
  end if;
  select s.decrypted_secret into v_secret from vault.decrypted_secrets s where s.name = 'pharmaai_cron_secret';
  if v_secret is null or v_secret = '' then
    return false;
  end if;
  return extensions.digest(p_secret, 'sha256') = extensions.digest(v_secret, 'sha256');
end;
$$;

comment on function private.cron_secret_matches(text) is
  'True when the value equals the Vault cron secret (pharmaai_cron_secret); false for null, empty, longer than 512 '
  'characters or no stored secret. Edge Functions only (usage-report, purge).';

revoke execute on function private.licence_config() from public, anon, authenticated, service_role;
revoke execute on function private.set_licence_report_secret(text) from public, anon, authenticated, service_role;
revoke execute on function private.cron_secret_matches(text) from public, anon, authenticated, service_role;
grant execute on function private.licence_config() to service_role;
grant execute on function private.set_licence_report_secret(text) to service_role;
grant execute on function private.cron_secret_matches(text) to service_role;
