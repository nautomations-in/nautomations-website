create table public.domains (
  id text primary key check (id ~ '^[A-Z][A-Z0-9_]{1,15}$'),
  name text not null,
  group_name text not null,
  enabled boolean not null default true,
  default_tier text not null check (default_tier in ('premium', 'standard', 'economy')),
  default_daily_tokens integer not null,
  max_output_tokens integer not null,
  file_max_output_tokens integer not null,
  temperature numeric(3, 2) not null,
  icon text not null,
  sort_order integer not null,
  policy_version text not null
);

comment on table public.domains is
  'The 19 standard domains. The Admin changes only "enabled" (through admin-settings).';

create table public.domain_policies (
  domain_id text not null references public.domains (id),
  version text not null,
  policy_json jsonb not null,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  primary key (domain_id, version)
);

comment on table public.domain_policies is
  'Domain Guard policy files (packages/domain-catalogue/domains/*.json). Read-only.';
create table public.ai_providers (
  id uuid primary key default gen_random_uuid(),
  provider text not null check (provider in ('anthropic', 'openai', 'google', 'azure_openai')),
  label text not null check (char_length(label) between 1 and 80),
  base_url text check (base_url is null or base_url ~ '^https://[^\s/]+(/[^\s]*)?$'),
  vault_secret_id uuid,
  key_last4 text check (key_last4 is null or char_length(key_last4) = 4),
  status text not null default 'untested'
    check (status in ('untested', 'active', 'error', 'revoked')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

comment on column public.ai_providers.vault_secret_id is
  'Id of the vault.secrets row that holds the API key. Only Edge Functions read the key.';

create table public.ai_routes (
  id uuid primary key default gen_random_uuid(),
  scope text not null check (scope in ('default', 'domain', 'user')),
  scope_id text,
  provider_id uuid not null references public.ai_providers (id),
  model text not null check (char_length(model) between 1 and 120),
  classifier_provider_id uuid references public.ai_providers (id),
  classifier_model text check (classifier_model is null or char_length(classifier_model) between 1 and 120),
  max_output_tokens integer check (max_output_tokens is null or max_output_tokens between 1 and 64000),
  temperature numeric(3, 2) check (temperature is null or temperature between 0 and 2),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint ai_routes_scope_id_check check ((scope = 'default') = (scope_id is null)),
  constraint ai_routes_classifier_pair_check
    check ((classifier_provider_id is null) = (classifier_model is null)),
  constraint ai_routes_scope_unique unique nulls not distinct (scope, scope_id)
);

create index ai_routes_provider_id_idx on public.ai_routes (provider_id);
create index ai_routes_classifier_provider_id_idx on public.ai_routes (classifier_provider_id);
create table public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  username text not null check (username ~ '^[a-z0-9][a-z0-9._-]{2,31}$'),
  display_name text not null check (char_length(display_name) between 1 and 80),
  role text not null check (role in ('user', 'admin', 'backup_admin')),
  domain_id text references public.domains (id),
  status text not null default 'active' check (status in ('active', 'disabled', 'locked')),
  failed_logins integer not null default 0 check (failed_logins >= 0),
  daily_token_limit integer check (daily_token_limit is null or daily_token_limit > 0),
  route_override_id uuid references public.ai_routes (id) on delete set null,
  user_seat_token text,
  notice_accepted_at timestamptz,
  eula_accepted_at timestamptz,
  created_by uuid references public.profiles (id),
  created_at timestamptz not null default now(),
  last_login_at timestamptz,
  constraint profiles_domain_by_role_check
    check ((role = 'user' and domain_id is not null) or (role <> 'user' and domain_id is null))
);

create unique index profiles_username_key on public.profiles (lower(username));
create index profiles_domain_id_idx on public.profiles (domain_id);
create index profiles_route_override_id_idx on public.profiles (route_override_id);
create index profiles_created_by_idx on public.profiles (created_by);

comment on table public.profiles is
  'Application profile of every Auth user. Deleting a user with log rows is refused (logs are permanent) - disable instead.';
create table public.branding (
  id boolean primary key default true check (id),
  company_name text not null check (char_length(company_name) between 1 and 120),
  app_display_name text not null default 'Pharma AI'
    check (char_length(app_display_name) between 2 and 30),
  logo_path text,
  logo_version integer not null default 0 check (logo_version >= 0),
  updated_at timestamptz not null default now(),
  updated_by uuid references public.profiles (id)
);

create index branding_updated_by_idx on public.branding (updated_by);

create table public.tenant_settings (
  id boolean primary key default true check (id),
  client_slug text not null default 'test-client' check (client_slug ~ '^[a-z0-9][a-z0-9-]{1,39}$'),
  timezone text not null default 'Asia/Kolkata',
  answer_retention_days integer not null default 0 check (answer_retention_days between 0 and 3650),
  log_retention_days integer not null default 1095 check (log_retention_days between 1 and 36500),
  upload_max_mb integer not null default 20 check (upload_max_mb between 1 and 20),
  allowed_types text[] not null default array['pdf', 'docx', 'xlsx', 'pptx', 'txt', 'csv', 'png', 'jpg']
    check (allowed_types <@ array['pdf', 'docx', 'xlsx', 'pptx', 'txt', 'csv', 'png', 'jpg']),
  idle_timeout_min integer not null default 15 check (idle_timeout_min between 1 and 1440),
  session_max_hours integer not null default 12 check (session_max_hours between 1 and 72),
  lockout_threshold integer not null default 5 check (lockout_threshold between 1 and 20),
  allow_copy boolean not null default true,
  admin_approved_pcs_only boolean not null default false,
  update_policy text not null default 'admin_approved' check (update_policy in ('admin_approved', 'manual')),
  approved_version text,
  catalogue_version text not null default '1.0.0',
  licence_token text,
  licence_status text check (licence_status is null or licence_status in ('active', 'paused', 'revoked')),
  licence_id text check (licence_id is null or licence_id ~ '^lic_[a-z2-7]{20}$'),
  licence_updated_at timestamptz,
  last_report_day date,
  seat_plan text not null default 'per_pc' check (seat_plan in ('per_pc', 'per_user')),
  usd_inr_rate numeric(10, 4) not null default 88 check (usd_inr_rate > 0),
  employee_notice_text text not null,
  updated_at timestamptz not null default now()
);

comment on column public.tenant_settings.client_slug is
  'Used for the internal Auth e-mail addresses: <username>@<client_slug>.pharmaai.local (no e-mail is ever sent).';
comment on column public.tenant_settings.last_report_day is
  'Last IST day successfully reported by usage-report (for back-filling missed days).';
create table public.model_prices (
  id uuid primary key default gen_random_uuid(),
  provider text not null check (provider in ('anthropic', 'openai', 'google', 'azure_openai')),
  model_id text check (model_id is null or char_length(model_id) between 1 and 120),
  display_name text not null check (char_length(display_name) between 1 and 120),
  tier text not null check (tier in ('premium', 'standard', 'economy')),
  classifier boolean not null default false,
  input_per_mtok numeric(12, 4) check (input_per_mtok is null or input_per_mtok >= 0),
  cached_input_per_mtok numeric(12, 4) check (cached_input_per_mtok is null or cached_input_per_mtok >= 0),
  output_per_mtok numeric(12, 4) check (output_per_mtok is null or output_per_mtok >= 0),
  currency text not null default 'USD' check (currency = 'USD'),
  valid_from date,
  valid_to date,
  is_example boolean not null default true,
  notes text,
  updated_at timestamptz not null default now(),
  constraint model_prices_validity_check check (valid_from is null or valid_to is null or valid_from <= valid_to),
  constraint model_prices_unique unique nulls not distinct (provider, display_name, valid_from)
);

comment on column public.model_prices.model_id is
  'Provider model id. Nullable on purpose: OpenAI and Google ids are entered by the Admin at set-up (MASTER_PROMPT 10.9).';

create table public.budgets (
  id uuid primary key default gen_random_uuid(),
  scope text not null check (scope in ('client', 'domain', 'user')),
  scope_id text,
  daily_tokens integer check (daily_tokens is null or daily_tokens > 0),
  monthly_cost_limit numeric(14, 2) check (monthly_cost_limit is null or monthly_cost_limit >= 0),
  currency text not null default 'INR' check (currency in ('INR', 'USD')),
  alert_pcts integer[] not null default array[80, 100]
    check (alert_pcts <@ array[50, 60, 70, 75, 80, 90, 95, 100]),
  action text not null default 'notify' check (action in ('block', 'notify')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint budgets_scope_id_check check ((scope = 'client') = (scope_id is null)),
  constraint budgets_scope_unique unique nulls not distinct (scope, scope_id)
);

create table public.usage_daily (
  id uuid primary key default gen_random_uuid(),
  day date not null,
  user_id uuid not null references public.profiles (id),
  domain_id text references public.domains (id),
  provider text,
  model text,
  kind text not null check (kind in ('main', 'classifier')),
  input_tokens bigint not null default 0 check (input_tokens >= 0),
  cached_tokens bigint not null default 0 check (cached_tokens >= 0),
  output_tokens bigint not null default 0 check (output_tokens >= 0),
  est_cost numeric(14, 6) not null default 0 check (est_cost >= 0),
  requests integer not null default 0 check (requests >= 0),
  blocked integer not null default 0 check (blocked >= 0),
  updated_at timestamptz not null default now(),
  constraint usage_daily_unique unique nulls not distinct (day, user_id, domain_id, provider, model, kind)
);

create index usage_daily_user_day_idx on public.usage_daily (user_id, day);
create index usage_daily_domain_day_idx on public.usage_daily (domain_id, day);

comment on column public.usage_daily.day is 'IST calendar day (tenant_settings.timezone).';
comment on column public.usage_daily.input_tokens is 'All input tokens including cached_tokens.';
create table public.notification_rules (
  type text primary key check (type ~ '^[a-z][a-z0-9_]{1,39}$'),
  label text not null,
  enabled boolean not null default true,
  locked boolean not null default false,
  updated_at timestamptz not null default now(),
  constraint notification_rules_locked_check check (enabled or not locked)
);

create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  type text not null references public.notification_rules (type),
  title text not null check (char_length(title) between 1 and 200),
  body text check (body is null or char_length(body) <= 2000),
  ref_table text,
  ref_id text,
  created_at timestamptz not null default now(),
  read_at timestamptz,
  read_by uuid references public.profiles (id)
);

create index notifications_created_at_idx on public.notifications (created_at desc);
create index notifications_type_idx on public.notifications (type);
create index notifications_read_by_idx on public.notifications (read_by);

comment on column public.notifications.body is 'Never contains prompt text or file content.';
create table public.legal_holds (
  id uuid primary key default gen_random_uuid(),
  filter jsonb not null check (jsonb_typeof(filter) = 'object'),
  reason text not null check (char_length(btrim(reason)) >= 3),
  created_by uuid references public.profiles (id),
  created_at timestamptz not null default now(),
  released_at timestamptz,
  released_by uuid references public.profiles (id),
  release_reason text,
  constraint legal_holds_release_check
    check (released_at is null or (release_reason is not null and char_length(btrim(release_reason)) >= 3))
);

create index legal_holds_active_idx on public.legal_holds (created_at) where released_at is null;
create index legal_holds_created_by_idx on public.legal_holds (created_by);
create index legal_holds_released_by_idx on public.legal_holds (released_by);

create table public.devices (
  device_id text primary key check (device_id ~ '^[0-9a-f]{32}$'),
  machine_hash text check (machine_hash is null or machine_hash ~ '^[0-9a-f]{64}$'),
  device_name text check (device_name is null or char_length(device_name) <= 120),
  os_version text check (os_version is null or char_length(os_version) <= 120),
  app_version text check (app_version is null or char_length(app_version) <= 40),
  first_seen timestamptz not null default now(),
  last_seen timestamptz not null default now(),
  last_user_id uuid references public.profiles (id),
  seat_expires_at timestamptz,
  released_at timestamptz,
  admin_login_allowed boolean not null default false
);

create index devices_last_user_id_idx on public.devices (last_user_id);

comment on column public.devices.released_at is 'Set by admin-licence; auth-login never clears it.';

create table public.force_logout (
  id uuid primary key default gen_random_uuid(),
  target_user_id uuid references public.profiles (id),
  target_device_id text references public.devices (device_id),
  reason text not null default 'admin' check (char_length(reason) between 1 and 200),
  created_by uuid references public.profiles (id),
  created_at timestamptz not null default now(),
  constraint force_logout_target_check check (target_user_id is not null or target_device_id is not null)
);

create index force_logout_target_user_idx on public.force_logout (target_user_id, created_at desc);
create index force_logout_target_device_idx on public.force_logout (target_device_id, created_at desc);
create index force_logout_created_by_idx on public.force_logout (created_by);

create table public.notices (
  id uuid primary key default gen_random_uuid(),
  title text not null check (char_length(title) between 1 and 120),
  body text not null check (char_length(body) between 1 and 2000),
  domain_id text references public.domains (id),
  created_by uuid references public.profiles (id),
  created_at timestamptz not null default now(),
  expires_at timestamptz
);

create index notices_domain_id_idx on public.notices (domain_id);
create index notices_created_by_idx on public.notices (created_by);
