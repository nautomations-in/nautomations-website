drop policy force_logout_select on public.force_logout;

create policy force_logout_select on public.force_logout
  for select to authenticated using (
    target_user_id = (select auth.uid())
    or target_device_id = ((select auth.jwt()) ->> 'device_id')
    or (select public.is_admin())
  );
