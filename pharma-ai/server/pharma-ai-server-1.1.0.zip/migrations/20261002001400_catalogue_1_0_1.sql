insert into public.domains (id, name, group_name, default_tier, default_daily_tokens, max_output_tokens, file_max_output_tokens, temperature, icon, sort_order, policy_version)
values
  ('ADM', 'Administration / Management', 'Corporate / Office', 'standard', 100000, 3072, 8192, 0.30, 'business_center', 1, '1.0.1'),
  ('HR', 'HR (Human Resources)', 'Corporate / Office', 'standard', 100000, 3072, 8192, 0.30, 'groups', 2, '1.0.1'),
  ('FIN', 'Finance & Accounts', 'Corporate / Office', 'standard', 100000, 3072, 8192, 0.30, 'account_balance', 3, '1.0.1'),
  ('SMB', 'Sales & Marketing, Business Development', 'Corporate / Office', 'standard', 100000, 3072, 8192, 0.30, 'trending_up', 4, '1.0.1'),
  ('PUR', 'Purchase / Procurement / Commercial', 'Corporate / Office', 'standard', 100000, 3072, 8192, 0.30, 'shopping_cart', 5, '1.0.1'),
  ('SCM', 'Supply Chain', 'Corporate / Office', 'standard', 100000, 3072, 8192, 0.30, 'local_shipping', 6, '1.0.1'),
  ('PPC', 'Planning / PPC', 'Corporate / Office', 'standard', 100000, 3072, 8192, 0.30, 'event_note', 7, '1.0.1'),
  ('LRA', 'Legal & Regulatory Affairs', 'Corporate / Office', 'premium', 150000, 4096, 8192, 0.30, 'gavel', 8, '1.0.1'),
  ('PRD', 'Production & Operations', 'Manufacturing Plant', 'premium', 150000, 4096, 8192, 0.30, 'factory', 9, '1.0.1'),
  ('QQV', 'QA / QC / Validation', 'Manufacturing Plant', 'premium', 150000, 4096, 8192, 0.30, 'verified', 10, '1.0.1'),
  ('RND', 'Research & Development', 'Manufacturing Plant', 'premium', 150000, 4096, 8192, 0.30, 'biotech', 11, '1.0.1'),
  ('WHS', 'Warehouse / Stores', 'Manufacturing Plant', 'standard', 100000, 3072, 8192, 0.30, 'warehouse', 12, '1.0.1'),
  ('ENG', 'Engineering, Maintenance & Projects', 'Manufacturing Plant', 'premium', 150000, 4096, 8192, 0.30, 'engineering', 13, '1.0.1'),
  ('EHS', 'EHS / Safety', 'Manufacturing Plant', 'standard', 100000, 3072, 8192, 0.30, 'health_and_safety', 14, '1.0.1'),
  ('FAC', 'Facility Management', 'Manufacturing Plant', 'economy', 50000, 2048, 8192, 0.30, 'apartment', 15, '1.0.1'),
  ('SEC', 'Security', 'Common (Office & Plant)', 'economy', 50000, 2048, 8192, 0.30, 'security', 16, '1.0.1'),
  ('ITS', 'IT', 'Common (Office & Plant)', 'standard', 100000, 3072, 8192, 0.30, 'computer', 17, '1.0.1'),
  ('HKP', 'Housekeeping', 'Common (Office & Plant)', 'economy', 50000, 2048, 8192, 0.30, 'cleaning_services', 18, '1.0.1'),
  ('CAN', 'Canteen', 'Common (Office & Plant)', 'economy', 50000, 2048, 8192, 0.30, 'restaurant', 19, '1.0.1')
on conflict (id) do update set
  name = excluded.name,
  group_name = excluded.group_name,
  default_tier = excluded.default_tier,
  default_daily_tokens = excluded.default_daily_tokens,
  max_output_tokens = excluded.max_output_tokens,
  file_max_output_tokens = excluded.file_max_output_tokens,
  temperature = excluded.temperature,
  icon = excluded.icon,
  sort_order = excluded.sort_order,
  policy_version = excluded.policy_version;

insert into public.domain_policies (domain_id, version, policy_json, active)
values
  ('ADM', '1.0.1', $pai${
  "id": "ADM",
  "version": "1.0.1",
  "name": "Administration / Management",
  "group": "Corporate / Office",
  "icon": "business_center",
  "tier": "standard",
  "dailyTokens": 100000,
  "maxOutputTokens": 3072,
  "fileMaxOutputTokens": 8192,
  "temperature": 0.3,
  "sortOrder": 1,
  "users": "MD / CEO office, plant head, admin managers, executive assistants",
  "inScope": [
    "Company policies, circulars, notices and announcements",
    "Meeting agendas and minutes of meeting (MoM)",
    "Management reports and KPI summaries from data the user gives",
    "Operational planning, annual plans, management-level budget overviews",
    "Board / management presentations and decision memos",
    "Office administration procedures, travel and event administration",
    "Management review inputs (ISO / QMS) together with QA"
  ],
  "outScope": [
    "Writing software code",
    "Personal investment or stock tips",
    "Definitive legal opinions (→ Legal & RA)",
    "GMP batch decisions (→ QA)"
  ],
  "specialRules": "Management summaries must state assumptions and data sources given by the user.",
  "blockPatterns": [
    "((^|[^\\w\\s])\\s*|\\b(?!(contains?|containing|contained|embedded|existing|legacy|restores?|restoring|restored|recovers?|recovering|recovered|validates?|validating|validated|backup|up|archives?|archiving|archived|retrieves?|retrieving|retrieved)\\s)(?!(the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s)\\w+\\s+)((the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s+){0,2}(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\s+(codes?|scripts?|programs?|macros?|quer(y|ies)|functions?|snippets?|modules?|subroutines?)\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))",
    "\\b(codes?|scripts?|macros?|quer(y|ies))\\s+((in|using|with)\\s+((a|an|the)\\s+)?|for\\s+(a|an)\\s+)(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\b(?!\\s+server)",
    "((^|[^\\w\\s])\\s*|\\b(?!(contains?|containing|contained|embedded|existing|legacy|restores?|restoring|restored|recovers?|recovering|recovered|validates?|validating|validated|backup|up|archives?|archiving|archived|retrieves?|retrieving|retrieved)\\s)(?!(the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s)\\w+\\s+)((the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s+){0,2}(plc|scada|source|program)\\s+codes?\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))(?![^.;?!\\n]{0,80}\\b(was|were|is|are|got|gets|has\\s+been|have\\s+been|had\\s+been)\\s+(lost|deleted|corrupted|erased|wiped|missing|overwritten|damaged)\\b)",
    "\\b(shell|batch|cmd|automation|apps)\\s+scripts?\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))",
    "\\b(macro\\s+(for|to|in|using)|macros\\s+(for|to|using))\\s+(ms\\s+|microsoft\\s+|google\\s+)?(excel|word|sheets?|outlook|vba)\\b(?!\\s+(files?|documents?|attachments?|settings?|options|reviews?|risks?|security|threats?|malware|viruses))",
    "\\b(write|create|generate|develop|build|make|give|provide|share|need|want)\\s+(me\\s+|us\\s+)?((a|an|the|some|this|that|small|simple|short|sample|quick|full|complete|working|new|basic)\\s+){0,3}programs?\\s+(in|using|with)\\s+(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\b(?!\\s+server)"
  ],
  "reviewPatterns": [
    "\\b(create|write|generate|give|make|build|develop|provide|prepare|need|want)\\s+(me\\s+|us\\s+)?((a|an|the|some|any|sample|simple|small|full|complete|working|new|my|our)\\s+){0,3}(codes?|macros?)\\b(?!-|\\s+of\\b)",
    "\\binstall(ation|ing)?\\s+(of\\s+)?((a|an|the|new|latest)\\s+)?(software|windows|python|office|ms\\s+office|drivers?|apps?)\\b",
    "\\bscripts?\\s+(to|that|which)\\s+(automat(e|es)|renames?|cop(y|ies)|moves?|deletes?|downloads?|scrapes?|extracts?|runs?|execut(e|es)|installs?|updates?|monitors?|backs?\\s+up)\\b"
  ],
  "noCode": true,
  "allowFormulas": true,
  "exports": [
    "docx",
    "pdf",
    "xlsx",
    "pptx",
    "chart",
    "diagram",
    "email"
  ],
  "refusal": "This is outside the Administration / Management domain, so I can’t help with it here. {suggestion}",
  "examplesIn": [
    "Draft the agenda and MoM format for the monthly plant review meeting."
  ],
  "examplesOut": [
    "Write a Python script to collect competitor prices from websites."
  ]
}$pai$::jsonb, true),
  ('HR', '1.0.1', $pai${
  "id": "HR",
  "version": "1.0.1",
  "name": "HR (Human Resources)",
  "group": "Corporate / Office",
  "icon": "groups",
  "tier": "standard",
  "dailyTokens": 100000,
  "maxOutputTokens": 3072,
  "fileMaxOutputTokens": 8192,
  "temperature": 0.3,
  "sortOrder": 2,
  "users": "HR managers, recruiters, training coordinators, payroll / time office",
  "inScope": [
    "Job descriptions, recruitment advertisements, interview question sets",
    "Offer and appointment letter drafts, induction plans",
    "Training calendars, GMP training matrix (with QA), training effectiveness forms",
    "Attendance, leave and HR policy explanations and drafts",
    "Performance appraisal formats, HR SOPs, grievance and exit procedures",
    "Statutory awareness (PF, ESI, gratuity, working hours) — informational, verify with HR / legal"
  ],
  "outScope": [
    "Medical diagnosis for employees",
    "IT account creation (→ IT)",
    "Legal disputes (→ Legal & RA)",
    "Code or macros"
  ],
  "specialRules": "Never recommend decisions based on protected characteristics; use personal data only when necessary.",
  "blockPatterns": [
    "((^|[^\\w\\s])\\s*|\\b(?!(contains?|containing|contained|embedded|existing|legacy|restores?|restoring|restored|recovers?|recovering|recovered|validates?|validating|validated|backup|up|archives?|archiving|archived|retrieves?|retrieving|retrieved)\\s)(?!(the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s)\\w+\\s+)((the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s+){0,2}(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\s+(codes?|scripts?|programs?|macros?|quer(y|ies)|functions?|snippets?|modules?|subroutines?)\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))",
    "\\b(codes?|scripts?|macros?|quer(y|ies))\\s+((in|using|with)\\s+((a|an|the)\\s+)?|for\\s+(a|an)\\s+)(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\b(?!\\s+server)",
    "((^|[^\\w\\s])\\s*|\\b(?!(contains?|containing|contained|embedded|existing|legacy|restores?|restoring|restored|recovers?|recovering|recovered|validates?|validating|validated|backup|up|archives?|archiving|archived|retrieves?|retrieving|retrieved)\\s)(?!(the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s)\\w+\\s+)((the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s+){0,2}(plc|scada|source|program)\\s+codes?\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))(?![^.;?!\\n]{0,80}\\b(was|were|is|are|got|gets|has\\s+been|have\\s+been|had\\s+been)\\s+(lost|deleted|corrupted|erased|wiped|missing|overwritten|damaged)\\b)",
    "\\b(shell|batch|cmd|automation|apps)\\s+scripts?\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))",
    "\\b(macro\\s+(for|to|in|using)|macros\\s+(for|to|using))\\s+(ms\\s+|microsoft\\s+|google\\s+)?(excel|word|sheets?|outlook|vba)\\b(?!\\s+(files?|documents?|attachments?|settings?|options|reviews?|risks?|security|threats?|malware|viruses))",
    "\\b(write|create|generate|develop|build|make|give|provide|share|need|want)\\s+(me\\s+|us\\s+)?((a|an|the|some|this|that|small|simple|short|sample|quick|full|complete|working|new|basic)\\s+){0,3}programs?\\s+(in|using|with)\\s+(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\b(?!\\s+server)"
  ],
  "reviewPatterns": [
    "\\b(create|write|generate|give|make|build|develop|provide|prepare|need|want)\\s+(me\\s+|us\\s+)?((a|an|the|some|any|sample|simple|small|full|complete|working|new|my|our)\\s+){0,3}(codes?|macros?)\\b(?!-|\\s+of\\b)",
    "\\binstall(ation|ing)?\\s+(of\\s+)?((a|an|the|new|latest)\\s+)?(software|windows|python|office|ms\\s+office|drivers?|apps?)\\b",
    "\\bscripts?\\s+(to|that|which)\\s+(automat(e|es)|renames?|cop(y|ies)|moves?|deletes?|downloads?|scrapes?|extracts?|runs?|execut(e|es)|installs?|updates?|monitors?|backs?\\s+up)\\b"
  ],
  "noCode": true,
  "allowFormulas": true,
  "exports": [
    "docx",
    "pdf",
    "xlsx",
    "pptx",
    "chart",
    "diagram",
    "email"
  ],
  "refusal": "This is outside the HR (Human Resources) domain, so I can’t help with it here. {suggestion}",
  "examplesIn": [
    "Create a job description and 10 interview questions for a QC chemist (HPLC)."
  ],
  "examplesOut": [
    "Compare the share price of two pharma companies for my investment."
  ]
}$pai$::jsonb, true),
  ('FIN', '1.0.1', $pai${
  "id": "FIN",
  "version": "1.0.1",
  "name": "Finance & Accounts",
  "group": "Corporate / Office",
  "icon": "account_balance",
  "tier": "standard",
  "dailyTokens": 100000,
  "maxOutputTokens": 3072,
  "fileMaxOutputTokens": 8192,
  "temperature": 0.3,
  "sortOrder": 3,
  "users": "Accounts, costing, treasury, taxation, MIS teams",
  "inScope": [
    "Budget and variance analysis from figures the user provides",
    "Product costing and BOM cost roll-up concepts",
    "GST, e-invoice, e-way bill and TDS process explanations (final position verified by CA)",
    "Payment follow-up emails, vendor / customer reconciliation formats",
    "MIS, cash-flow, fixed-asset register templates and Excel formulas",
    "Audit schedules and finance SOPs"
  ],
  "outScope": [
    "Personal tax filing or stock tips",
    "VBA / macro code",
    "Production troubleshooting (→ Production / Engineering)"
  ],
  "specialRules": "Calculations only from user data with assumptions shown; Excel formulas allowed, macros not allowed.",
  "blockPatterns": [
    "((^|[^\\w\\s])\\s*|\\b(?!(contains?|containing|contained|embedded|existing|legacy|restores?|restoring|restored|recovers?|recovering|recovered|validates?|validating|validated|backup|up|archives?|archiving|archived|retrieves?|retrieving|retrieved)\\s)(?!(the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s)\\w+\\s+)((the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s+){0,2}(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\s+(codes?|scripts?|programs?|macros?|quer(y|ies)|functions?|snippets?|modules?|subroutines?)\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))",
    "\\b(codes?|scripts?|macros?|quer(y|ies))\\s+((in|using|with)\\s+((a|an|the)\\s+)?|for\\s+(a|an)\\s+)(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\b(?!\\s+server)",
    "((^|[^\\w\\s])\\s*|\\b(?!(contains?|containing|contained|embedded|existing|legacy|restores?|restoring|restored|recovers?|recovering|recovered|validates?|validating|validated|backup|up|archives?|archiving|archived|retrieves?|retrieving|retrieved)\\s)(?!(the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s)\\w+\\s+)((the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s+){0,2}(plc|scada|source|program)\\s+codes?\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))(?![^.;?!\\n]{0,80}\\b(was|were|is|are|got|gets|has\\s+been|have\\s+been|had\\s+been)\\s+(lost|deleted|corrupted|erased|wiped|missing|overwritten|damaged)\\b)",
    "\\b(shell|batch|cmd|automation|apps)\\s+scripts?\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))",
    "\\b(macro\\s+(for|to|in|using)|macros\\s+(for|to|using))\\s+(ms\\s+|microsoft\\s+|google\\s+)?(excel|word|sheets?|outlook|vba)\\b(?!\\s+(files?|documents?|attachments?|settings?|options|reviews?|risks?|security|threats?|malware|viruses))",
    "\\b(write|create|generate|develop|build|make|give|provide|share|need|want)\\s+(me\\s+|us\\s+)?((a|an|the|some|this|that|small|simple|short|sample|quick|full|complete|working|new|basic)\\s+){0,3}programs?\\s+(in|using|with)\\s+(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\b(?!\\s+server)"
  ],
  "reviewPatterns": [
    "\\b(create|write|generate|give|make|build|develop|provide|prepare|need|want)\\s+(me\\s+|us\\s+)?((a|an|the|some|any|sample|simple|small|full|complete|working|new|my|our)\\s+){0,3}(codes?|macros?)\\b(?!-|\\s+of\\b)",
    "\\binstall(ation|ing)?\\s+(of\\s+)?((a|an|the|new|latest)\\s+)?(software|windows|python|office|ms\\s+office|drivers?|apps?)\\b",
    "\\bscripts?\\s+(to|that|which)\\s+(automat(e|es)|renames?|cop(y|ies)|moves?|deletes?|downloads?|scrapes?|extracts?|runs?|execut(e|es)|installs?|updates?|monitors?|backs?\\s+up)\\b"
  ],
  "noCode": true,
  "allowFormulas": true,
  "exports": [
    "docx",
    "pdf",
    "xlsx",
    "pptx",
    "chart",
    "diagram",
    "email"
  ],
  "refusal": "This is outside the Finance & Accounts domain, so I can’t help with it here. {suggestion}",
  "examplesIn": [
    "Make an Excel budget-vs-actual template with variance % and conditional colours."
  ],
  "examplesOut": [
    "Write a VBA macro that emails all vendors automatically."
  ]
}$pai$::jsonb, true),
  ('SMB', '1.0.1', $pai${
  "id": "SMB",
  "version": "1.0.1",
  "name": "Sales & Marketing, Business Development",
  "group": "Corporate / Office",
  "icon": "trending_up",
  "tier": "standard",
  "dailyTokens": 100000,
  "maxOutputTokens": 3072,
  "fileMaxOutputTokens": 8192,
  "temperature": 0.3,
  "sortOrder": 4,
  "users": "Domestic / export sales, marketing, BD, tender teams",
  "inScope": [
    "Customer emails, proposals, tender / RFP response drafts",
    "Product literature drafts within approved claims",
    "Market research summaries from information the user provides",
    "Pricing-strategy frameworks, sales plans, CRM follow-up plans",
    "Presentations, exhibition plans, export document formats (pro-forma, packing list)",
    "BD pipeline reports and customer meeting notes"
  ],
  "outScope": [
    "Unapproved medical or therapeutic claims",
    "Inventing competitor prices",
    "Internal HR matters (→ HR)",
    "Code"
  ],
  "specialRules": "Promotional content must follow the Uniform Code for Pharmaceutical Marketing Practices (UCPMP) 2024 and be approved by Medical / RA.",
  "blockPatterns": [
    "((^|[^\\w\\s])\\s*|\\b(?!(contains?|containing|contained|embedded|existing|legacy|restores?|restoring|restored|recovers?|recovering|recovered|validates?|validating|validated|backup|up|archives?|archiving|archived|retrieves?|retrieving|retrieved)\\s)(?!(the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s)\\w+\\s+)((the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s+){0,2}(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\s+(codes?|scripts?|programs?|macros?|quer(y|ies)|functions?|snippets?|modules?|subroutines?)\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))",
    "\\b(codes?|scripts?|macros?|quer(y|ies))\\s+((in|using|with)\\s+((a|an|the)\\s+)?|for\\s+(a|an)\\s+)(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\b(?!\\s+server)",
    "((^|[^\\w\\s])\\s*|\\b(?!(contains?|containing|contained|embedded|existing|legacy|restores?|restoring|restored|recovers?|recovering|recovered|validates?|validating|validated|backup|up|archives?|archiving|archived|retrieves?|retrieving|retrieved)\\s)(?!(the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s)\\w+\\s+)((the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s+){0,2}(plc|scada|source|program)\\s+codes?\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))(?![^.;?!\\n]{0,80}\\b(was|were|is|are|got|gets|has\\s+been|have\\s+been|had\\s+been)\\s+(lost|deleted|corrupted|erased|wiped|missing|overwritten|damaged)\\b)",
    "\\b(shell|batch|cmd|automation|apps)\\s+scripts?\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))",
    "\\b(macro\\s+(for|to|in|using)|macros\\s+(for|to|using))\\s+(ms\\s+|microsoft\\s+|google\\s+)?(excel|word|sheets?|outlook|vba)\\b(?!\\s+(files?|documents?|attachments?|settings?|options|reviews?|risks?|security|threats?|malware|viruses))",
    "\\b(write|create|generate|develop|build|make|give|provide|share|need|want)\\s+(me\\s+|us\\s+)?((a|an|the|some|this|that|small|simple|short|sample|quick|full|complete|working|new|basic)\\s+){0,3}programs?\\s+(in|using|with)\\s+(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\b(?!\\s+server)"
  ],
  "reviewPatterns": [
    "\\b(create|write|generate|give|make|build|develop|provide|prepare|need|want)\\s+(me\\s+|us\\s+)?((a|an|the|some|any|sample|simple|small|full|complete|working|new|my|our)\\s+){0,3}(codes?|macros?)\\b(?!-|\\s+of\\b)",
    "\\binstall(ation|ing)?\\s+(of\\s+)?((a|an|the|new|latest)\\s+)?(software|windows|python|office|ms\\s+office|drivers?|apps?)\\b",
    "\\bscripts?\\s+(to|that|which)\\s+(automat(e|es)|renames?|cop(y|ies)|moves?|deletes?|downloads?|scrapes?|extracts?|runs?|execut(e|es)|installs?|updates?|monitors?|backs?\\s+up)\\b"
  ],
  "noCode": true,
  "allowFormulas": true,
  "exports": [
    "docx",
    "pdf",
    "xlsx",
    "pptx",
    "chart",
    "diagram",
    "email"
  ],
  "refusal": "This is outside the Sales & Marketing, Business Development domain, so I can’t help with it here. {suggestion}",
  "examplesIn": [
    "Draft a proposal email for supplying our paracetamol API to a new formulation customer."
  ],
  "examplesOut": [
    "Tell me how to fix the boiler pressure drop."
  ]
}$pai$::jsonb, true),
  ('PUR', '1.0.1', $pai${
  "id": "PUR",
  "version": "1.0.1",
  "name": "Purchase / Procurement / Commercial",
  "group": "Corporate / Office",
  "icon": "shopping_cart",
  "tier": "standard",
  "dailyTokens": 100000,
  "maxOutputTokens": 3072,
  "fileMaxOutputTokens": 8192,
  "temperature": 0.3,
  "sortOrder": 5,
  "users": "Purchase officers, commercial managers, import / export desk",
  "inScope": [
    "RFQ / enquiry drafts and purchase specifications",
    "Techno-commercial comparison statements from quotations the user uploads",
    "PO terms and conditions drafts, Incoterms explanation, import procedure overview",
    "Vendor evaluation / qualification questionnaires (with QA)",
    "Negotiation and delivery follow-up emails, purchase SOPs, cost-saving analysis"
  ],
  "outScope": [
    "Price comparison of unrelated personal products",
    "GMP vendor approval decision (→ QA)",
    "Code"
  ],
  "specialRules": "Never invent vendor prices or phone numbers; compare only quotations provided.",
  "blockPatterns": [
    "((^|[^\\w\\s])\\s*|\\b(?!(contains?|containing|contained|embedded|existing|legacy|restores?|restoring|restored|recovers?|recovering|recovered|validates?|validating|validated|backup|up|archives?|archiving|archived|retrieves?|retrieving|retrieved)\\s)(?!(the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s)\\w+\\s+)((the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s+){0,2}(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\s+(codes?|scripts?|programs?|macros?|quer(y|ies)|functions?|snippets?|modules?|subroutines?)\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))",
    "\\b(codes?|scripts?|macros?|quer(y|ies))\\s+((in|using|with)\\s+((a|an|the)\\s+)?|for\\s+(a|an)\\s+)(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\b(?!\\s+server)",
    "((^|[^\\w\\s])\\s*|\\b(?!(contains?|containing|contained|embedded|existing|legacy|restores?|restoring|restored|recovers?|recovering|recovered|validates?|validating|validated|backup|up|archives?|archiving|archived|retrieves?|retrieving|retrieved)\\s)(?!(the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s)\\w+\\s+)((the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s+){0,2}(plc|scada|source|program)\\s+codes?\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))(?![^.;?!\\n]{0,80}\\b(was|were|is|are|got|gets|has\\s+been|have\\s+been|had\\s+been)\\s+(lost|deleted|corrupted|erased|wiped|missing|overwritten|damaged)\\b)",
    "\\b(shell|batch|cmd|automation|apps)\\s+scripts?\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))",
    "\\b(macro\\s+(for|to|in|using)|macros\\s+(for|to|using))\\s+(ms\\s+|microsoft\\s+|google\\s+)?(excel|word|sheets?|outlook|vba)\\b(?!\\s+(files?|documents?|attachments?|settings?|options|reviews?|risks?|security|threats?|malware|viruses))",
    "\\b(write|create|generate|develop|build|make|give|provide|share|need|want)\\s+(me\\s+|us\\s+)?((a|an|the|some|this|that|small|simple|short|sample|quick|full|complete|working|new|basic)\\s+){0,3}programs?\\s+(in|using|with)\\s+(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\b(?!\\s+server)"
  ],
  "reviewPatterns": [
    "\\b(create|write|generate|give|make|build|develop|provide|prepare|need|want)\\s+(me\\s+|us\\s+)?((a|an|the|some|any|sample|simple|small|full|complete|working|new|my|our)\\s+){0,3}(codes?|macros?)\\b(?!-|\\s+of\\b)",
    "\\binstall(ation|ing)?\\s+(of\\s+)?((a|an|the|new|latest)\\s+)?(software|windows|python|office|ms\\s+office|drivers?|apps?)\\b",
    "\\bscripts?\\s+(to|that|which)\\s+(automat(e|es)|renames?|cop(y|ies)|moves?|deletes?|downloads?|scrapes?|extracts?|runs?|execut(e|es)|installs?|updates?|monitors?|backs?\\s+up)\\b"
  ],
  "noCode": true,
  "allowFormulas": true,
  "exports": [
    "docx",
    "pdf",
    "xlsx",
    "pptx",
    "chart",
    "diagram",
    "email"
  ],
  "refusal": "This is outside the Purchase / Procurement / Commercial domain, so I can’t help with it here. {suggestion}",
  "examplesIn": [
    "Prepare a comparison statement of these three RO membrane quotations (uploaded)."
  ],
  "examplesOut": [
    "Which smartphone should I buy for my son?"
  ]
}$pai$::jsonb, true),
  ('SCM', '1.0.1', $pai${
  "id": "SCM",
  "version": "1.0.1",
  "name": "Supply Chain",
  "group": "Corporate / Office",
  "icon": "local_shipping",
  "tier": "standard",
  "dailyTokens": 100000,
  "maxOutputTokens": 3072,
  "fileMaxOutputTokens": 8192,
  "temperature": 0.3,
  "sortOrder": 6,
  "users": "Supply chain, logistics, distribution, S&OP teams",
  "inScope": [
    "Demand forecasting methods and S&OP meeting formats",
    "Inventory policies: ABC / VED / XYZ, safety stock and reorder-level calculations",
    "Distribution, transport and cold-chain (2–8 °C) shipment planning",
    "Good Distribution Practice (GDP) guidance, shipment document checklists",
    "Transporter evaluation, supply-risk analysis"
  ],
  "outScope": [
    "Finance approvals (→ Finance)",
    "Code"
  ],
  "specialRules": "Show formulas and assumptions for every inventory calculation.",
  "blockPatterns": [
    "((^|[^\\w\\s])\\s*|\\b(?!(contains?|containing|contained|embedded|existing|legacy|restores?|restoring|restored|recovers?|recovering|recovered|validates?|validating|validated|backup|up|archives?|archiving|archived|retrieves?|retrieving|retrieved)\\s)(?!(the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s)\\w+\\s+)((the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s+){0,2}(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\s+(codes?|scripts?|programs?|macros?|quer(y|ies)|functions?|snippets?|modules?|subroutines?)\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))",
    "\\b(codes?|scripts?|macros?|quer(y|ies))\\s+((in|using|with)\\s+((a|an|the)\\s+)?|for\\s+(a|an)\\s+)(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\b(?!\\s+server)",
    "((^|[^\\w\\s])\\s*|\\b(?!(contains?|containing|contained|embedded|existing|legacy|restores?|restoring|restored|recovers?|recovering|recovered|validates?|validating|validated|backup|up|archives?|archiving|archived|retrieves?|retrieving|retrieved)\\s)(?!(the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s)\\w+\\s+)((the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s+){0,2}(plc|scada|source|program)\\s+codes?\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))(?![^.;?!\\n]{0,80}\\b(was|were|is|are|got|gets|has\\s+been|have\\s+been|had\\s+been)\\s+(lost|deleted|corrupted|erased|wiped|missing|overwritten|damaged)\\b)",
    "\\b(shell|batch|cmd|automation|apps)\\s+scripts?\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))",
    "\\b(macro\\s+(for|to|in|using)|macros\\s+(for|to|using))\\s+(ms\\s+|microsoft\\s+|google\\s+)?(excel|word|sheets?|outlook|vba)\\b(?!\\s+(files?|documents?|attachments?|settings?|options|reviews?|risks?|security|threats?|malware|viruses))",
    "\\b(write|create|generate|develop|build|make|give|provide|share|need|want)\\s+(me\\s+|us\\s+)?((a|an|the|some|this|that|small|simple|short|sample|quick|full|complete|working|new|basic)\\s+){0,3}programs?\\s+(in|using|with)\\s+(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\b(?!\\s+server)"
  ],
  "reviewPatterns": [
    "\\b(create|write|generate|give|make|build|develop|provide|prepare|need|want)\\s+(me\\s+|us\\s+)?((a|an|the|some|any|sample|simple|small|full|complete|working|new|my|our)\\s+){0,3}(codes?|macros?)\\b(?!-|\\s+of\\b)",
    "\\binstall(ation|ing)?\\s+(of\\s+)?((a|an|the|new|latest)\\s+)?(software|windows|python|office|ms\\s+office|drivers?|apps?)\\b",
    "\\bscripts?\\s+(to|that|which)\\s+(automat(e|es)|renames?|cop(y|ies)|moves?|deletes?|downloads?|scrapes?|extracts?|runs?|execut(e|es)|installs?|updates?|monitors?|backs?\\s+up)\\b"
  ],
  "noCode": true,
  "allowFormulas": true,
  "exports": [
    "docx",
    "pdf",
    "xlsx",
    "pptx",
    "chart",
    "diagram",
    "email"
  ],
  "refusal": "This is outside the Supply Chain domain, so I can’t help with it here. {suggestion}",
  "examplesIn": [
    "Calculate safety stock for this material with the lead-time and demand data given."
  ],
  "examplesOut": [
    "Write a SQL query to extract our ERP stock table."
  ]
}$pai$::jsonb, true),
  ('PPC', '1.0.1', $pai${
  "id": "PPC",
  "version": "1.0.1",
  "name": "Planning / PPC",
  "group": "Corporate / Office",
  "icon": "event_note",
  "tier": "standard",
  "dailyTokens": 100000,
  "maxOutputTokens": 3072,
  "fileMaxOutputTokens": 8192,
  "temperature": 0.3,
  "sortOrder": 7,
  "users": "Production planning and control, MRP planners",
  "inScope": [
    "Production schedules, batch plans, Gantt charts in Excel",
    "Capacity and OEE calculations, line balancing, changeover (SMED) planning",
    "MRP concepts and material requirement plans",
    "Dispatch plans and planning SOPs"
  ],
  "outScope": [
    "QA decisions (→ QA)",
    "Macros or code"
  ],
  "specialRules": "Excel formulas allowed; no macros.",
  "blockPatterns": [
    "((^|[^\\w\\s])\\s*|\\b(?!(contains?|containing|contained|embedded|existing|legacy|restores?|restoring|restored|recovers?|recovering|recovered|validates?|validating|validated|backup|up|archives?|archiving|archived|retrieves?|retrieving|retrieved)\\s)(?!(the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s)\\w+\\s+)((the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s+){0,2}(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\s+(codes?|scripts?|programs?|macros?|quer(y|ies)|functions?|snippets?|modules?|subroutines?)\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))",
    "\\b(codes?|scripts?|macros?|quer(y|ies))\\s+((in|using|with)\\s+((a|an|the)\\s+)?|for\\s+(a|an)\\s+)(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\b(?!\\s+server)",
    "((^|[^\\w\\s])\\s*|\\b(?!(contains?|containing|contained|embedded|existing|legacy|restores?|restoring|restored|recovers?|recovering|recovered|validates?|validating|validated|backup|up|archives?|archiving|archived|retrieves?|retrieving|retrieved)\\s)(?!(the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s)\\w+\\s+)((the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s+){0,2}(plc|scada|source|program)\\s+codes?\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))(?![^.;?!\\n]{0,80}\\b(was|were|is|are|got|gets|has\\s+been|have\\s+been|had\\s+been)\\s+(lost|deleted|corrupted|erased|wiped|missing|overwritten|damaged)\\b)",
    "\\b(shell|batch|cmd|automation|apps)\\s+scripts?\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))",
    "\\b(macro\\s+(for|to|in|using)|macros\\s+(for|to|using))\\s+(ms\\s+|microsoft\\s+|google\\s+)?(excel|word|sheets?|outlook|vba)\\b(?!\\s+(files?|documents?|attachments?|settings?|options|reviews?|risks?|security|threats?|malware|viruses))",
    "\\b(write|create|generate|develop|build|make|give|provide|share|need|want)\\s+(me\\s+|us\\s+)?((a|an|the|some|this|that|small|simple|short|sample|quick|full|complete|working|new|basic)\\s+){0,3}programs?\\s+(in|using|with)\\s+(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\b(?!\\s+server)"
  ],
  "reviewPatterns": [
    "\\b(create|write|generate|give|make|build|develop|provide|prepare|need|want)\\s+(me\\s+|us\\s+)?((a|an|the|some|any|sample|simple|small|full|complete|working|new|my|our)\\s+){0,3}(codes?|macros?)\\b(?!-|\\s+of\\b)",
    "\\binstall(ation|ing)?\\s+(of\\s+)?((a|an|the|new|latest)\\s+)?(software|windows|python|office|ms\\s+office|drivers?|apps?)\\b",
    "\\bscripts?\\s+(to|that|which)\\s+(automat(e|es)|renames?|cop(y|ies)|moves?|deletes?|downloads?|scrapes?|extracts?|runs?|execut(e|es)|installs?|updates?|monitors?|backs?\\s+up)\\b"
  ],
  "noCode": true,
  "allowFormulas": true,
  "exports": [
    "docx",
    "pdf",
    "xlsx",
    "pptx",
    "chart",
    "diagram",
    "email"
  ],
  "refusal": "This is outside the Planning / PPC domain, so I can’t help with it here. {suggestion}",
  "examplesIn": [
    "Build a weekly compression-machine schedule for these 12 batches with changeovers."
  ],
  "examplesOut": [
    "Suggest marketing ideas for our new brand."
  ]
}$pai$::jsonb, true),
  ('LRA', '1.0.1', $pai${
  "id": "LRA",
  "version": "1.0.1",
  "name": "Legal & Regulatory Affairs",
  "group": "Corporate / Office",
  "icon": "gavel",
  "tier": "premium",
  "dailyTokens": 150000,
  "maxOutputTokens": 4096,
  "fileMaxOutputTokens": 8192,
  "temperature": 0.3,
  "sortOrder": 8,
  "users": "Legal counsel, company secretary, regulatory affairs (RA) teams",
  "inScope": [
    "Legal: contract clause review and drafting support (NDA, supply, service) — draft only",
    "Legal: statutory compliance calendars, notices, IP process overviews",
    "RA: CTD / eCTD structure, DMF, variations, query-response drafts",
    "RA: CDSCO, USFDA, EMA, WHO-PQ guideline explanations and labelling review against approved text"
  ],
  "outScope": [
    "Final legal opinions or court strategy (must be counsel)",
    "Code",
    "Commercial pricing"
  ],
  "specialRules": "Always name the regulation / guideline and version to verify; mark output “Draft — requires Legal / RA approval”. (Clients can split Legal and RA into two domains.)",
  "blockPatterns": [
    "((^|[^\\w\\s])\\s*|\\b(?!(contains?|containing|contained|embedded|existing|legacy|restores?|restoring|restored|recovers?|recovering|recovered|validates?|validating|validated|backup|up|archives?|archiving|archived|retrieves?|retrieving|retrieved)\\s)(?!(the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s)\\w+\\s+)((the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s+){0,2}(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\s+(codes?|scripts?|programs?|macros?|quer(y|ies)|functions?|snippets?|modules?|subroutines?)\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))",
    "\\b(codes?|scripts?|macros?|quer(y|ies))\\s+((in|using|with)\\s+((a|an|the)\\s+)?|for\\s+(a|an)\\s+)(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\b(?!\\s+server)",
    "((^|[^\\w\\s])\\s*|\\b(?!(contains?|containing|contained|embedded|existing|legacy|restores?|restoring|restored|recovers?|recovering|recovered|validates?|validating|validated|backup|up|archives?|archiving|archived|retrieves?|retrieving|retrieved)\\s)(?!(the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s)\\w+\\s+)((the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s+){0,2}(plc|scada|source|program)\\s+codes?\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))(?![^.;?!\\n]{0,80}\\b(was|were|is|are|got|gets|has\\s+been|have\\s+been|had\\s+been)\\s+(lost|deleted|corrupted|erased|wiped|missing|overwritten|damaged)\\b)",
    "\\b(shell|batch|cmd|automation|apps)\\s+scripts?\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))",
    "\\b(macro\\s+(for|to|in|using)|macros\\s+(for|to|using))\\s+(ms\\s+|microsoft\\s+|google\\s+)?(excel|word|sheets?|outlook|vba)\\b(?!\\s+(files?|documents?|attachments?|settings?|options|reviews?|risks?|security|threats?|malware|viruses))",
    "\\b(write|create|generate|develop|build|make|give|provide|share|need|want)\\s+(me\\s+|us\\s+)?((a|an|the|some|this|that|small|simple|short|sample|quick|full|complete|working|new|basic)\\s+){0,3}programs?\\s+(in|using|with)\\s+(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\b(?!\\s+server)"
  ],
  "reviewPatterns": [
    "\\b(create|write|generate|give|make|build|develop|provide|prepare|need|want)\\s+(me\\s+|us\\s+)?((a|an|the|some|any|sample|simple|small|full|complete|working|new|my|our)\\s+){0,3}(codes?|macros?)\\b(?!-|\\s+of\\b)",
    "\\binstall(ation|ing)?\\s+(of\\s+)?((a|an|the|new|latest)\\s+)?(software|windows|python|office|ms\\s+office|drivers?|apps?)\\b",
    "\\bscripts?\\s+(to|that|which)\\s+(automat(e|es)|renames?|cop(y|ies)|moves?|deletes?|downloads?|scrapes?|extracts?|runs?|execut(e|es)|installs?|updates?|monitors?|backs?\\s+up)\\b"
  ],
  "noCode": true,
  "allowFormulas": true,
  "exports": [
    "docx",
    "pdf",
    "xlsx",
    "pptx",
    "chart",
    "diagram",
    "email"
  ],
  "refusal": "This is outside the Legal & Regulatory Affairs domain, so I can’t help with it here. {suggestion}",
  "examplesIn": [
    "List the documents needed for a Module 3 quality section of a generic tablet dossier."
  ],
  "examplesOut": [
    "Write a Java program to generate our dossier index."
  ]
}$pai$::jsonb, true),
  ('PRD', '1.0.1', $pai${
  "id": "PRD",
  "version": "1.0.1",
  "name": "Production & Operations",
  "group": "Manufacturing Plant",
  "icon": "factory",
  "tier": "premium",
  "dailyTokens": 150000,
  "maxOutputTokens": 4096,
  "fileMaxOutputTokens": 8192,
  "temperature": 0.3,
  "sortOrder": 9,
  "users": "Production officers, shift in-charges, production heads (OSD, liquids, sterile, API)",
  "inScope": [
    "Batch process support: granulation, compression, coating, capsule filling, liquids, sterile, API steps",
    "BMR / BPR format drafts, line-clearance checklists, in-process checks, yield calculations",
    "Process troubleshooting (capping, sticking, weight variation, low yield)",
    "Equipment operating SOP drafts (with Engineering), cleaning procedure drafts (with QA)",
    "Shift handover logs, 5S / lean, first description of a deviation"
  ],
  "outScope": [
    "Releasing a batch (→ QA)",
    "Changing validated parameters without change control",
    "Code",
    "Commercial questions"
  ],
  "specialRules": "Never advise bypassing validated parameters or GMP controls; recommend deviation / change control.",
  "blockPatterns": [
    "((^|[^\\w\\s])\\s*|\\b(?!(contains?|containing|contained|embedded|existing|legacy|restores?|restoring|restored|recovers?|recovering|recovered|validates?|validating|validated|backup|up|archives?|archiving|archived|retrieves?|retrieving|retrieved)\\s)(?!(the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s)\\w+\\s+)((the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s+){0,2}(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\s+(codes?|scripts?|programs?|macros?|quer(y|ies)|functions?|snippets?|modules?|subroutines?)\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))",
    "\\b(codes?|scripts?|macros?|quer(y|ies))\\s+((in|using|with)\\s+((a|an|the)\\s+)?|for\\s+(a|an)\\s+)(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\b(?!\\s+server)",
    "((^|[^\\w\\s])\\s*|\\b(?!(contains?|containing|contained|embedded|existing|legacy|restores?|restoring|restored|recovers?|recovering|recovered|validates?|validating|validated|backup|up|archives?|archiving|archived|retrieves?|retrieving|retrieved)\\s)(?!(the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s)\\w+\\s+)((the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s+){0,2}(plc|scada|source|program)\\s+codes?\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))(?![^.;?!\\n]{0,80}\\b(was|were|is|are|got|gets|has\\s+been|have\\s+been|had\\s+been)\\s+(lost|deleted|corrupted|erased|wiped|missing|overwritten|damaged)\\b)",
    "\\b(shell|batch|cmd|automation|apps)\\s+scripts?\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))",
    "\\b(macro\\s+(for|to|in|using)|macros\\s+(for|to|using))\\s+(ms\\s+|microsoft\\s+|google\\s+)?(excel|word|sheets?|outlook|vba)\\b(?!\\s+(files?|documents?|attachments?|settings?|options|reviews?|risks?|security|threats?|malware|viruses))",
    "\\b(write|create|generate|develop|build|make|give|provide|share|need|want)\\s+(me\\s+|us\\s+)?((a|an|the|some|this|that|small|simple|short|sample|quick|full|complete|working|new|basic)\\s+){0,3}programs?\\s+(in|using|with)\\s+(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\b(?!\\s+server)"
  ],
  "reviewPatterns": [
    "\\b(create|write|generate|give|make|build|develop|provide|prepare|need|want)\\s+(me\\s+|us\\s+)?((a|an|the|some|any|sample|simple|small|full|complete|working|new|my|our)\\s+){0,3}(codes?|macros?)\\b(?!-|\\s+of\\b)",
    "\\binstall(ation|ing)?\\s+(of\\s+)?((a|an|the|new|latest)\\s+)?(software|windows|python|office|ms\\s+office|drivers?|apps?)\\b",
    "\\bscripts?\\s+(to|that|which)\\s+(automat(e|es)|renames?|cop(y|ies)|moves?|deletes?|downloads?|scrapes?|extracts?|runs?|execut(e|es)|installs?|updates?|monitors?|backs?\\s+up)\\b"
  ],
  "noCode": true,
  "allowFormulas": true,
  "exports": [
    "docx",
    "pdf",
    "xlsx",
    "pptx",
    "chart",
    "diagram",
    "email"
  ],
  "refusal": "This is outside the Production & Operations domain, so I can’t help with it here. {suggestion}",
  "examplesIn": [
    "Tablets show capping during compression — give a troubleshooting checklist."
  ],
  "examplesOut": [
    "What is the best way to invest my bonus?"
  ]
}$pai$::jsonb, true),
  ('QQV', '1.0.1', $pai${
  "id": "QQV",
  "version": "1.0.1",
  "name": "QA / QC / Validation",
  "group": "Manufacturing Plant",
  "icon": "verified",
  "tier": "premium",
  "dailyTokens": 150000,
  "maxOutputTokens": 4096,
  "fileMaxOutputTokens": 8192,
  "temperature": 0.3,
  "sortOrder": 10,
  "users": "Quality assurance, quality control laboratories, validation / qualification teams",
  "inScope": [
    "QA: SOPs, deviations, CAPA, change control, OOS / OOT structure, APQR, audits, complaints, recalls, data integrity (ALCOA+), ICH Q9(R1) risk management, ICH Q10 QMS",
    "QC: analytical methods (HPLC, GC, UV, KF, dissolution), ICH Q2(R2) method validation, specifications, IP / BP / USP / Ph. Eur. references, ICH Q1 stability, instrument troubleshooting, microbiology and water testing",
    "Validation: URS, DQ / IQ / OQ / PQ, process and cleaning validation (MACO / PDE), CSV (GAMP 5), utilities qualification, temperature mapping, traceability matrix"
  ],
  "outScope": [
    "AI approving, signing or releasing any record",
    "Code",
    "Commercial pricing"
  ],
  "specialRules": "Drafts only — humans approve. Cite guideline and version. Flag data-integrity risks. Clients may split into QA, QC and Validation domains.",
  "blockPatterns": [
    "((^|[^\\w\\s])\\s*|\\b(?!(contains?|containing|contained|embedded|existing|legacy|restores?|restoring|restored|recovers?|recovering|recovered|validates?|validating|validated|backup|up|archives?|archiving|archived|retrieves?|retrieving|retrieved)\\s)(?!(the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s)\\w+\\s+)((the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s+){0,2}(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\s+(codes?|scripts?|programs?|macros?|quer(y|ies)|functions?|snippets?|modules?|subroutines?)\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))",
    "\\b(codes?|scripts?|macros?|quer(y|ies))\\s+((in|using|with)\\s+((a|an|the)\\s+)?|for\\s+(a|an)\\s+)(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\b(?!\\s+server)",
    "((^|[^\\w\\s])\\s*|\\b(?!(contains?|containing|contained|embedded|existing|legacy|restores?|restoring|restored|recovers?|recovering|recovered|validates?|validating|validated|backup|up|archives?|archiving|archived|retrieves?|retrieving|retrieved)\\s)(?!(the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s)\\w+\\s+)((the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s+){0,2}(plc|scada|source|program)\\s+codes?\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))(?![^.;?!\\n]{0,80}\\b(was|were|is|are|got|gets|has\\s+been|have\\s+been|had\\s+been)\\s+(lost|deleted|corrupted|erased|wiped|missing|overwritten|damaged)\\b)",
    "\\b(shell|batch|cmd|automation|apps)\\s+scripts?\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))",
    "\\b(macro\\s+(for|to|in|using)|macros\\s+(for|to|using))\\s+(ms\\s+|microsoft\\s+|google\\s+)?(excel|word|sheets?|outlook|vba)\\b(?!\\s+(files?|documents?|attachments?|settings?|options|reviews?|risks?|security|threats?|malware|viruses))",
    "\\b(write|create|generate|develop|build|make|give|provide|share|need|want)\\s+(me\\s+|us\\s+)?((a|an|the|some|this|that|small|simple|short|sample|quick|full|complete|working|new|basic)\\s+){0,3}programs?\\s+(in|using|with)\\s+(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\b(?!\\s+server)"
  ],
  "reviewPatterns": [
    "\\b(create|write|generate|give|make|build|develop|provide|prepare|need|want)\\s+(me\\s+|us\\s+)?((a|an|the|some|any|sample|simple|small|full|complete|working|new|my|our)\\s+){0,3}(codes?|macros?)\\b(?!-|\\s+of\\b)",
    "\\binstall(ation|ing)?\\s+(of\\s+)?((a|an|the|new|latest)\\s+)?(software|windows|python|office|ms\\s+office|drivers?|apps?)\\b",
    "\\bscripts?\\s+(to|that|which)\\s+(automat(e|es)|renames?|cop(y|ies)|moves?|deletes?|downloads?|scrapes?|extracts?|runs?|execut(e|es)|installs?|updates?|monitors?|backs?\\s+up)\\b"
  ],
  "noCode": true,
  "allowFormulas": true,
  "exports": [
    "docx",
    "pdf",
    "xlsx",
    "pptx",
    "chart",
    "diagram",
    "email"
  ],
  "refusal": "This is outside the QA / QC / Validation domain, so I can’t help with it here. {suggestion}",
  "examplesIn": [
    "Draft a deviation investigation outline for a temperature excursion in the cold room."
  ],
  "examplesOut": [
    "Approve batch B2409 for release."
  ]
}$pai$::jsonb, true),
  ('RND', '1.0.1', $pai${
  "id": "RND",
  "version": "1.0.1",
  "name": "Research & Development",
  "group": "Manufacturing Plant",
  "icon": "biotech",
  "tier": "premium",
  "dailyTokens": 150000,
  "maxOutputTokens": 4096,
  "fileMaxOutputTokens": 8192,
  "temperature": 0.3,
  "sortOrder": 11,
  "users": "Formulation (FR&D), analytical (AR&D), process chemistry teams",
  "inScope": [
    "Pre-formulation, excipient selection, formulation development",
    "Analytical method development, DoE planning, QbD (ICH Q8)",
    "Literature summaries from papers the user uploads",
    "Stability design, scale-up and technology-transfer documents, lab notebook formats"
  ],
  "outScope": [
    "Hazardous or controlled-substance instructions outside legitimate pharma use",
    "Clinical dosing advice for patients",
    "Code"
  ],
  "specialRules": "AI provider safety policies apply; cite sources; mark as research draft.",
  "blockPatterns": [
    "((^|[^\\w\\s])\\s*|\\b(?!(contains?|containing|contained|embedded|existing|legacy|restores?|restoring|restored|recovers?|recovering|recovered|validates?|validating|validated|backup|up|archives?|archiving|archived|retrieves?|retrieving|retrieved)\\s)(?!(the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s)\\w+\\s+)((the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s+){0,2}(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\s+(codes?|scripts?|programs?|macros?|quer(y|ies)|functions?|snippets?|modules?|subroutines?)\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))",
    "\\b(codes?|scripts?|macros?|quer(y|ies))\\s+((in|using|with)\\s+((a|an|the)\\s+)?|for\\s+(a|an)\\s+)(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\b(?!\\s+server)",
    "((^|[^\\w\\s])\\s*|\\b(?!(contains?|containing|contained|embedded|existing|legacy|restores?|restoring|restored|recovers?|recovering|recovered|validates?|validating|validated|backup|up|archives?|archiving|archived|retrieves?|retrieving|retrieved)\\s)(?!(the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s)\\w+\\s+)((the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s+){0,2}(plc|scada|source|program)\\s+codes?\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))(?![^.;?!\\n]{0,80}\\b(was|were|is|are|got|gets|has\\s+been|have\\s+been|had\\s+been)\\s+(lost|deleted|corrupted|erased|wiped|missing|overwritten|damaged)\\b)",
    "\\b(shell|batch|cmd|automation|apps)\\s+scripts?\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))",
    "\\b(macro\\s+(for|to|in|using)|macros\\s+(for|to|using))\\s+(ms\\s+|microsoft\\s+|google\\s+)?(excel|word|sheets?|outlook|vba)\\b(?!\\s+(files?|documents?|attachments?|settings?|options|reviews?|risks?|security|threats?|malware|viruses))",
    "\\b(write|create|generate|develop|build|make|give|provide|share|need|want)\\s+(me\\s+|us\\s+)?((a|an|the|some|this|that|small|simple|short|sample|quick|full|complete|working|new|basic)\\s+){0,3}programs?\\s+(in|using|with)\\s+(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\b(?!\\s+server)"
  ],
  "reviewPatterns": [
    "\\b(create|write|generate|give|make|build|develop|provide|prepare|need|want)\\s+(me\\s+|us\\s+)?((a|an|the|some|any|sample|simple|small|full|complete|working|new|my|our)\\s+){0,3}(codes?|macros?)\\b(?!-|\\s+of\\b)",
    "\\binstall(ation|ing)?\\s+(of\\s+)?((a|an|the|new|latest)\\s+)?(software|windows|python|office|ms\\s+office|drivers?|apps?)\\b",
    "\\bscripts?\\s+(to|that|which)\\s+(automat(e|es)|renames?|cop(y|ies)|moves?|deletes?|downloads?|scrapes?|extracts?|runs?|execut(e|es)|installs?|updates?|monitors?|backs?\\s+up)\\b"
  ],
  "noCode": true,
  "allowFormulas": true,
  "exports": [
    "docx",
    "pdf",
    "xlsx",
    "pptx",
    "chart",
    "diagram",
    "email"
  ],
  "refusal": "This is outside the Research & Development domain, so I can’t help with it here. {suggestion}",
  "examplesIn": [
    "Plan a 2^3 factorial DoE for a wet-granulation process."
  ],
  "examplesOut": [
    "Install Python on my laptop."
  ]
}$pai$::jsonb, true),
  ('WHS', '1.0.1', $pai${
  "id": "WHS",
  "version": "1.0.1",
  "name": "Warehouse / Stores",
  "group": "Manufacturing Plant",
  "icon": "warehouse",
  "tier": "standard",
  "dailyTokens": 100000,
  "maxOutputTokens": 3072,
  "fileMaxOutputTokens": 8192,
  "temperature": 0.3,
  "sortOrder": 12,
  "users": "Warehouse in-charges, stores officers, dispensing staff",
  "inScope": [
    "GRN and material receipt, sampling, quarantine / approved / rejected status labelling",
    "FIFO / FEFO, storage conditions, cold room and humidity control procedures",
    "Dispensing procedures, bin cards, stock registers, cycle counting",
    "Returned goods, destruction and pest-control coordination procedures"
  ],
  "outScope": [
    "QA release decisions (→ QA)",
    "Purchase negotiation (→ Purchase)",
    "Code"
  ],
  "specialRules": "Status changes always follow QA procedures.",
  "blockPatterns": [
    "((^|[^\\w\\s])\\s*|\\b(?!(contains?|containing|contained|embedded|existing|legacy|restores?|restoring|restored|recovers?|recovering|recovered|validates?|validating|validated|backup|up|archives?|archiving|archived|retrieves?|retrieving|retrieved)\\s)(?!(the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s)\\w+\\s+)((the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s+){0,2}(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\s+(codes?|scripts?|programs?|macros?|quer(y|ies)|functions?|snippets?|modules?|subroutines?)\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))",
    "\\b(codes?|scripts?|macros?|quer(y|ies))\\s+((in|using|with)\\s+((a|an|the)\\s+)?|for\\s+(a|an)\\s+)(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\b(?!\\s+server)",
    "((^|[^\\w\\s])\\s*|\\b(?!(contains?|containing|contained|embedded|existing|legacy|restores?|restoring|restored|recovers?|recovering|recovered|validates?|validating|validated|backup|up|archives?|archiving|archived|retrieves?|retrieving|retrieved)\\s)(?!(the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s)\\w+\\s+)((the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s+){0,2}(plc|scada|source|program)\\s+codes?\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))(?![^.;?!\\n]{0,80}\\b(was|were|is|are|got|gets|has\\s+been|have\\s+been|had\\s+been)\\s+(lost|deleted|corrupted|erased|wiped|missing|overwritten|damaged)\\b)",
    "\\b(shell|batch|cmd|automation|apps)\\s+scripts?\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))",
    "\\b(macro\\s+(for|to|in|using)|macros\\s+(for|to|using))\\s+(ms\\s+|microsoft\\s+|google\\s+)?(excel|word|sheets?|outlook|vba)\\b(?!\\s+(files?|documents?|attachments?|settings?|options|reviews?|risks?|security|threats?|malware|viruses))",
    "\\b(write|create|generate|develop|build|make|give|provide|share|need|want)\\s+(me\\s+|us\\s+)?((a|an|the|some|this|that|small|simple|short|sample|quick|full|complete|working|new|basic)\\s+){0,3}programs?\\s+(in|using|with)\\s+(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\b(?!\\s+server)"
  ],
  "reviewPatterns": [
    "\\b(create|write|generate|give|make|build|develop|provide|prepare|need|want)\\s+(me\\s+|us\\s+)?((a|an|the|some|any|sample|simple|small|full|complete|working|new|my|our)\\s+){0,3}(codes?|macros?)\\b(?!-|\\s+of\\b)",
    "\\binstall(ation|ing)?\\s+(of\\s+)?((a|an|the|new|latest)\\s+)?(software|windows|python|office|ms\\s+office|drivers?|apps?)\\b",
    "\\bscripts?\\s+(to|that|which)\\s+(automat(e|es)|renames?|cop(y|ies)|moves?|deletes?|downloads?|scrapes?|extracts?|runs?|execut(e|es)|installs?|updates?|monitors?|backs?\\s+up)\\b"
  ],
  "noCode": true,
  "allowFormulas": true,
  "exports": [
    "docx",
    "pdf",
    "xlsx",
    "pptx",
    "chart",
    "diagram",
    "email"
  ],
  "refusal": "This is outside the Warehouse / Stores domain, so I can’t help with it here. {suggestion}",
  "examplesIn": [
    "Create a daily cold-room temperature logsheet with alert limits."
  ],
  "examplesOut": [
    "Negotiate a better price with the RM supplier."
  ]
}$pai$::jsonb, true),
  ('ENG', '1.0.1', $pai${
  "id": "ENG",
  "version": "1.0.1",
  "name": "Engineering, Maintenance & Projects",
  "group": "Manufacturing Plant",
  "icon": "engineering",
  "tier": "premium",
  "dailyTokens": 150000,
  "maxOutputTokens": 4096,
  "fileMaxOutputTokens": 8192,
  "temperature": 0.3,
  "sortOrder": 13,
  "users": "Maintenance, utilities, instrumentation, automation, projects and calibration teams",
  "inScope": [
    "Equipment troubleshooting (pumps, motors, compressors, chillers, boilers, AHUs, RO plants)",
    "Preventive maintenance plans and checklists, breakdown RCA (why-why, fishbone), spare lists",
    "Engineering calculations: pump head / NPSH, heat load, air changes, pipe sizing, pressure drop, Reynolds number, chemical dosing",
    "Datasheets, specifications, URS for new equipment, project schedules and BOQs",
    "Automation: control philosophy, I/O lists, interlock and alarm tables (no program code)",
    "Qualification support with Validation, energy saving, statutory awareness (boilers, pressure vessels), manuals and SOPs, how to design an equipment item"
  ],
  "outScope": [
    "Software installation guides",
    "Writing program code, including PLC / SCADA code",
    "IT network problems (→ IT)",
    "HR or purchase negotiation topics"
  ],
  "specialRules": "Safety first (LOTO, permits). Show formulas and assumptions. Manufacturer contacts only if known and marked “verify before use”.",
  "blockPatterns": [
    "((^|[^\\w\\s])\\s*|\\b(?!(contains?|containing|contained|embedded|existing|legacy|restores?|restoring|restored|recovers?|recovering|recovered|validates?|validating|validated|backup|up|archives?|archiving|archived|retrieves?|retrieving|retrieved)\\s)(?!(the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s)\\w+\\s+)((the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s+){0,2}(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\s+(codes?|scripts?|programs?|macros?|quer(y|ies)|functions?|snippets?|modules?|subroutines?)\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))",
    "\\b(codes?|scripts?|macros?|quer(y|ies))\\s+((in|using|with)\\s+((a|an|the)\\s+)?|for\\s+(a|an)\\s+)(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\b(?!\\s+server)",
    "((^|[^\\w\\s])\\s*|\\b(?!(contains?|containing|contained|embedded|existing|legacy|restores?|restoring|restored|recovers?|recovering|recovered|validates?|validating|validated|backup|up|archives?|archiving|archived|retrieves?|retrieving|retrieved)\\s)(?!(the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s)\\w+\\s+)((the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s+){0,2}(plc|scada|source|program)\\s+codes?\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))(?![^.;?!\\n]{0,80}\\b(was|were|is|are|got|gets|has\\s+been|have\\s+been|had\\s+been)\\s+(lost|deleted|corrupted|erased|wiped|missing|overwritten|damaged)\\b)",
    "\\b(shell|batch|cmd|automation|apps)\\s+scripts?\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))",
    "\\b(macro\\s+(for|to|in|using)|macros\\s+(for|to|using))\\s+(ms\\s+|microsoft\\s+|google\\s+)?(excel|word|sheets?|outlook|vba)\\b(?!\\s+(files?|documents?|attachments?|settings?|options|reviews?|risks?|security|threats?|malware|viruses))",
    "\\b(write|create|generate|develop|build|make|give|provide|share|need|want)\\s+(me\\s+|us\\s+)?((a|an|the|some|this|that|small|simple|short|sample|quick|full|complete|working|new|basic)\\s+){0,3}programs?\\s+(in|using|with)\\s+(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\b(?!\\s+server)"
  ],
  "reviewPatterns": [
    "\\b(create|write|generate|give|make|build|develop|provide|prepare|need|want)\\s+(me\\s+|us\\s+)?((a|an|the|some|any|sample|simple|small|full|complete|working|new|my|our)\\s+){0,3}(codes?|macros?)\\b(?!-|\\s+of\\b)",
    "\\binstall(ation|ing)?\\s+(of\\s+)?((a|an|the|new|latest)\\s+)?(software|windows|python|office|ms\\s+office|drivers?|apps?)\\b",
    "\\bscripts?\\s+(to|that|which)\\s+(automat(e|es)|renames?|cop(y|ies)|moves?|deletes?|downloads?|scrapes?|extracts?|runs?|execut(e|es)|installs?|updates?|monitors?|backs?\\s+up)\\b"
  ],
  "noCode": true,
  "allowFormulas": true,
  "exports": [
    "docx",
    "pdf",
    "xlsx",
    "pptx",
    "chart",
    "diagram",
    "email"
  ],
  "refusal": "This is outside the Engineering, Maintenance & Projects domain, so I can’t help with it here. {suggestion}",
  "examplesIn": [
    "How to check and troubleshoot a centrifugal pump that is losing flow? Give a PM checklist."
  ],
  "examplesOut": [
    "Generate code for a Python dashboard of pump data."
  ]
}$pai$::jsonb, true),
  ('EHS', '1.0.1', $pai${
  "id": "EHS",
  "version": "1.0.1",
  "name": "EHS / Safety",
  "group": "Manufacturing Plant",
  "icon": "health_and_safety",
  "tier": "standard",
  "dailyTokens": 100000,
  "maxOutputTokens": 3072,
  "fileMaxOutputTokens": 8192,
  "temperature": 0.3,
  "sortOrder": 14,
  "users": "Safety officers, environment officers, occupational health administrators",
  "inScope": [
    "Safety rules and policies (for example a plan to build new safety rules)",
    "HIRA / JSA, permit-to-work, LOTO, PPE selection and comparison of safety equipment",
    "Fire safety, emergency plans, mock drills, incident / near-miss investigation formats",
    "Chemical safety (SDS, GHS labels), hazardous waste, effluent and emission parameters",
    "Safety training content, audits and checklists, statutory awareness (Factories Act, SPCB / CPCB consents)"
  ],
  "outScope": [
    "Price comparison of products other than safety equipment",
    "Code",
    "HR disputes"
  ],
  "specialRules": "In a real emergency, tell the user to follow the site emergency plan and call emergency services first.",
  "blockPatterns": [
    "((^|[^\\w\\s])\\s*|\\b(?!(contains?|containing|contained|embedded|existing|legacy|restores?|restoring|restored|recovers?|recovering|recovered|validates?|validating|validated|backup|up|archives?|archiving|archived|retrieves?|retrieving|retrieved)\\s)(?!(the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s)\\w+\\s+)((the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s+){0,2}(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\s+(codes?|scripts?|programs?|macros?|quer(y|ies)|functions?|snippets?|modules?|subroutines?)\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))",
    "\\b(codes?|scripts?|macros?|quer(y|ies))\\s+((in|using|with)\\s+((a|an|the)\\s+)?|for\\s+(a|an)\\s+)(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\b(?!\\s+server)",
    "((^|[^\\w\\s])\\s*|\\b(?!(contains?|containing|contained|embedded|existing|legacy|restores?|restoring|restored|recovers?|recovering|recovered|validates?|validating|validated|backup|up|archives?|archiving|archived|retrieves?|retrieving|retrieved)\\s)(?!(the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s)\\w+\\s+)((the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s+){0,2}(plc|scada|source|program)\\s+codes?\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))(?![^.;?!\\n]{0,80}\\b(was|were|is|are|got|gets|has\\s+been|have\\s+been|had\\s+been)\\s+(lost|deleted|corrupted|erased|wiped|missing|overwritten|damaged)\\b)",
    "\\b(shell|batch|cmd|automation|apps)\\s+scripts?\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))",
    "\\b(macro\\s+(for|to|in|using)|macros\\s+(for|to|using))\\s+(ms\\s+|microsoft\\s+|google\\s+)?(excel|word|sheets?|outlook|vba)\\b(?!\\s+(files?|documents?|attachments?|settings?|options|reviews?|risks?|security|threats?|malware|viruses))",
    "\\b(write|create|generate|develop|build|make|give|provide|share|need|want)\\s+(me\\s+|us\\s+)?((a|an|the|some|this|that|small|simple|short|sample|quick|full|complete|working|new|basic)\\s+){0,3}programs?\\s+(in|using|with)\\s+(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\b(?!\\s+server)"
  ],
  "reviewPatterns": [
    "\\b(create|write|generate|give|make|build|develop|provide|prepare|need|want)\\s+(me\\s+|us\\s+)?((a|an|the|some|any|sample|simple|small|full|complete|working|new|my|our)\\s+){0,3}(codes?|macros?)\\b(?!-|\\s+of\\b)",
    "\\binstall(ation|ing)?\\s+(of\\s+)?((a|an|the|new|latest)\\s+)?(software|windows|python|office|ms\\s+office|drivers?|apps?)\\b",
    "\\bscripts?\\s+(to|that|which)\\s+(automat(e|es)|renames?|cop(y|ies)|moves?|deletes?|downloads?|scrapes?|extracts?|runs?|execut(e|es)|installs?|updates?|monitors?|backs?\\s+up)\\b"
  ],
  "noCode": true,
  "allowFormulas": true,
  "exports": [
    "docx",
    "pdf",
    "xlsx",
    "pptx",
    "chart",
    "diagram",
    "email"
  ],
  "refusal": "This is outside the EHS / Safety domain, so I can’t help with it here. {suggestion}",
  "examplesIn": [
    "Make a plan to introduce new safety rules for the solvent storage area."
  ],
  "examplesOut": [
    "Compare prices of two laptops for my office."
  ]
}$pai$::jsonb, true),
  ('FAC', '1.0.1', $pai${
  "id": "FAC",
  "version": "1.0.1",
  "name": "Facility Management",
  "group": "Manufacturing Plant",
  "icon": "apartment",
  "tier": "economy",
  "dailyTokens": 50000,
  "maxOutputTokens": 2048,
  "fileMaxOutputTokens": 8192,
  "temperature": 0.3,
  "sortOrder": 15,
  "users": "Facility and general administration staff",
  "inScope": [
    "Building maintenance schedules and AMC tracking",
    "Space planning, guest house, transport / fleet administration",
    "Non-GMP utilities consumption tracking, landscaping, facility service vendors",
    "Facility SOPs and checklists"
  ],
  "outScope": [
    "GMP engineering changes (→ Engineering)",
    "Code"
  ],
  "specialRules": "Economy model by default (per your cost-saving rule).",
  "blockPatterns": [
    "((^|[^\\w\\s])\\s*|\\b(?!(contains?|containing|contained|embedded|existing|legacy|restores?|restoring|restored|recovers?|recovering|recovered|validates?|validating|validated|backup|up|archives?|archiving|archived|retrieves?|retrieving|retrieved)\\s)(?!(the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s)\\w+\\s+)((the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s+){0,2}(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\s+(codes?|scripts?|programs?|macros?|quer(y|ies)|functions?|snippets?|modules?|subroutines?)\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))",
    "\\b(codes?|scripts?|macros?|quer(y|ies))\\s+((in|using|with)\\s+((a|an|the)\\s+)?|for\\s+(a|an)\\s+)(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\b(?!\\s+server)",
    "((^|[^\\w\\s])\\s*|\\b(?!(contains?|containing|contained|embedded|existing|legacy|restores?|restoring|restored|recovers?|recovering|recovered|validates?|validating|validated|backup|up|archives?|archiving|archived|retrieves?|retrieving|retrieved)\\s)(?!(the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s)\\w+\\s+)((the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s+){0,2}(plc|scada|source|program)\\s+codes?\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))(?![^.;?!\\n]{0,80}\\b(was|were|is|are|got|gets|has\\s+been|have\\s+been|had\\s+been)\\s+(lost|deleted|corrupted|erased|wiped|missing|overwritten|damaged)\\b)",
    "\\b(shell|batch|cmd|automation|apps)\\s+scripts?\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))",
    "\\b(macro\\s+(for|to|in|using)|macros\\s+(for|to|using))\\s+(ms\\s+|microsoft\\s+|google\\s+)?(excel|word|sheets?|outlook|vba)\\b(?!\\s+(files?|documents?|attachments?|settings?|options|reviews?|risks?|security|threats?|malware|viruses))",
    "\\b(write|create|generate|develop|build|make|give|provide|share|need|want)\\s+(me\\s+|us\\s+)?((a|an|the|some|this|that|small|simple|short|sample|quick|full|complete|working|new|basic)\\s+){0,3}programs?\\s+(in|using|with)\\s+(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\b(?!\\s+server)"
  ],
  "reviewPatterns": [
    "\\b(create|write|generate|give|make|build|develop|provide|prepare|need|want)\\s+(me\\s+|us\\s+)?((a|an|the|some|any|sample|simple|small|full|complete|working|new|my|our)\\s+){0,3}(codes?|macros?)\\b(?!-|\\s+of\\b)",
    "\\binstall(ation|ing)?\\s+(of\\s+)?((a|an|the|new|latest)\\s+)?(software|windows|python|office|ms\\s+office|drivers?|apps?)\\b",
    "\\bscripts?\\s+(to|that|which)\\s+(automat(e|es)|renames?|cop(y|ies)|moves?|deletes?|downloads?|scrapes?|extracts?|runs?|execut(e|es)|installs?|updates?|monitors?|backs?\\s+up)\\b"
  ],
  "noCode": true,
  "allowFormulas": true,
  "exports": [
    "docx",
    "pdf",
    "xlsx",
    "pptx",
    "chart",
    "diagram",
    "email"
  ],
  "refusal": "This is outside the Facility Management domain, so I can’t help with it here. {suggestion}",
  "examplesIn": [
    "Create an AMC tracker in Excel for lifts, DG sets and fire systems."
  ],
  "examplesOut": [
    "Write a legal notice to a contractor."
  ]
}$pai$::jsonb, true),
  ('SEC', '1.0.1', $pai${
  "id": "SEC",
  "version": "1.0.1",
  "name": "Security",
  "group": "Common (Office & Plant)",
  "icon": "security",
  "tier": "economy",
  "dailyTokens": 50000,
  "maxOutputTokens": 2048,
  "fileMaxOutputTokens": 8192,
  "temperature": 0.3,
  "sortOrder": 16,
  "users": "Security supervisors and guards (through supervisors)",
  "inScope": [
    "Site access control, visitor management, gate passes and vehicle checks",
    "Patrolling schedules, CCTV monitoring procedures (non-technical), key management",
    "Incident reporting and emergency-response coordination, guard training content"
  ],
  "outScope": [
    "Hacking or cyber-attack techniques",
    "Code",
    "Surveillance of individuals beyond company policy"
  ],
  "specialRules": "Economy model by default.",
  "blockPatterns": [
    "((^|[^\\w\\s])\\s*|\\b(?!(contains?|containing|contained|embedded|existing|legacy|restores?|restoring|restored|recovers?|recovering|recovered|validates?|validating|validated|backup|up|archives?|archiving|archived|retrieves?|retrieving|retrieved)\\s)(?!(the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s)\\w+\\s+)((the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s+){0,2}(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\s+(codes?|scripts?|programs?|macros?|quer(y|ies)|functions?|snippets?|modules?|subroutines?)\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))",
    "\\b(codes?|scripts?|macros?|quer(y|ies))\\s+((in|using|with)\\s+((a|an|the)\\s+)?|for\\s+(a|an)\\s+)(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\b(?!\\s+server)",
    "((^|[^\\w\\s])\\s*|\\b(?!(contains?|containing|contained|embedded|existing|legacy|restores?|restoring|restored|recovers?|recovering|recovered|validates?|validating|validated|backup|up|archives?|archiving|archived|retrieves?|retrieving|retrieved)\\s)(?!(the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s)\\w+\\s+)((the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s+){0,2}(plc|scada|source|program)\\s+codes?\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))(?![^.;?!\\n]{0,80}\\b(was|were|is|are|got|gets|has\\s+been|have\\s+been|had\\s+been)\\s+(lost|deleted|corrupted|erased|wiped|missing|overwritten|damaged)\\b)",
    "\\b(shell|batch|cmd|automation|apps)\\s+scripts?\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))",
    "\\b(macro\\s+(for|to|in|using)|macros\\s+(for|to|using))\\s+(ms\\s+|microsoft\\s+|google\\s+)?(excel|word|sheets?|outlook|vba)\\b(?!\\s+(files?|documents?|attachments?|settings?|options|reviews?|risks?|security|threats?|malware|viruses))",
    "\\b(write|create|generate|develop|build|make|give|provide|share|need|want)\\s+(me\\s+|us\\s+)?((a|an|the|some|this|that|small|simple|short|sample|quick|full|complete|working|new|basic)\\s+){0,3}programs?\\s+(in|using|with)\\s+(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\b(?!\\s+server)"
  ],
  "reviewPatterns": [
    "\\b(create|write|generate|give|make|build|develop|provide|prepare|need|want)\\s+(me\\s+|us\\s+)?((a|an|the|some|any|sample|simple|small|full|complete|working|new|my|our)\\s+){0,3}(codes?|macros?)\\b(?!-|\\s+of\\b)",
    "\\binstall(ation|ing)?\\s+(of\\s+)?((a|an|the|new|latest)\\s+)?(software|windows|python|office|ms\\s+office|drivers?|apps?)\\b",
    "\\bscripts?\\s+(to|that|which)\\s+(automat(e|es)|renames?|cop(y|ies)|moves?|deletes?|downloads?|scrapes?|extracts?|runs?|execut(e|es)|installs?|updates?|monitors?|backs?\\s+up)\\b"
  ],
  "noCode": true,
  "allowFormulas": true,
  "exports": [
    "docx",
    "pdf",
    "xlsx",
    "pptx",
    "chart",
    "diagram",
    "email"
  ],
  "refusal": "This is outside the Security domain, so I can’t help with it here. {suggestion}",
  "examplesIn": [
    "Draft a visitor-entry procedure for the manufacturing block."
  ],
  "examplesOut": [
    "How to break into a locked Wi-Fi network?"
  ]
}$pai$::jsonb, true),
  ('ITS', '1.0.1', $pai${
  "id": "ITS",
  "version": "1.0.1",
  "name": "IT",
  "group": "Common (Office & Plant)",
  "icon": "computer",
  "tier": "standard",
  "dailyTokens": 100000,
  "maxOutputTokens": 3072,
  "fileMaxOutputTokens": 8192,
  "temperature": 0.3,
  "sortOrder": 17,
  "users": "IT support and IT compliance staff",
  "inScope": [
    "User support procedures and device troubleshooting steps (printers, Windows, network basics)",
    "IT SOPs: backup, patching, access review, incident handling, asset management (ITIL)",
    "IT compliance: 21 CFR Part 11 / Annex 11 concepts, audit-trail review procedures, CSV documents (non-code)",
    "Cyber-security awareness content and IT vendor management"
  ],
  "outScope": [
    "Generating any code: programs, PowerShell / batch scripts, SQL, macros",
    "Business growth strategy",
    "Hacking"
  ],
  "specialRules": "Your rule: pharma companies do not ask IT staff to generate code, so the IT domain never writes code — it explains steps using approved tools instead.",
  "blockPatterns": [
    "((^|[^\\w\\s])\\s*|\\b(?!(contains?|containing|contained|embedded|existing|legacy|restores?|restoring|restored|recovers?|recovering|recovered|validates?|validating|validated|backup|up|archives?|archiving|archived|retrieves?|retrieving|retrieved)\\s)(?!(the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s)\\w+\\s+)((the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s+){0,2}(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\s+(codes?|scripts?|programs?|macros?|quer(y|ies)|functions?|snippets?|modules?|subroutines?)\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))",
    "\\b(codes?|scripts?|macros?|quer(y|ies))\\s+((in|using|with)\\s+((a|an|the)\\s+)?|for\\s+(a|an)\\s+)(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\b(?!\\s+server)",
    "((^|[^\\w\\s])\\s*|\\b(?!(contains?|containing|contained|embedded|existing|legacy|restores?|restoring|restored|recovers?|recovering|recovered|validates?|validating|validated|backup|up|archives?|archiving|archived|retrieves?|retrieving|retrieved)\\s)(?!(the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s)\\w+\\s+)((the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s+){0,2}(plc|scada|source|program)\\s+codes?\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))(?![^.;?!\\n]{0,80}\\b(was|were|is|are|got|gets|has\\s+been|have\\s+been|had\\s+been)\\s+(lost|deleted|corrupted|erased|wiped|missing|overwritten|damaged)\\b)",
    "\\b(shell|batch|cmd|automation|apps)\\s+scripts?\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))",
    "\\b(macro\\s+(for|to|in|using)|macros\\s+(for|to|using))\\s+(ms\\s+|microsoft\\s+|google\\s+)?(excel|word|sheets?|outlook|vba)\\b(?!\\s+(files?|documents?|attachments?|settings?|options|reviews?|risks?|security|threats?|malware|viruses))",
    "\\b(write|create|generate|develop|build|make|give|provide|share|need|want)\\s+(me\\s+|us\\s+)?((a|an|the|some|this|that|small|simple|short|sample|quick|full|complete|working|new|basic)\\s+){0,3}programs?\\s+(in|using|with)\\s+(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\b(?!\\s+server)"
  ],
  "reviewPatterns": [
    "\\b(create|write|generate|give|make|build|develop|provide|prepare|need|want)\\s+(me\\s+|us\\s+)?((a|an|the|some|any|sample|simple|small|full|complete|working|new|my|our)\\s+){0,3}(codes?|macros?)\\b(?!-|\\s+of\\b)",
    "\\binstall(ation|ing)?\\s+(of\\s+)?((a|an|the|new|latest)\\s+)?(software|windows|python|office|ms\\s+office|drivers?|apps?)\\b",
    "\\bscripts?\\s+(to|that|which)\\s+(automat(e|es)|renames?|cop(y|ies)|moves?|deletes?|downloads?|scrapes?|extracts?|runs?|execut(e|es)|installs?|updates?|monitors?|backs?\\s+up)\\b"
  ],
  "noCode": true,
  "allowFormulas": true,
  "exports": [
    "docx",
    "pdf",
    "xlsx",
    "pptx",
    "chart",
    "diagram",
    "email"
  ],
  "refusal": "This is outside the IT domain, so I can’t help with it here. {suggestion}",
  "examplesIn": [
    "Write an SOP for monthly user-access review of the LIMS."
  ],
  "examplesOut": [
    "Give me suggestions to develop our business."
  ]
}$pai$::jsonb, true),
  ('HKP', '1.0.1', $pai${
  "id": "HKP",
  "version": "1.0.1",
  "name": "Housekeeping",
  "group": "Common (Office & Plant)",
  "icon": "cleaning_services",
  "tier": "economy",
  "dailyTokens": 50000,
  "maxOutputTokens": 2048,
  "fileMaxOutputTokens": 8192,
  "temperature": 0.3,
  "sortOrder": 18,
  "users": "Housekeeping supervisors",
  "inScope": [
    "Cleaning schedules and checklists, manpower rosters",
    "Cleaning agent dilution for general areas (GMP areas follow approved SOPs)",
    "Waste segregation, washroom hygiene, laundry procedures, training content"
  ],
  "outScope": [
    "Changing GMP cleaning / disinfectant SOPs (→ QA)",
    "Code"
  ],
  "specialRules": "Economy model by default.",
  "blockPatterns": [
    "((^|[^\\w\\s])\\s*|\\b(?!(contains?|containing|contained|embedded|existing|legacy|restores?|restoring|restored|recovers?|recovering|recovered|validates?|validating|validated|backup|up|archives?|archiving|archived|retrieves?|retrieving|retrieved)\\s)(?!(the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s)\\w+\\s+)((the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s+){0,2}(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\s+(codes?|scripts?|programs?|macros?|quer(y|ies)|functions?|snippets?|modules?|subroutines?)\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))",
    "\\b(codes?|scripts?|macros?|quer(y|ies))\\s+((in|using|with)\\s+((a|an|the)\\s+)?|for\\s+(a|an)\\s+)(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\b(?!\\s+server)",
    "((^|[^\\w\\s])\\s*|\\b(?!(contains?|containing|contained|embedded|existing|legacy|restores?|restoring|restored|recovers?|recovering|recovered|validates?|validating|validated|backup|up|archives?|archiving|archived|retrieves?|retrieving|retrieved)\\s)(?!(the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s)\\w+\\s+)((the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s+){0,2}(plc|scada|source|program)\\s+codes?\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))(?![^.;?!\\n]{0,80}\\b(was|were|is|are|got|gets|has\\s+been|have\\s+been|had\\s+been)\\s+(lost|deleted|corrupted|erased|wiped|missing|overwritten|damaged)\\b)",
    "\\b(shell|batch|cmd|automation|apps)\\s+scripts?\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))",
    "\\b(macro\\s+(for|to|in|using)|macros\\s+(for|to|using))\\s+(ms\\s+|microsoft\\s+|google\\s+)?(excel|word|sheets?|outlook|vba)\\b(?!\\s+(files?|documents?|attachments?|settings?|options|reviews?|risks?|security|threats?|malware|viruses))",
    "\\b(write|create|generate|develop|build|make|give|provide|share|need|want)\\s+(me\\s+|us\\s+)?((a|an|the|some|this|that|small|simple|short|sample|quick|full|complete|working|new|basic)\\s+){0,3}programs?\\s+(in|using|with)\\s+(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\b(?!\\s+server)"
  ],
  "reviewPatterns": [
    "\\b(create|write|generate|give|make|build|develop|provide|prepare|need|want)\\s+(me\\s+|us\\s+)?((a|an|the|some|any|sample|simple|small|full|complete|working|new|my|our)\\s+){0,3}(codes?|macros?)\\b(?!-|\\s+of\\b)",
    "\\binstall(ation|ing)?\\s+(of\\s+)?((a|an|the|new|latest)\\s+)?(software|windows|python|office|ms\\s+office|drivers?|apps?)\\b",
    "\\bscripts?\\s+(to|that|which)\\s+(automat(e|es)|renames?|cop(y|ies)|moves?|deletes?|downloads?|scrapes?|extracts?|runs?|execut(e|es)|installs?|updates?|monitors?|backs?\\s+up)\\b"
  ],
  "noCode": true,
  "allowFormulas": true,
  "exports": [
    "docx",
    "pdf",
    "xlsx",
    "pptx",
    "chart",
    "diagram",
    "email"
  ],
  "refusal": "This is outside the Housekeeping domain, so I can’t help with it here. {suggestion}",
  "examplesIn": [
    "Make a weekly cleaning schedule for the admin block."
  ],
  "examplesOut": [
    "Explain HPLC column selection."
  ]
}$pai$::jsonb, true),
  ('CAN', '1.0.1', $pai${
  "id": "CAN",
  "version": "1.0.1",
  "name": "Canteen",
  "group": "Common (Office & Plant)",
  "icon": "restaurant",
  "tier": "economy",
  "dailyTokens": 50000,
  "maxOutputTokens": 2048,
  "fileMaxOutputTokens": 8192,
  "temperature": 0.3,
  "sortOrder": 19,
  "users": "Canteen managers and contractors (through supervisor)",
  "inScope": [
    "Menu planning and cost per plate",
    "Food safety and hygiene practices (FSSAI good hygiene), kitchen cleaning schedules",
    "Raw material checks, food-handler hygiene rules, pest control in kitchen",
    "Feedback forms and canteen committee minutes"
  ],
  "outScope": [
    "Individual medical diet prescriptions",
    "Code"
  ],
  "specialRules": "Economy model by default (per your cost-saving example).",
  "blockPatterns": [
    "((^|[^\\w\\s])\\s*|\\b(?!(contains?|containing|contained|embedded|existing|legacy|restores?|restoring|restored|recovers?|recovering|recovered|validates?|validating|validated|backup|up|archives?|archiving|archived|retrieves?|retrieving|retrieved)\\s)(?!(the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s)\\w+\\s+)((the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s+){0,2}(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\s+(codes?|scripts?|programs?|macros?|quer(y|ies)|functions?|snippets?|modules?|subroutines?)\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))",
    "\\b(codes?|scripts?|macros?|quer(y|ies))\\s+((in|using|with)\\s+((a|an|the)\\s+)?|for\\s+(a|an)\\s+)(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\b(?!\\s+server)",
    "((^|[^\\w\\s])\\s*|\\b(?!(contains?|containing|contained|embedded|existing|legacy|restores?|restoring|restored|recovers?|recovering|recovered|validates?|validating|validated|backup|up|archives?|archiving|archived|retrieves?|retrieving|retrieved)\\s)(?!(the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s)\\w+\\s+)((the|a|an|any|some|many|all|these|those|this|that|its|their|our|such)\\s+){0,2}(plc|scada|source|program)\\s+codes?\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))(?![^.;?!\\n]{0,80}\\b(was|were|is|are|got|gets|has\\s+been|have\\s+been|had\\s+been)\\s+(lost|deleted|corrupted|erased|wiped|missing|overwritten|damaged)\\b)",
    "\\b(shell|batch|cmd|automation|apps)\\s+scripts?\\b(?!\\s+(reviews?|audits?|escrow|backups?|version\\s+control|versioning|management|risks?|security|threats?|malware|viruses))",
    "\\b(macro\\s+(for|to|in|using)|macros\\s+(for|to|using))\\s+(ms\\s+|microsoft\\s+|google\\s+)?(excel|word|sheets?|outlook|vba)\\b(?!\\s+(files?|documents?|attachments?|settings?|options|reviews?|risks?|security|threats?|malware|viruses))",
    "\\b(write|create|generate|develop|build|make|give|provide|share|need|want)\\s+(me\\s+|us\\s+)?((a|an|the|some|this|that|small|simple|short|sample|quick|full|complete|working|new|basic)\\s+){0,3}programs?\\s+(in|using|with)\\s+(python|javascript|typescript|java|kotlin|c\\+\\+|c#|vb\\.net|vbscript|vba|powershell|bash|sql|php|ruby|perl|golang|matlab|ladder logic|structured text)\\b(?!\\s+server)"
  ],
  "reviewPatterns": [
    "\\b(create|write|generate|give|make|build|develop|provide|prepare|need|want)\\s+(me\\s+|us\\s+)?((a|an|the|some|any|sample|simple|small|full|complete|working|new|my|our)\\s+){0,3}(codes?|macros?)\\b(?!-|\\s+of\\b)",
    "\\binstall(ation|ing)?\\s+(of\\s+)?((a|an|the|new|latest)\\s+)?(software|windows|python|office|ms\\s+office|drivers?|apps?)\\b",
    "\\bscripts?\\s+(to|that|which)\\s+(automat(e|es)|renames?|cop(y|ies)|moves?|deletes?|downloads?|scrapes?|extracts?|runs?|execut(e|es)|installs?|updates?|monitors?|backs?\\s+up)\\b"
  ],
  "noCode": true,
  "allowFormulas": true,
  "exports": [
    "docx",
    "pdf",
    "xlsx",
    "pptx",
    "chart",
    "diagram",
    "email"
  ],
  "refusal": "This is outside the Canteen domain, so I can’t help with it here. {suggestion}",
  "examplesIn": [
    "Plan a balanced 7-day menu for 300 employees within Rs 60 per meal."
  ],
  "examplesOut": [
    "Troubleshoot the chiller compressor trip."
  ]
}$pai$::jsonb, true)
on conflict (domain_id, version) do update set
  policy_json = excluded.policy_json,
  active = true;
update public.domain_policies as p
set active = false
from (
  values
    ('ADM', '1.0.1'),
    ('HR', '1.0.1'),
    ('FIN', '1.0.1'),
    ('SMB', '1.0.1'),
    ('PUR', '1.0.1'),
    ('SCM', '1.0.1'),
    ('PPC', '1.0.1'),
    ('LRA', '1.0.1'),
    ('PRD', '1.0.1'),
    ('QQV', '1.0.1'),
    ('RND', '1.0.1'),
    ('WHS', '1.0.1'),
    ('ENG', '1.0.1'),
    ('EHS', '1.0.1'),
    ('FAC', '1.0.1'),
    ('SEC', '1.0.1'),
    ('ITS', '1.0.1'),
    ('HKP', '1.0.1'),
    ('CAN', '1.0.1')
) as seeded (domain_id, version)
where p.domain_id = seeded.domain_id
  and p.version <> seeded.version
  and p.active;

update public.tenant_settings
set catalogue_version = '1.0.1'
where catalogue_version is distinct from '1.0.1';
