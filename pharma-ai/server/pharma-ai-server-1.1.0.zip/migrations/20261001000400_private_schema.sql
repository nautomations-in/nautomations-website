create schema if not exists private;

revoke all on schema private from public;
revoke all on schema private from anon, authenticated;
grant usage on schema private to service_role;
create table private.level2_secrets (
  user_id uuid primary key references public.profiles (id) on delete cascade,
  hash text not null,
  failed_count integer not null default 0 check (failed_count >= 0),
  locked boolean not null default false,
  updated_by uuid references public.profiles (id),
  updated_at timestamptz not null default now()
);

create index level2_secrets_updated_by_idx on private.level2_secrets (updated_by);
create table private.recovery_codes (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles (id) on delete cascade,
  code_hash text not null,
  used_at timestamptz,
  created_at timestamptz not null default now()
);

create index recovery_codes_user_id_idx on private.recovery_codes (user_id);
create unlogged table private.rate_limits (
  key text not null check (char_length(key) between 1 and 200),
  window_start timestamptz not null,
  count integer not null default 0 check (count >= 0),
  primary key (key, window_start)
);

create index rate_limits_window_start_idx on private.rate_limits (window_start);
create table private.login_tickets (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users (id) on delete cascade,
  device_id text not null check (device_id ~ '^[0-9a-f]{32}$'),
  created_at timestamptz not null default now(),
  expires_at timestamptz not null default (now() + interval '60 seconds'),
  used_at timestamptz
);
create index login_tickets_user_created_idx on private.login_tickets (user_id, created_at desc);
create index login_tickets_created_at_idx on private.login_tickets (created_at);
create table private.change_tickets (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users (id) on delete cascade,
  kind text not null check (kind in ('password', 'email')),
  created_by uuid references public.profiles (id),
  created_at timestamptz not null default now(),
  expires_at timestamptz not null default (now() + interval '60 seconds'),
  used_at timestamptz
);

create index change_tickets_user_kind_idx on private.change_tickets (user_id, kind, created_at desc);
create index change_tickets_created_at_idx on private.change_tickets (created_at);
create index change_tickets_created_by_idx on private.change_tickets (created_by);
create table private.session_devices (
  session_id uuid primary key,
  user_id uuid not null references auth.users (id) on delete cascade,
  device_id text not null check (device_id ~ '^[0-9a-f]{32}$'),
  created_at timestamptz not null default now()
);

create index session_devices_user_id_idx on private.session_devices (user_id);
create index session_devices_created_at_idx on private.session_devices (created_at);
create table private.used_nonces (
  nonce text primary key check (nonce ~ '^[A-Za-z0-9_-]{16,64}$'),
  created_at timestamptz not null default now()
);

create index used_nonces_created_at_idx on private.used_nonces (created_at);
create table private.config (
  key text primary key check (key ~ '^[a-z][a-z0-9_]{1,62}$'),
  value text not null
);

comment on table private.config is
  'Non-secret server configuration. Secrets belong in Vault, never here.';
grant select, insert, update, delete on all tables in schema private to service_role;
