do $$
declare
  v_name text;
begin
  for v_name in
    select c.conname
    from pg_constraint c
    where c.conrelid = 'public.tenant_settings'::regclass
      and c.contype = 'c'
      and pg_get_constraintdef(c.oid) like '%upload_max_mb%'
  loop
    execute format('alter table public.tenant_settings drop constraint %I', v_name);
  end loop;
end;
$$;
alter table public.tenant_settings
  add constraint tenant_settings_upload_max_mb_check check (upload_max_mb between 1 and 1024);
alter table public.tenant_settings alter column upload_max_mb set default 50;
update public.tenant_settings set upload_max_mb = 50 where upload_max_mb = 20;

comment on column public.tenant_settings.upload_max_mb is
  'Largest upload in MB (1-1024, default 50 = Supabase Free plan per-file maximum; the Admin sets it in A9 '
  'Security). A file must also fit the '
  'project''s Storage global file size limit: raise that limit first (paid plan) before setting more than 50.';
create function private.sync_uploads_bucket_limit()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  update storage.buckets
  set file_size_limit = new.upload_max_mb::bigint * 1048576
  where id = 'uploads'
    and file_size_limit is distinct from new.upload_max_mb::bigint * 1048576;
  return null;
end;
$$;

comment on function private.sync_uploads_bucket_limit() is
  'Trigger: keeps the uploads bucket''s file_size_limit equal to tenant_settings.upload_max_mb (in bytes).';
revoke execute on function private.sync_uploads_bucket_limit() from public, anon, authenticated, service_role;

create trigger tenant_settings_sync_uploads_bucket_limit
  after insert or update of upload_max_mb on public.tenant_settings
  for each row execute function private.sync_uploads_bucket_limit();
update storage.buckets
set file_size_limit = coalesce((select s.upload_max_mb from public.tenant_settings s limit 1), 50)::bigint * 1048576
where id = 'uploads';
alter table private.upload_tickets add column confirm_by timestamptz;
update private.upload_tickets
set confirm_by = expires_at
where prepared_at is not null
  and confirm_by is null
  and expires_at > prepared_at
  and expires_at <= prepared_at + interval '110 minutes';
alter table private.upload_tickets
  add constraint upload_tickets_confirm_by_check check (
    confirm_by is null
    or (prepared_at is not null and confirm_by > prepared_at
        and confirm_by <= prepared_at + interval '110 minutes')
  );

comment on column private.upload_tickets.confirm_by is
  'Set by register-upload prepare: the prepared upload must be confirmed before this time (prepare + 5 minutes '
  '+ 1 minute per 10 MB, at most 110 minutes; packages/shared uploadConfirmWindowSeconds).';
comment on table private.upload_tickets is
  'Level-2 upload tokens (CONTRACTS 16 / 17): SHA-256 only, 5 minutes to start ONE upload, then until confirm_by '
  'for that prepared upload only; bound to user and PC. Edge Functions only; removed by private.cleanup_expired() '
  '(unconfirmed objects first through private.upload_orphans).';
create or replace function private.upload_ticket_prepare(
  p_token_sha256 text,
  p_user_id uuid,
  p_device_id text,
  p_upload_id uuid,
  p_storage_path text,
  p_file_name text,
  p_mime_type text,
  p_size_bytes bigint,
  p_sha256 text
)
returns boolean
language plpgsql
set search_path = ''
as $$
begin
  update private.upload_tickets t
  set prepared_at = now(), upload_id = p_upload_id, storage_path = p_storage_path, file_name = p_file_name,
      mime_type = p_mime_type, size_bytes = p_size_bytes, sha256 = p_sha256,
      confirm_by = now() + least(
        interval '110 minutes',
        interval '5 minutes' + make_interval(secs => p_size_bytes::double precision * 6 / 1048576)
      )
  where t.token_sha256 = p_token_sha256
    and t.user_id = p_user_id
    and t.device_id = p_device_id
    and t.used_at is null
    and t.prepared_at is null
    and t.expires_at > now()
    and not exists (select 1 from private.level2_secrets s where s.user_id = t.user_id and s.locked);
  return found;
end;
$$;
alter table private.upload_tickets
  add column verified_bytes bigint not null default 0,
  add column verify_state text,
  add column verified_at timestamptz;
alter table private.upload_tickets
  add constraint upload_tickets_verify_state_check
    check (verify_state is null or verify_state ~ '^[0-9a-f]{64}$'),
  add constraint upload_tickets_verify_check check (
    (verified_bytes = 0 and verify_state is null and verified_at is null)
    or (prepared_at is not null and verified_at is null and verify_state is not null
        and verified_bytes > 0 and verified_bytes < size_bytes and verified_bytes % 64 = 0)
    or (prepared_at is not null and verified_at is not null and verify_state is null
        and verified_bytes = size_bytes)
  );

comment on column private.upload_tickets.verified_bytes is
  'register-upload verify: bytes of the stored object hashed so far (whole object once verified_at is set).';
comment on column private.upload_tickets.verify_state is
  'register-upload verify: SHA-256 state (8 words, hex) after verified_bytes; NULL before the first slice and once verified.';
comment on column private.upload_tickets.verified_at is
  'register-upload: the stored object matched the prepared size and SHA-256 and passed the content check.';
alter table private.upload_tickets add column verify_lease_until timestamptz;
comment on column private.upload_tickets.verify_lease_until is
  'register-upload verify / confirm: a call re-checks the next slice until this time; other calls meanwhile '
  'answer the saved progress without reading Storage (private.upload_ticket_verify_lease).';
create or replace function private.upload_ticket_check(p_token_sha256 text, p_user_id uuid, p_device_id text)
returns jsonb
language sql
stable
set search_path = ''
as $$
  select jsonb_build_object(
    'id', t.id,
    'expires_at', extract(epoch from t.expires_at)::bigint,
    'confirm_by', extract(epoch from t.confirm_by)::bigint,
    'prepared', t.prepared_at is not null,
    'upload_id', t.upload_id,
    'storage_path', t.storage_path,
    'file_name', t.file_name,
    'mime_type', t.mime_type,
    'size_bytes', t.size_bytes,
    'sha256', t.sha256,
    'verified_bytes', t.verified_bytes,
    'verify_state', t.verify_state,
    'verified', t.verified_at is not null
  )
  from private.upload_tickets t
  where t.token_sha256 = p_token_sha256
    and t.user_id = p_user_id
    and t.device_id = p_device_id
    and t.used_at is null
    and (case when t.prepared_at is null then t.expires_at else t.confirm_by end) > now()
    and not exists (select 1 from private.level2_secrets s where s.user_id = t.user_id and s.locked);
$$;
create function private.upload_ticket_verify_lease(
  p_token_sha256 text,
  p_user_id uuid,
  p_device_id text,
  p_upload_id uuid,
  p_from_bytes bigint,
  p_seconds integer
)
returns boolean
language plpgsql
set search_path = ''
as $$
begin
  if p_seconds is null or p_seconds < 1 or p_seconds > 300 then
    return false;
  end if;
  update private.upload_tickets t
  set verify_lease_until = now() + make_interval(secs => p_seconds)
  where t.token_sha256 = p_token_sha256
    and t.user_id = p_user_id
    and t.device_id = p_device_id
    and t.upload_id = p_upload_id
    and t.prepared_at is not null
    and t.used_at is null
    and t.verified_at is null
    and t.confirm_by > now()
    and t.verified_bytes = p_from_bytes
    and (t.verify_lease_until is null or t.verify_lease_until <= now())
    and not exists (select 1 from private.level2_secrets s where s.user_id = t.user_id and s.locked);
  return found;
end;
$$;
create function private.upload_ticket_verify_release(
  p_token_sha256 text,
  p_user_id uuid,
  p_device_id text,
  p_upload_id uuid
)
returns boolean
language plpgsql
set search_path = ''
as $$
begin
  update private.upload_tickets t
  set verify_lease_until = null
  where t.token_sha256 = p_token_sha256
    and t.user_id = p_user_id
    and t.device_id = p_device_id
    and t.upload_id = p_upload_id
    and t.verify_lease_until is not null;
  return found;
end;
$$;
create function private.upload_ticket_verify_save(
  p_token_sha256 text,
  p_user_id uuid,
  p_device_id text,
  p_upload_id uuid,
  p_from_bytes bigint,
  p_to_bytes bigint,
  p_state text
)
returns boolean
language plpgsql
set search_path = ''
as $$
begin
  update private.upload_tickets t
  set verified_bytes = p_to_bytes,
      verify_state = p_state,
      verified_at = case when p_state is null then now() end,
      verify_lease_until = null
  where t.token_sha256 = p_token_sha256
    and t.user_id = p_user_id
    and t.device_id = p_device_id
    and t.upload_id = p_upload_id
    and t.prepared_at is not null
    and t.used_at is null
    and t.verified_at is null
    and t.verified_bytes = p_from_bytes
    and p_to_bytes > p_from_bytes
    and p_to_bytes <= t.size_bytes
    and (p_state is null) = (p_to_bytes = t.size_bytes)
    and not exists (select 1 from private.level2_secrets s where s.user_id = t.user_id and s.locked);
  return found;
end;
$$;
create function private.upload_ticket_finish(
  p_token_sha256 text,
  p_user_id uuid,
  p_device_id text,
  p_upload_id uuid
)
returns boolean
language plpgsql
set search_path = ''
as $$
begin
  update private.upload_tickets t
  set used_at = now()
  where t.token_sha256 = p_token_sha256
    and t.user_id = p_user_id
    and t.device_id = p_device_id
    and t.upload_id = p_upload_id
    and t.verified_at is not null
    and t.used_at is null
    and not exists (select 1 from private.level2_secrets s where s.user_id = t.user_id and s.locked);
  return found;
end;
$$;
create function private.upload_ticket_recorded(
  p_token_sha256 text,
  p_user_id uuid,
  p_device_id text,
  p_upload_id uuid
)
returns jsonb
language sql
stable
set search_path = ''
as $$
  select jsonb_build_object(
    'id', u.id,
    'file_name', u.file_name,
    'mime_type', u.mime_type,
    'size_bytes', u.size_bytes,
    'sha256', u.sha256,
    'created_at', extract(epoch from u.created_at)::bigint
  )
  from private.upload_tickets t
  join public.upload_log u
    on u.id = t.upload_id
   and u.user_id = t.user_id
   and u.device_id = t.device_id
   and u.storage_path = t.storage_path
  where t.token_sha256 = p_token_sha256
    and t.user_id = p_user_id
    and t.device_id = p_device_id
    and t.upload_id = p_upload_id
    and t.used_at is not null
    and t.confirm_by > now()
    and not exists (select 1 from private.level2_secrets s where s.user_id = t.user_id and s.locked);
$$;

comment on function private.upload_ticket_recorded(text, uuid, text, uuid) is
  'register-upload confirm / verify: the upload_log record a used ticket''s confirm wrote, within its confirm window (a lost confirm answer is answered again). Edge Functions only.';
revoke execute on function private.upload_ticket_recorded(text, uuid, text, uuid)
  from public, anon, authenticated, service_role;
grant execute on function private.upload_ticket_recorded(text, uuid, text, uuid) to service_role;

comment on function private.upload_ticket_verify_lease(text, uuid, text, uuid, bigint, integer) is
  'register-upload verify / confirm: takes the re-check lease of a prepared ticket (one call at a time). Edge Functions only.';
comment on function private.upload_ticket_verify_release(text, uuid, text, uuid) is
  'register-upload verify / confirm: ends the re-check lease after a failed re-check. Edge Functions only.';
comment on function private.upload_ticket_verify_save(text, uuid, text, uuid, bigint, bigint, text) is
  'register-upload verify: saves the re-check progress of a prepared ticket (compare-and-set). Edge Functions only.';
comment on function private.upload_ticket_finish(text, uuid, text, uuid) is
  'register-upload confirm: marks a verified ticket used (first call only). Edge Functions only.';

revoke execute on function private.upload_ticket_verify_lease(text, uuid, text, uuid, bigint, integer)
  from public, anon, authenticated, service_role;
revoke execute on function private.upload_ticket_verify_release(text, uuid, text, uuid)
  from public, anon, authenticated, service_role;
revoke execute on function private.upload_ticket_verify_save(text, uuid, text, uuid, bigint, bigint, text)
  from public, anon, authenticated, service_role;
revoke execute on function private.upload_ticket_finish(text, uuid, text, uuid)
  from public, anon, authenticated, service_role;
grant execute on function private.upload_ticket_verify_lease(text, uuid, text, uuid, bigint, integer)
  to service_role;
grant execute on function private.upload_ticket_verify_release(text, uuid, text, uuid) to service_role;
grant execute on function private.upload_ticket_verify_save(text, uuid, text, uuid, bigint, bigint, text)
  to service_role;
grant execute on function private.upload_ticket_finish(text, uuid, text, uuid) to service_role;
