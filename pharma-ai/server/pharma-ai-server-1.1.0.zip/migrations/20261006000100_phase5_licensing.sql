create table public.offline_seat_requests (
  device_id text primary key check (device_id ~ '^[0-9a-f]{32}$'),
  licence_id text not null check (licence_id ~ '^lic_[a-z2-7]{20}$'),
  device_public_key text not null check (device_public_key ~ '^[A-Za-z0-9_-]{42}[AEIMQUYcgkosw048]$'),
  machine_hash text not null check (machine_hash ~ '^[0-9a-f]{64}$'),
  app_version text check (
    app_version is null or app_version ~ '^[0-9]{1,5}\.[0-9]{1,5}\.[0-9]{1,5}([-+][0-9A-Za-z.-]{1,40})?$'),
  device_name text check (
    device_name is null or (char_length(device_name) between 1 and 120 and device_name !~ '[\r\n]')),
  ts bigint check (ts is null or ts >= 0),
  proof text check (proof is null or proof ~ '^[A-Za-z0-9_-]{42}[AEIMQUYcgkosw048]$'),
  signature text check (signature is null or signature ~ '^[A-Za-z0-9_-]{85}[AQgw]$'),
  requested_at timestamptz not null default now(),
  exported_at timestamptz,
  status text not null default 'pending' check (status in ('pending', 'issued')),
  seat_certificate text check (
    seat_certificate is null
    or (char_length(seat_certificate) <= 8192 and seat_certificate ~ '^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$')),
  issued_at timestamptz,
  constraint offline_seat_requests_request_fields_check check (
    status = 'issued'
    or (ts is not null and proof is not null and signature is not null and device_name is not null
        and app_version is not null)),
  constraint offline_seat_requests_issued_check check (
    (status = 'issued') = (seat_certificate is not null) and (status = 'issued') = (issued_at is not null))
);
create index offline_seat_requests_status_idx on public.offline_seat_requests (status);

comment on table public.offline_seat_requests is
  'Offline seat requests of PCs and their signed certificates (CONTRACTS 33; LIC-13). Written only by the Edge '
  'Functions offline-seat and admin-licence; Administrators read them in A10.';
comment on column public.offline_seat_requests.device_name is
  'PC name shown in A10. Null (with ts, proof, signature, app_version) only on an issued row created by '
  'admin-licence offlineImport for a certificate without a request.';
comment on column public.offline_seat_requests.exported_at is
  'When admin-licence offlineExport last put this pending request into a seat request file.';
comment on column public.offline_seat_requests.seat_certificate is
  'CONTRACTS 3 seat certificate from a verified seat file (set exactly when status = issued); a later issuedAt wins.';

alter table public.offline_seat_requests enable row level security;

revoke all on table public.offline_seat_requests from public, anon, authenticated, service_role;
grant select on table public.offline_seat_requests to authenticated;
grant select, insert, update, delete on table public.offline_seat_requests to service_role;
create policy offline_seat_requests_select_admin on public.offline_seat_requests
  for select to authenticated using ((select public.is_admin()));
create function private.usage_report_counts(p_day date)
returns jsonb
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
  v_day_start timestamptz;
  v_day_end timestamptz;
  v_period_start timestamptz;
  v_result jsonb;
begin
  if p_day is null then
    raise exception 'A report day is required' using errcode = '22023';
  end if;
  v_day_start := p_day::timestamp at time zone 'Asia/Kolkata';
  v_day_end := (p_day + 1)::timestamp at time zone 'Asia/Kolkata';
  v_period_start := (p_day - 29)::timestamp at time zone 'Asia/Kolkata';

  with active_users as (
    select e.user_id, e.created_at
    from public.login_events e
    where e.event = 'success' and e.user_id is not null
      and e.created_at >= v_period_start and e.created_at < v_day_end
    union all
    select p.user_id, p.created_at
    from public.prompt_log p
    where p.created_at >= v_period_start and p.created_at < v_day_end
  ),
  active_devices as (
    select distinct e.device_id
    from public.login_events e
    where e.event = 'success' and e.device_id is not null
      and e.created_at >= v_period_start and e.created_at < v_day_end
      and not exists (
        select 1 from public.devices d where d.device_id = e.device_id and d.released_at is not null
      )
  )
  select jsonb_build_object(
    'activeUsers24h', (select count(distinct u.user_id) from active_users u where u.created_at >= v_day_start),
    'activeUsersPeriod', (select count(distinct u.user_id) from active_users u),
    'activeDevices', (select count(*) from active_devices),
    'versions', coalesce((
      select jsonb_object_agg(v.app_version, v.n)
      from (
        select d.app_version, count(*) as n
        from active_devices a
        join public.devices d on d.device_id = a.device_id
        where d.app_version ~ '^[0-9]{1,5}\.[0-9]{1,5}\.[0-9]{1,5}([-+][0-9A-Za-z.-]{1,40})?$'
        group by d.app_version
      ) v
    ), '{}'::jsonb),
    'catalogueVersion', (select s.catalogue_version from public.tenant_settings s)
  )
  into v_result;
  return v_result;
end;
$$;

comment on function private.usage_report_counts(date) is
  'Daily licence report counts for one IST day (CONTRACTS 32; LIC-02): activeUsers24h, activeUsersPeriod, '
  'activeDevices, versions, catalogueVersion - counts only. Edge Functions usage-report / admin-licence only.';

revoke execute on function private.usage_report_counts(date) from public, anon, authenticated, service_role;
grant execute on function private.usage_report_counts(date) to service_role;
comment on column public.tenant_settings.licence_token is
  'Verified tenant licence token (CONTRACTS 3). Replaced only by a verified token of the same licence and backend '
  'with a later issuedAt (usage-report, admin-licence refresh / offlineImport; first install by the onboarding SQL).';
comment on column public.tenant_settings.licence_status is
  'Licence Service status from the last daily report (active / paused / revoked); shown in A10 only - pause and '
  'revoke have no immediate effect on the company server (Phase 5 decision 16).';
comment on column public.tenant_settings.licence_updated_at is
  'When a newer verified licence token was last stored.';
comment on column public.tenant_settings.last_report_day is
  'Last IST day successfully reported by usage-report (CONTRACTS 32: missed days are back-filled, up to 30).';
comment on column public.tenant_settings.seat_plan is
  'Copy of the stored licence token''s plan, written with every newer token (CONTRACTS 31 "Stored licence token"). '
  'The verified token''s plan is authoritative for every check; this copy is for reading (A8 data export).';
comment on column public.devices.released_at is
  'Set by admin-licence release (CONTRACTS 31), cleared only by admin-licence allow; auth-login never clears it. '
  'While set, auth-login and every seat-checked function refuse the PC.';
alter table public.devices add column seat_floor_at timestamptz;

comment on column public.devices.seat_floor_at is
  'Seat floor (CONTRACTS 31): a seat certificate issued at or before this time (whole seconds) is refused for '
  'this PC. Raised to now() by admin-licence release and allow, never lowered or cleared.';
comment on column public.profiles.user_seat_token is
  'Per-user plan only: the CONTRACTS 3 user seat token (PAI-USEAT-1) given in A10 through admin-licence '
  '(CONTRACTS 34); auth-login checks it for role user. Only the salted userHash ever leaves the company server.';
