create function public.my_settings()
returns jsonb
language sql
stable
security definer
set search_path = ''
as $$
  select jsonb_build_object(
    'allow_copy', s.allow_copy,
    'idle_timeout_min', s.idle_timeout_min,
    'session_max_hours', s.session_max_hours,
    'upload_max_mb', s.upload_max_mb,
    'allowed_types', to_jsonb(s.allowed_types),
    'timezone', s.timezone
  )
  from public.tenant_settings s
  where exists (select 1 from public.profiles p where p.id = auth.uid() and p.status = 'active');
$$;
create function public.my_usage_today(p_domain_id text default null)
returns jsonb
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
  v_uid uuid := auth.uid();
  v_profile public.profiles%rowtype;
  v_day date;
  v_domain text;
  v_limit bigint;
  v_used bigint;
  v_requests bigint;
begin
  select * into v_profile from public.profiles p where p.id = v_uid and p.status = 'active';
  if not found then
    return null;
  end if;

  select (now() at time zone s.timezone)::date into v_day from public.tenant_settings s;
  v_domain := case when v_profile.role = 'user' then v_profile.domain_id else p_domain_id end;

  select coalesce(v_profile.daily_token_limit, d.default_daily_tokens) into v_limit
  from public.domains d
  where d.id = v_domain;
  if v_limit is null then
    v_limit := v_profile.daily_token_limit;
  end if;

  select coalesce(sum(u.input_tokens + u.output_tokens), 0), coalesce(sum(u.requests), 0)
  into v_used, v_requests
  from public.usage_daily u
  where u.user_id = v_uid and u.day = v_day;

  return jsonb_build_object(
    'day', v_day,
    'domain_id', v_domain,
    'tokens_used', v_used,
    'daily_limit', v_limit,
    'tokens_left', case when v_limit is null then null else greatest(v_limit - v_used, 0) end,
    'requests', v_requests
  );
end;
$$;
create function public.log_export(
  p_prompt_id uuid,
  p_export_type text,
  p_file_name text,
  p_sha256 text,
  p_device_id text
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_uid uuid := auth.uid();
  v_claim_device text := nullif(auth.jwt() ->> 'device_id', '');
  v_role text;
  v_domain text;
  v_prompt_domain text;
  v_id uuid;
begin
  select p.role, p.domain_id into v_role, v_domain
  from public.profiles p
  where p.id = v_uid and p.status = 'active';
  if not found then
    raise exception 'Not signed in' using errcode = '42501';
  end if;

  if p_file_name is null or p_file_name ~ '[\\/:*?"<>|[:cntrl:]]' then
    raise exception 'Invalid file name' using errcode = '22023';
  end if;

  if v_claim_device is not null and p_device_id is not null and p_device_id <> v_claim_device then
    raise exception 'Device does not match the session' using errcode = '42501';
  end if;

  if p_prompt_id is not null then
    select pl.domain_id into v_prompt_domain
    from public.prompt_log pl
    where pl.id = p_prompt_id and pl.user_id = v_uid;
    if not found then
      raise exception 'Unknown prompt' using errcode = 'P0002';
    end if;
    if v_role <> 'user' then
      v_domain := v_prompt_domain;
    end if;
  end if;

  insert into public.export_log (user_id, domain_id, prompt_id, export_type, file_name, sha256, device_id)
  values (v_uid, v_domain, p_prompt_id, p_export_type, p_file_name, p_sha256, coalesce(v_claim_device, p_device_id))
  returning id into v_id;

  return v_id;
end;
$$;
create function public.mark_notifications_read(p_ids uuid[])
returns integer
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_count integer;
begin
  if not public.is_admin() then
    raise exception 'Only an Administrator can do this' using errcode = '42501';
  end if;

  update public.notifications n
  set read_at = now(), read_by = auth.uid()
  where n.id = any (p_ids) and n.read_at is null;
  get diagnostics v_count = row_count;
  return v_count;
end;
$$;
create function public.record_acceptance(p_kind text)
returns timestamptz
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_uid uuid := auth.uid();
  v_role text;
  v_at timestamptz;
begin
  select p.role into v_role from public.profiles p where p.id = v_uid and p.status = 'active';
  if not found then
    raise exception 'Not signed in' using errcode = '42501';
  end if;

  if p_kind = 'notice' then
    update public.profiles p
    set notice_accepted_at = coalesce(p.notice_accepted_at, now())
    where p.id = v_uid
    returning p.notice_accepted_at into v_at;
  elsif p_kind = 'eula' then
    if v_role not in ('admin', 'backup_admin') then
      raise exception 'Only an Administrator accepts the licence agreement' using errcode = '42501';
    end if;
    update public.profiles p
    set eula_accepted_at = coalesce(p.eula_accepted_at, now())
    where p.id = v_uid
    returning p.eula_accepted_at into v_at;
  else
    raise exception 'Unknown acceptance kind' using errcode = '22023';
  end if;

  return v_at;
end;
$$;
create function private.purgeable_tables()
returns text[]
language sql
immutable
set search_path = ''
as $$
  select array['login_events', 'prompt_log', 'prompt_result', 'upload_log', 'export_log',
               'answer_store', 'usage_daily', 'notifications'];
$$;
create function private.purge_predicate(p_table text, p_filter jsonb, p_is_hold boolean)
returns text
language plpgsql
stable
set search_path = ''
as $$
declare
  v_key text;
  v_parts text[] := '{}';
  v_time_col text := case when p_table = 'usage_daily' then 'day' else 'created_at' end;
  v_id_col text := case when p_table in ('prompt_result', 'answer_store') then 'prompt_id' else 'id' end;
  v_has_user boolean := p_table not in ('answer_store', 'notifications');
  v_has_domain boolean := p_table in ('login_events', 'prompt_log', 'upload_log', 'export_log', 'usage_daily');
  v_via_prompt boolean := p_table in ('prompt_result', 'answer_store');
  v_tz text := coalesce((select s.timezone from public.tenant_settings s), 'Asia/Kolkata');
  v_before timestamptz;
  v_after timestamptz;
  v_user uuid;
  v_domain text;
  v_ids uuid[];
begin
  if p_filter is null or jsonb_typeof(p_filter) <> 'object' then
    raise exception 'The filter must be a JSON object' using errcode = '22023';
  end if;

  for v_key in select jsonb_object_keys(p_filter) loop
    if v_key not in ('before', 'after', 'user_id', 'domain_id', 'ids', 'tables')
       or (v_key = 'tables' and not p_is_hold) then
      raise exception 'Unknown filter key %', v_key using errcode = '22023';
    end if;
  end loop;

  if p_filter ? 'tables' then
    if jsonb_typeof(p_filter -> 'tables') <> 'array' then
      raise exception 'tables must be an array' using errcode = '22023';
    end if;
    if not (p_filter -> 'tables') ? p_table then
      return 'false';
    end if;
  end if;

  if p_filter ? 'before' then
    v_before := (p_filter ->> 'before')::timestamptz;
    v_parts := v_parts || case when p_table = 'usage_daily'
      then format('day < (%L::timestamptz at time zone %L)::date', v_before, v_tz)
      else format('%I < %L::timestamptz', v_time_col, v_before) end;
  end if;

  if p_filter ? 'after' then
    v_after := (p_filter ->> 'after')::timestamptz;
    v_parts := v_parts || case when p_table = 'usage_daily'
      then format('day >= (%L::timestamptz at time zone %L)::date', v_after, v_tz)
      else format('%I >= %L::timestamptz', v_time_col, v_after) end;
  end if;

  if p_filter ? 'user_id' then
    v_user := (p_filter ->> 'user_id')::uuid;
    if p_table = 'answer_store' then
      v_parts := v_parts || format('prompt_id in (select pl.id from public.prompt_log pl where pl.user_id = %L::uuid)', v_user);
    elsif v_has_user then
      v_parts := v_parts || format('user_id = %L::uuid', v_user);
    elsif p_is_hold then
      return 'false';
    else
      raise exception 'Table % cannot be filtered by user', p_table using errcode = '22023';
    end if;
  end if;

  if p_filter ? 'domain_id' then
    v_domain := p_filter ->> 'domain_id';
    if v_domain is null or v_domain !~ '^[A-Z][A-Z0-9_]{1,15}$' then
      raise exception 'Invalid domain_id' using errcode = '22023';
    end if;
    if v_via_prompt then
      v_parts := v_parts || format('prompt_id in (select pl.id from public.prompt_log pl where pl.domain_id = %L)', v_domain);
    elsif v_has_domain then
      v_parts := v_parts || format('domain_id = %L', v_domain);
    elsif p_is_hold then
      return 'false';
    else
      raise exception 'Table % cannot be filtered by domain', p_table using errcode = '22023';
    end if;
  end if;

  if p_filter ? 'ids' then
    select array_agg(x::uuid) into v_ids from jsonb_array_elements_text(p_filter -> 'ids') as x;
    v_parts := v_parts || format('%I = any (%L::uuid[])', v_id_col, coalesce(v_ids, '{}'));
  end if;

  if cardinality(v_parts) = 0 then
    if p_is_hold then
      return 'true';
    end if;
    raise exception 'A filter is required' using errcode = '22023';
  end if;

  return array_to_string(v_parts, ' and ');
end;
$$;
create function private.legal_hold_predicate(p_table text)
returns text
language sql
stable
set search_path = ''
as $$
  select coalesce(
    string_agg('(' || private.purge_predicate(p_table, h.filter, true) || ')', ' or '),
    'false'
  )
  from public.legal_holds h
  where h.released_at is null;
$$;
create function private.validate_legal_hold()
returns trigger
language plpgsql
set search_path = ''
as $$
declare
  v_table text;
begin
  if new.filter ? 'tables' then
    if jsonb_typeof(new.filter -> 'tables') <> 'array' or jsonb_array_length(new.filter -> 'tables') = 0 then
      raise exception 'tables must be a non-empty array' using errcode = '22023';
    end if;
    if exists (
      select 1 from jsonb_array_elements(new.filter -> 'tables') as t (v)
      where jsonb_typeof(t.v) <> 'string' or not ((t.v #>> '{}') = any (private.purgeable_tables()))
    ) then
      raise exception 'A legal hold names a table that cannot be purged' using errcode = '22023';
    end if;
  end if;
  foreach v_table in array private.purgeable_tables() loop
    perform private.purge_predicate(v_table, new.filter - 'tables', true);
  end loop;
  return new;
end;
$$;

create trigger legal_holds_validate
  before insert or update of filter on public.legal_holds
  for each row execute function private.validate_legal_hold();
create function public.admin_purge(
  p_table text,
  p_filter jsonb,
  p_reason text,
  p_admin_id uuid default null
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_uid uuid := auth.uid();
  v_claims jsonb := nullif(current_setting('request.jwt.claims', true), '')::jsonb;
  v_admin uuid;
  v_reason text := btrim(coalesce(p_reason, ''));
  v_pred text;
  v_hold text;
  v_where text;
  v_held integer;
  v_deleted integer;
  v_count integer;
  v_related jsonb := '{}'::jsonb;
  v_paths jsonb := '[]'::jsonb;
begin
  if v_uid is not null then
    if not public.is_admin() then
      raise exception 'Only an Administrator can delete records' using errcode = '42501';
    end if;
    v_admin := v_uid;
  elsif coalesce(v_claims ->> 'role', '') = 'service_role'
        and coalesce(current_setting('role', true), '') = 'service_role' then
    if p_admin_id is not null and not exists (
      select 1 from public.profiles p
      where p.id = p_admin_id and p.role in ('admin', 'backup_admin') and p.status = 'active'
    ) then
      raise exception 'Unknown Administrator' using errcode = '42501';
    end if;
    v_admin := p_admin_id;
  else
    raise exception 'Only an Administrator can delete records' using errcode = '42501';
  end if;
  if char_length(v_reason) < 3 then
    raise exception 'A reason is required for every deletion' using errcode = '22023';
  end if;
  if p_table is null or not (p_table = any (private.purgeable_tables())) then
    raise exception 'Records of % cannot be deleted', coalesce(p_table, 'this table') using errcode = '42501';
  end if;
  v_pred := private.purge_predicate(p_table, p_filter, false);
  v_hold := private.legal_hold_predicate(p_table);
  v_where := format('(%s) and not coalesce((%s), false)', v_pred, v_hold);
  execute format('select count(*) from public.%I where (%s) and coalesce((%s), false)', p_table, v_pred, v_hold)
    into v_held;
  perform set_config('pharmaai.purge', 'on', true);

  if p_table = 'prompt_log' then
    execute format(
      'with d as (delete from public.prompt_result where prompt_id in (select id from public.prompt_log where %s) returning 1) select count(*) from d',
      v_where) into v_count;
    v_related := v_related || jsonb_build_object('prompt_result', v_count);
    insert into public.deletion_log (admin_id, table_name, filter, record_count, reason)
    values (v_admin, 'prompt_result', p_filter, v_count, v_reason);

    execute format(
      'with d as (delete from public.answer_store where prompt_id in (select id from public.prompt_log where %s) returning 1) select count(*) from d',
      v_where) into v_count;
    v_related := v_related || jsonb_build_object('answer_store', v_count);
    insert into public.deletion_log (admin_id, table_name, filter, record_count, reason)
    values (v_admin, 'answer_store', p_filter, v_count, v_reason);
  end if;

  if p_table = 'upload_log' then
    execute format(
      'with d as (delete from public.upload_log where %s returning storage_path) select count(*), coalesce(jsonb_agg(storage_path), ''[]''::jsonb) from d',
      v_where) into v_deleted, v_paths;
  else
    execute format('with d as (delete from public.%I where %s returning 1) select count(*) from d', p_table, v_where)
      into v_deleted;
  end if;

  perform set_config('pharmaai.purge', 'off', true);

  insert into public.deletion_log (admin_id, table_name, filter, record_count, reason)
  values (v_admin, p_table, p_filter, v_deleted, v_reason);

  return jsonb_build_object(
    'table', p_table,
    'deleted', v_deleted,
    'held', v_held,
    'related', v_related,
    'storage_paths', v_paths
  );
end;
$$;
create function private.rate_limit_hit(p_key text, p_window_seconds integer, p_max integer)
returns boolean
language plpgsql
set search_path = ''
as $$
declare
  v_window timestamptz;
  v_count integer;
begin
  if p_key is null or p_window_seconds is null or p_window_seconds < 1 or p_max is null or p_max < 1 then
    raise exception 'Invalid rate limit arguments' using errcode = '22023';
  end if;
  v_window := to_timestamp(floor(extract(epoch from now()) / p_window_seconds) * p_window_seconds);

  insert into private.rate_limits as r (key, window_start, count)
  values (p_key, v_window, 1)
  on conflict (key, window_start) do update set count = r.count + 1
  returning r.count into v_count;

  return v_count <= p_max;
end;
$$;
create function private.use_nonce(p_nonce text)
returns boolean
language plpgsql
set search_path = ''
as $$
declare
  v_count integer;
begin
  insert into private.used_nonces (nonce) values (p_nonce) on conflict (nonce) do nothing;
  get diagnostics v_count = row_count;
  return v_count = 1;
end;
$$;
create function private.create_login_ticket(p_user_id uuid, p_device_id text)
returns uuid
language plpgsql
set search_path = ''
as $$
declare
  v_id uuid;
begin
  delete from private.login_tickets t where t.user_id = p_user_id and t.used_at is null;
  insert into private.login_tickets (user_id, device_id) values (p_user_id, p_device_id)
  returning id into v_id;
  return v_id;
end;
$$;
create function private.create_change_ticket(p_user_id uuid, p_kind text, p_created_by uuid default null)
returns uuid
language plpgsql
set search_path = ''
as $$
declare
  v_id uuid;
begin
  delete from private.change_tickets t
  where t.user_id = p_user_id and t.kind = p_kind and t.used_at is null;
  insert into private.change_tickets (user_id, kind, created_by) values (p_user_id, p_kind, p_created_by)
  returning id into v_id;
  return v_id;
end;
$$;
create function private.register_login_failure(p_user_id uuid)
returns jsonb
language plpgsql
set search_path = ''
as $$
declare
  v_threshold integer := coalesce((select s.lockout_threshold from public.tenant_settings s), 5);
  v_old_status text;
  v_failed integer;
  v_status text;
begin
  select p.status into v_old_status from public.profiles p where p.id = p_user_id for update;
  if not found then
    return null;
  end if;

  update public.profiles p
  set failed_logins = p.failed_logins + 1,
      status = case when p.status = 'active' and p.failed_logins + 1 >= v_threshold then 'locked' else p.status end
  where p.id = p_user_id
  returning p.failed_logins, p.status into v_failed, v_status;

  return jsonb_build_object(
    'failed_logins', v_failed,
    'threshold', v_threshold,
    'locked', v_status = 'locked',
    'newly_locked', v_status = 'locked' and v_old_status <> 'locked'
  );
end;
$$;
create function private.register_login_success(p_user_id uuid)
returns void
language plpgsql
set search_path = ''
as $$
begin
  update public.profiles p
  set failed_logins = 0, last_login_at = now()
  where p.id = p_user_id;
end;
$$;
create function private.known_answer_hashes(p_user_id uuid, p_conversation_id text, p_hashes text[])
returns text[]
language sql
stable
set search_path = ''
as $$
  select coalesce(array_agg(distinct r.answer_sha256), '{}')
  from public.prompt_result r
  join public.prompt_log l on l.id = r.prompt_id
  where r.user_id = p_user_id
    and l.user_id = p_user_id
    and l.conversation_id = p_conversation_id
    and r.answer_sha256 = any (p_hashes);
$$;
create function private.add_usage(
  p_day date,
  p_user_id uuid,
  p_domain_id text,
  p_provider text,
  p_model text,
  p_kind text,
  p_input_tokens bigint default 0,
  p_cached_tokens bigint default 0,
  p_output_tokens bigint default 0,
  p_est_cost numeric default 0,
  p_requests integer default 1,
  p_blocked integer default 0
)
returns void
language plpgsql
set search_path = ''
as $$
begin
  insert into public.usage_daily as u (
    day, user_id, domain_id, provider, model, kind,
    input_tokens, cached_tokens, output_tokens, est_cost, requests, blocked
  )
  values (
    p_day, p_user_id, p_domain_id, p_provider, p_model, p_kind,
    p_input_tokens, p_cached_tokens, p_output_tokens, p_est_cost, p_requests, p_blocked
  )
  on conflict on constraint usage_daily_unique do update set
    input_tokens = u.input_tokens + excluded.input_tokens,
    cached_tokens = u.cached_tokens + excluded.cached_tokens,
    output_tokens = u.output_tokens + excluded.output_tokens,
    est_cost = u.est_cost + excluded.est_cost,
    requests = u.requests + excluded.requests,
    blocked = u.blocked + excluded.blocked,
    updated_at = now();
end;
$$;
create function private.notify(
  p_type text,
  p_title text,
  p_body text default null,
  p_ref_table text default null,
  p_ref_id text default null
)
returns uuid
language plpgsql
set search_path = ''
as $$
declare
  v_id uuid;
begin
  if not exists (select 1 from public.notification_rules r where r.type = p_type and (r.enabled or r.locked)) then
    if not exists (select 1 from public.notification_rules r where r.type = p_type) then
      raise exception 'Unknown notification type %', p_type using errcode = '23503';
    end if;
    return null;
  end if;

  insert into public.notifications (type, title, body, ref_table, ref_id)
  values (p_type, left(p_title, 200), left(p_body, 2000), p_ref_table, p_ref_id)
  returning id into v_id;
  return v_id;
end;
$$;
create function private.level2_set(p_user_id uuid, p_password text, p_updated_by uuid default null)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  if p_password is null or char_length(p_password) < 10
     or p_password !~ '[A-Za-z]' or p_password !~ '[0-9]' then
    raise exception 'The Level-2 password needs at least 10 characters with letters and numbers'
      using errcode = '22023';
  end if;
  if exists (
    select 1 from auth.users u
    where u.id = p_user_id
      and u.encrypted_password is not null
      and u.encrypted_password <> ''
      and extensions.crypt(p_password, u.encrypted_password) = u.encrypted_password
  ) then
    raise exception 'The Level-2 password must be different from the login password'
      using errcode = '22023';
  end if;

  insert into private.level2_secrets as s (user_id, hash, failed_count, locked, updated_by, updated_at)
  values (p_user_id, extensions.crypt(p_password, extensions.gen_salt('bf', 10)), 0, false, p_updated_by, now())
  on conflict (user_id) do update set
    hash = excluded.hash, failed_count = 0, locked = false,
    updated_by = excluded.updated_by, updated_at = now();
end;
$$;
create function private.level2_check(p_user_id uuid, p_password text)
returns jsonb
language plpgsql
set search_path = ''
as $$
declare
  v_row private.level2_secrets%rowtype;
begin
  select * into v_row from private.level2_secrets s where s.user_id = p_user_id for update;
  if not found then
    return jsonb_build_object('ok', false, 'locked', false, 'failed_count', 0, 'missing', true);
  end if;
  if v_row.locked then
    return jsonb_build_object('ok', false, 'locked', true, 'failed_count', v_row.failed_count, 'missing', false);
  end if;

  if p_password is not null and extensions.crypt(p_password, v_row.hash) = v_row.hash then
    update private.level2_secrets s set failed_count = 0 where s.user_id = p_user_id;
    return jsonb_build_object('ok', true, 'locked', false, 'failed_count', 0, 'missing', false);
  end if;

  update private.level2_secrets s
  set failed_count = s.failed_count + 1, locked = (s.failed_count + 1 >= 5)
  where s.user_id = p_user_id
  returning * into v_row;
  return jsonb_build_object('ok', false, 'locked', v_row.locked, 'failed_count', v_row.failed_count, 'missing', false);
end;
$$;
create function private.level2_unlock(p_user_id uuid, p_updated_by uuid default null)
returns boolean
language plpgsql
set search_path = ''
as $$
begin
  update private.level2_secrets s
  set failed_count = 0, locked = false, updated_by = p_updated_by, updated_at = now()
  where s.user_id = p_user_id;
  return found;
end;
$$;
create function private.normalise_recovery_code(p_code text)
returns text
language sql
immutable
set search_path = ''
as $$
  select upper(regexp_replace(coalesce(p_code, ''), '[\s-]', '', 'g'));
$$;
create function private.recovery_codes_set(p_user_id uuid, p_codes text[])
returns integer
language plpgsql
set search_path = ''
as $$
declare
  v_code text;
begin
  if p_codes is null or cardinality(p_codes) <> 10 then
    raise exception 'Exactly 10 recovery codes are required' using errcode = '22023';
  end if;
  foreach v_code in array p_codes loop
    if char_length(private.normalise_recovery_code(v_code)) < 10 then
      raise exception 'Recovery codes need at least 10 characters' using errcode = '22023';
    end if;
  end loop;

  delete from private.recovery_codes r where r.user_id = p_user_id;
  insert into private.recovery_codes (user_id, code_hash)
  select p_user_id, extensions.crypt(private.normalise_recovery_code(c), extensions.gen_salt('bf', 10))
  from unnest(p_codes) as c;
  return 10;
end;
$$;
create function private.recovery_code_use(p_user_id uuid, p_code text)
returns boolean
language plpgsql
set search_path = ''
as $$
declare
  v_code text := private.normalise_recovery_code(p_code);
  v_id uuid;
begin
  select r.id into v_id
  from private.recovery_codes r
  where r.user_id = p_user_id
    and r.used_at is null
    and extensions.crypt(v_code, r.code_hash) = r.code_hash
  limit 1
  for update;
  if v_id is null then
    return false;
  end if;
  update private.recovery_codes r set used_at = now() where r.id = v_id;
  return true;
end;
$$;
create function private.cleanup_expired()
returns jsonb
language plpgsql
set search_path = ''
as $$
declare
  v_tickets integer;
  v_changes integer;
  v_nonces integer;
  v_rates integer;
  v_sessions integer;
  v_answers integer;
  v_hours integer;
begin
  delete from private.login_tickets t where t.created_at < now() - interval '1 day';
  get diagnostics v_tickets = row_count;
  delete from private.change_tickets t where t.created_at < now() - interval '1 day';
  get diagnostics v_changes = row_count;
  delete from private.used_nonces n where n.created_at < now() - interval '1 hour';
  get diagnostics v_nonces = row_count;
  delete from private.rate_limits r where r.window_start < now() - interval '1 day';
  get diagnostics v_rates = row_count;
  select s.session_max_hours + 12 into v_hours from public.tenant_settings s;
  delete from private.session_devices d
  where d.created_at < now() - make_interval(hours => coalesce(v_hours, 24));
  get diagnostics v_sessions = row_count;

  delete from public.answer_store a where a.expires_at < now();
  get diagnostics v_answers = row_count;
  if v_answers > 0 then
    insert into public.deletion_log (admin_id, table_name, filter, record_count, reason)
    values (null, 'answer_store', jsonb_build_object('expired_before', now()), v_answers,
            'Answer retention period ended');
  end if;

  return jsonb_build_object(
    'login_tickets', v_tickets, 'change_tickets', v_changes, 'used_nonces', v_nonces,
    'rate_limits', v_rates, 'session_devices', v_sessions, 'answer_store', v_answers
  );
end;
$$;
create function private.notify_upload()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_domain text;
  v_user text;
begin
  select d.name into v_domain from public.domains d where d.id = new.domain_id;
  select coalesce(p.display_name, p.username) into v_user from public.profiles p where p.id = new.user_id;

  insert into public.notifications (type, title, body, ref_table, ref_id)
  values (
    'upload',
    left(case when v_domain is null then 'New upload' else 'New upload in ' || v_domain end, 200),
    left(format('%s uploaded "%s" (%s, %s bytes). Reason: %s. Description: %s',
                coalesce(v_user, 'A user'), new.file_name, new.mime_type, new.size_bytes,
                new.reason, new.description), 2000),
    'upload_log',
    new.id::text
  );
  return new;
end;
$$;

create trigger upload_log_notify
  after insert on public.upload_log
  for each row execute function private.notify_upload();
create function private.protect_locked_rule()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  if tg_op = 'DELETE' then
    if old.locked then
      raise exception 'Notification type % is always on', old.type using errcode = '42501';
    end if;
    return old;
  end if;
  if old.locked and (not new.locked or not new.enabled or new.type <> old.type) then
    raise exception 'Notification type % is always on', old.type using errcode = '42501';
  end if;
  new.updated_at := now();
  return new;
end;
$$;

create trigger notification_rules_protect_locked
  before update or delete on public.notification_rules
  for each row execute function private.protect_locked_rule();
create function private.invoke_edge_function(p_name text)
returns bigint
language plpgsql
set search_path = ''
as $$
declare
  v_base text;
  v_secret text;
begin
  if p_name not in ('purge', 'usage-report') then
    raise exception 'Unknown scheduled function %', p_name using errcode = '22023';
  end if;

  select c.value into v_base from private.config c where c.key = 'functions_base_url';
  select s.decrypted_secret into v_secret from vault.decrypted_secrets s where s.name = 'pharmaai_cron_secret';
  if v_base is null or v_secret is null then
    raise warning 'Scheduled call to % skipped: functions_base_url or the cron secret is not configured', p_name;
    return null;
  end if;

  return net.http_post(
    url := rtrim(v_base, '/') || '/functions/v1/' || p_name,
    body := '{}'::jsonb,
    headers := jsonb_build_object('Content-Type', 'application/json', 'x-pharmaai-cron-secret', v_secret),
    timeout_milliseconds := 10000
  );
end;
$$;
revoke execute on all functions in schema public from public, anon, authenticated, service_role;
revoke execute on all functions in schema private from public, anon, authenticated, service_role;

grant execute on function public.is_admin() to authenticated;
grant execute on function public.my_domain() to authenticated;
grant execute on function public.realtime_topic_allowed(text) to authenticated;
grant execute on function public.my_settings() to authenticated;
grant execute on function public.my_usage_today(text) to authenticated;
grant execute on function public.log_export(uuid, text, text, text, text) to authenticated;
grant execute on function public.mark_notifications_read(uuid[]) to authenticated;
grant execute on function public.record_acceptance(text) to authenticated;
grant execute on function public.admin_purge(text, jsonb, text, uuid) to authenticated, service_role;

grant execute on function private.rate_limit_hit(text, integer, integer) to service_role;
grant execute on function private.use_nonce(text) to service_role;
grant execute on function private.create_login_ticket(uuid, text) to service_role;
grant execute on function private.create_change_ticket(uuid, text, uuid) to service_role;
grant execute on function private.register_login_failure(uuid) to service_role;
grant execute on function private.register_login_success(uuid) to service_role;
grant execute on function private.known_answer_hashes(uuid, text, text[]) to service_role;
grant execute on function private.add_usage(date, uuid, text, text, text, text, bigint, bigint, bigint, numeric, integer, integer) to service_role;
grant execute on function private.notify(text, text, text, text, text) to service_role;
grant execute on function private.level2_set(uuid, text, uuid) to service_role;
grant execute on function private.level2_check(uuid, text) to service_role;
grant execute on function private.level2_unlock(uuid, uuid) to service_role;
grant execute on function private.recovery_codes_set(uuid, text[]) to service_role;
grant execute on function private.recovery_code_use(uuid, text) to service_role;
grant execute on function private.cleanup_expired() to service_role;
grant execute on function private.normalise_recovery_code(text) to service_role;
grant execute on function private.purgeable_tables() to service_role;
grant execute on function private.purge_predicate(text, jsonb, boolean) to service_role;
