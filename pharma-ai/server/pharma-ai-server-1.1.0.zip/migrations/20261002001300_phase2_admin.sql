alter table public.budgets
  add column user_daily_tokens integer,
  add constraint budgets_user_daily_tokens_check
    check (user_daily_tokens is null or user_daily_tokens > 0),
  add constraint budgets_user_daily_tokens_scope_check
    check (user_daily_tokens is null or scope = 'domain');

comment on column public.budgets.user_daily_tokens is
  'Default daily token limit of each user of this domain (scope domain only). A profile''s own '
  'daily_token_limit wins; without either the domain''s default_daily_tokens applies (CONTRACTS 8.1).';
comment on constraint budgets_user_daily_tokens_check on public.budgets is
  'A per-user daily limit is a positive number of tokens.';
comment on constraint budgets_user_daily_tokens_scope_check on public.budgets is
  'Only domain budgets carry a per-user default (client and user budgets have none).';
create function private.effective_daily_limit(p_user_id uuid, p_domain_id text)
returns bigint
language sql
stable
set search_path = ''
as $$
  select coalesce(
    (select p.daily_token_limit from public.profiles p where p.id = p_user_id),
    (select b.user_daily_tokens from public.budgets b where b.scope = 'domain' and b.scope_id = p_domain_id),
    (select d.default_daily_tokens from public.domains d where d.id = p_domain_id)
  )::bigint;
$$;

comment on function private.effective_daily_limit(uuid, text) is
  'Effective daily token limit of a user working in a domain (CONTRACTS 8.1): profile override, else the '
  'domain budget''s user_daily_tokens, else the domain default. Used by my_usage_today() and ai-chat.';

revoke execute on function private.effective_daily_limit(uuid, text) from public, anon, authenticated, service_role;
grant execute on function private.effective_daily_limit(uuid, text) to service_role;
create or replace function public.my_usage_today(p_domain_id text default null)
returns jsonb
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
  v_uid uuid := auth.uid();
  v_profile public.profiles%rowtype;
  v_day date;
  v_domain text;
  v_limit bigint;
  v_used bigint;
  v_requests bigint;
begin
  select * into v_profile from public.profiles p where p.id = v_uid and p.status = 'active';
  if not found then
    return null;
  end if;

  select (now() at time zone s.timezone)::date into v_day from public.tenant_settings s;
  v_domain := case when v_profile.role = 'user' then v_profile.domain_id else p_domain_id end;
  v_limit := private.effective_daily_limit(v_uid, v_domain);

  select coalesce(sum(u.input_tokens + u.output_tokens), 0), coalesce(sum(u.requests), 0)
  into v_used, v_requests
  from public.usage_daily u
  where u.user_id = v_uid and u.day = v_day;

  return jsonb_build_object(
    'day', v_day,
    'domain_id', v_domain,
    'tokens_used', v_used,
    'daily_limit', v_limit,
    'tokens_left', case when v_limit is null then null else greatest(v_limit - v_used, 0) end,
    'requests', v_requests
  );
end;
$$;

comment on function public.my_usage_today(text) is
  'Today''s (IST) token use of the caller against his effective daily limit (CONTRACTS 8.1). Domain users '
  'always get their own domain; admins pass the domain they work in.';
revoke execute on function public.my_usage_today(text) from public, anon, authenticated, service_role;
grant execute on function public.my_usage_today(text) to authenticated;
create function private.provider_key_store(p_provider_id uuid, p_key text)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_name text := 'pharmaai_provider_' || p_provider_id::text;
  v_secret_id uuid;
begin
  if p_key is null or char_length(p_key) < 8 or char_length(p_key) > 512 or p_key ~ '[[:cntrl:]]' then
    raise exception 'The API key must be one line of 8 to 512 characters' using errcode = '22023';
  end if;

  select p.vault_secret_id into v_secret_id
  from public.ai_providers p
  where p.id = p_provider_id
  for update;
  if not found then
    raise exception 'Unknown AI provider' using errcode = 'P0002';
  end if;
  if v_secret_id is null or not exists (select 1 from vault.secrets s where s.id = v_secret_id) then
    select s.id into v_secret_id from vault.secrets s where s.name = v_name;
  end if;

  if v_secret_id is null then
    v_secret_id := vault.create_secret(p_key, v_name, 'AI provider key');
  else
    perform vault.update_secret(v_secret_id, p_key, v_name, 'AI provider key');
  end if;

  update public.ai_providers p
  set vault_secret_id = v_secret_id, key_last4 = right(p_key, 4), status = 'untested', updated_at = now()
  where p.id = p_provider_id;
  return v_secret_id;
end;
$$;

comment on function private.provider_key_store(uuid, text) is
  'admin-keys add / replace: stores the provider key in Vault (pharmaai_provider_<id>, updated in place), '
  'keeps only the last 4 characters in ai_providers and sets status untested. Edge Functions only.';
create function private.provider_key_read(p_provider_id uuid)
returns text
language sql
stable
security definer
set search_path = ''
as $$
  select s.decrypted_secret
  from public.ai_providers p
  join vault.decrypted_secrets s on s.id = p.vault_secret_id
  where p.id = p_provider_id
    and p.status <> 'revoked';
$$;

comment on function private.provider_key_read(uuid) is
  'admin-keys test / ai-chat: the decrypted provider key, NULL when revoked or missing. Edge Functions only; '
  'the key never leaves the function.';
create function private.provider_key_delete(p_provider_id uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_secret_id uuid;
begin
  select p.vault_secret_id into v_secret_id
  from public.ai_providers p
  where p.id = p_provider_id
  for update;
  if not found then
    raise exception 'Unknown AI provider' using errcode = 'P0002';
  end if;

  delete from vault.secrets s
  where s.id = v_secret_id
     or s.name = 'pharmaai_provider_' || p_provider_id::text;

  update public.ai_providers p
  set vault_secret_id = null, key_last4 = null, status = 'revoked', updated_at = now()
  where p.id = p_provider_id;
end;
$$;

comment on function private.provider_key_delete(uuid) is
  'admin-keys revoke: deletes the provider''s Vault secret, clears vault_secret_id and key_last4 and sets '
  'status revoked. Edge Functions only.';

revoke execute on function private.provider_key_store(uuid, text) from public, anon, authenticated, service_role;
revoke execute on function private.provider_key_read(uuid) from public, anon, authenticated, service_role;
revoke execute on function private.provider_key_delete(uuid) from public, anon, authenticated, service_role;
grant execute on function private.provider_key_store(uuid, text) to service_role;
grant execute on function private.provider_key_read(uuid) to service_role;
grant execute on function private.provider_key_delete(uuid) to service_role;
