revoke execute on function public.admin_purge(text, jsonb, text, uuid) from public, anon, authenticated;
grant execute on function public.admin_purge(text, jsonb, text, uuid) to service_role;

comment on function public.admin_purge(text, jsonb, text, uuid) is
  'The only way to delete log records (AUD-03, AUD-06): secret key only - admin-delete (for p_admin_id, after '
  'its password re-check) and the nightly purge (p_admin_id NULL). Legal holds honoured; deletion_log written.';
create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1
    from public.profiles p
    where p.id = auth.uid()
      and p.role in ('admin', 'backup_admin')
      and p.status = 'active'
  )
  and (
    coalesce(auth.jwt() ->> 'aal', '') = 'aal2'
    or not exists (
      select 1
      from auth.mfa_factors f
      where f.user_id = auth.uid()
        and f.factor_type = 'totp'
        and f.status = 'verified'
    )
  );
$$;

comment on function public.is_admin() is
  'True for an active Admin / Backup Admin - at the aal2 level once the account has a verified TOTP factor.';

revoke execute on function public.is_admin() from public, anon, authenticated, service_role;
grant execute on function public.is_admin() to authenticated;
create or replace function private.legal_hold_predicate(p_table text)
returns text
language plpgsql
stable
set search_path = ''
as $$
declare
  v_pred text;
  v_child_table text;
  v_child text;
begin
  select coalesce(string_agg('(' || private.purge_predicate(p_table, h.filter, true) || ')', ' or '), 'false')
    into v_pred
  from public.legal_holds h
  where h.released_at is null;

  if p_table is distinct from 'prompt_log' then
    return v_pred;
  end if;

  foreach v_child_table in array array['prompt_result', 'answer_store'] loop
    select string_agg('(' || x.pred || ')', ' or ')
      into v_child
    from (
      select private.purge_predicate(v_child_table, h.filter, true) as pred
      from public.legal_holds h
      where h.released_at is null
    ) x
    where x.pred <> 'false';
    if v_child is not null then
      v_pred := format('%s or id in (select c.prompt_id from public.%I c where coalesce((%s), false))',
                       v_pred, v_child_table, v_child);
    end if;
  end loop;
  return v_pred;
end;
$$;

comment on function private.legal_hold_predicate(text) is
  'SQL predicate of the rows an active legal hold keeps (prompt_log: also questions with a held result / stored answer).';

revoke execute on function private.legal_hold_predicate(text) from public, anon, authenticated, service_role;
grant execute on function private.legal_hold_predicate(text) to service_role;
create or replace function private.cleanup_expired()
returns jsonb
language plpgsql
set search_path = ''
as $$
declare
  v_tickets integer;
  v_changes integer;
  v_uploads integer;
  v_nonces integer;
  v_rates integer;
  v_sessions integer;
  v_answers integer;
  v_hours integer;
begin
  delete from private.login_tickets t where t.created_at < now() - interval '1 day';
  get diagnostics v_tickets = row_count;
  delete from private.change_tickets t where t.created_at < now() - interval '1 day';
  get diagnostics v_changes = row_count;
  delete from private.upload_tickets t
  where t.created_at < now() - interval '1 day'
    and (t.prepared_at is null
         or exists (select 1 from public.upload_log u where u.storage_path = t.storage_path));
  get diagnostics v_uploads = row_count;
  delete from private.used_nonces n where n.created_at < now() - interval '1 hour';
  get diagnostics v_nonces = row_count;
  delete from private.rate_limits r where r.window_start < now() - interval '1 day';
  get diagnostics v_rates = row_count;
  select s.session_max_hours + 12 into v_hours from public.tenant_settings s;
  delete from private.session_devices d
  where d.created_at < now() - make_interval(hours => coalesce(v_hours, 24));
  get diagnostics v_sessions = row_count;
  execute format(
    'delete from public.answer_store where expires_at < now() and not coalesce((%s), false)',
    private.legal_hold_predicate('answer_store'));
  get diagnostics v_answers = row_count;
  if v_answers > 0 then
    insert into public.deletion_log (admin_id, table_name, filter, record_count, reason)
    values (null, 'answer_store', jsonb_build_object('expired_before', now()), v_answers,
            'Answer retention period ended');
  end if;

  return jsonb_build_object(
    'login_tickets', v_tickets, 'change_tickets', v_changes, 'upload_tickets', v_uploads,
    'used_nonces', v_nonces, 'rate_limits', v_rates, 'session_devices', v_sessions, 'answer_store', v_answers
  );
end;
$$;

revoke execute on function private.cleanup_expired() from public, anon, authenticated, service_role;
grant execute on function private.cleanup_expired() to service_role;
create or replace function private.recovery_code_redeem(p_user_id uuid, p_code text)
returns jsonb
language plpgsql
set search_path = ''
as $$
declare
  v_code text := private.normalise_recovery_code(p_code);
  v_row record;
  v_same boolean;
  v_match uuid;
  v_claimed uuid;
  v_done integer := 0;
  v_left integer := 0;
begin
  for v_row in
    select r.id, r.code_hash, r.used_at
    from private.recovery_codes r
    where p_user_id is not null and r.user_id = p_user_id
    order by r.created_at, r.id
  loop
    v_done := v_done + 1;
    v_same := extensions.crypt(v_code, v_row.code_hash) = v_row.code_hash;
    if v_same and v_row.used_at is null and v_match is null then
      v_match := v_row.id;
    end if;
  end loop;
  while v_done < 10 loop
    perform extensions.crypt(v_code, extensions.gen_salt('bf', 10));
    v_done := v_done + 1;
  end loop;

  if v_match is not null then
    update private.recovery_codes r set used_at = now()
    where r.id = v_match and r.used_at is null
    returning r.id into v_claimed;
  end if;
  if p_user_id is not null then
    select count(*)::int into v_left from private.recovery_codes r where r.user_id = p_user_id and r.used_at is null;
  end if;
  return jsonb_build_object('ok', v_claimed is not null, 'codes_left', v_left);
end;
$$;

revoke execute on function private.recovery_code_redeem(uuid, text) from public, anon, authenticated, service_role;
grant execute on function private.recovery_code_redeem(uuid, text) to service_role;
create function public.log_mfa_change(p_event text, p_reason text default null)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_uid uuid := auth.uid();
  v_reason text := nullif(btrim(coalesce(p_reason, '')), '');
  v_enrolled boolean;
  v_id uuid;
begin
  if not public.is_admin() then
    raise exception 'Only an Administrator can do this' using errcode = '42501';
  end if;
  if p_event is null or p_event not in ('enrolled', 'removed') then
    raise exception 'Unknown authenticator-app change' using errcode = '22023';
  end if;
  if v_reason is not null and (char_length(v_reason) > 200 or v_reason ~ '[[:cntrl:]]') then
    raise exception 'The reason needs at most 200 characters on one line' using errcode = '22023';
  end if;
  if p_event = 'removed' and (v_reason is null or char_length(v_reason) < 3) then
    raise exception 'A reason of 3 to 200 characters is required' using errcode = '22023';
  end if;

  select exists (
    select 1 from auth.mfa_factors f
    where f.user_id = v_uid and f.factor_type = 'totp' and f.status = 'verified'
  ) into v_enrolled;
  if (p_event = 'enrolled') is distinct from v_enrolled then
    raise exception 'The authenticator app of this account does not match this change' using errcode = '22023';
  end if;

  insert into public.admin_actions (admin_id, action, target_type, target_id, details, reason)
  values (v_uid, 'users.mfa_' || p_event, 'user', v_uid::text, jsonb_build_object('factorType', 'totp'), v_reason)
  returning id into v_id;
  return v_id;
end;
$$;

comment on function public.log_mfa_change(text, text) is
  'Admin (A9): records adding / removing the own authenticator app in admin_actions (users.mfa_enrolled / users.mfa_removed).';

revoke execute on function public.log_mfa_change(text, text) from public, anon, authenticated, service_role;
grant execute on function public.log_mfa_change(text, text) to authenticated;
