insert into public.notification_rules (type, label, enabled, locked)
values
  ('admin_password_reset', 'Admin password reset by another Administrator', true, false),
  ('break_glass', 'Break-glass recovery used', true, true)
on conflict (type) do nothing;
create function private.notify_once(
  p_type text,
  p_key text,
  p_title text,
  p_body text,
  p_ref_table text,
  p_within interval
)
returns uuid
language plpgsql
set search_path = ''
as $$
begin
  if p_key is null or char_length(p_key) not between 1 and 200 or p_within is null or p_within <= interval '0' then
    raise exception 'Invalid once-only notification arguments' using errcode = '22023';
  end if;
  perform pg_advisory_xact_lock(hashtextextended('pharmaai-notify-once:' || p_type || ':' || p_key, 0));
  if exists (
    select 1 from public.notifications n
    where n.type = p_type and n.ref_id = p_key and n.created_at > now() - p_within
  ) then
    return null;
  end if;
  return private.notify(p_type, p_title, p_body, p_ref_table, p_key);
end;
$$;

comment on function private.notify_once(text, text, text, text, text, interval) is
  'A notification at most once per (type, key) within the window (CONTRACTS 21). Edge Functions and triggers.';
create function private.notify_failed_login_burst()
returns trigger
language plpgsql
set search_path = ''
as $$
declare
  v_count integer;
begin
  select count(*) into v_count
  from public.login_events e
  where e.event = 'fail' and e.created_at > now() - interval '10 minutes';
  if v_count >= 10 then
    perform private.notify_once(
      'failed_logins', 'failed-logins', 'Burst of failed sign-ins',
      format('%s failed sign-in attempts in the last 10 minutes.', v_count),
      'login_events', interval '60 minutes');
  end if;
  return null;
end;
$$;

create trigger login_events_failed_burst
  after insert on public.login_events
  for each row when (new.event = 'fail')
  execute function private.notify_failed_login_burst();
create function private.notify_blocked_burst()
returns trigger
language plpgsql
set search_path = ''
as $$
declare
  v_count integer;
  v_username text;
  v_domain text;
begin
  select count(*) into v_count
  from public.prompt_log p
  where p.user_id = new.user_id and p.decision = 'blocked' and p.created_at > now() - interval '10 minutes';
  if v_count >= 5 then
    select pr.username into v_username from public.profiles pr where pr.id = new.user_id;
    select d.name into v_domain from public.domains d where d.id = new.domain_id;
    perform private.notify_once(
      'blocked_prompts', new.user_id::text,
      left('Burst of refused questions' || coalesce(' in ' || v_domain, ''), 200),
      format('%s had %s questions refused in 10 minutes (see Activity & Audit, Blocked).',
             coalesce(v_username, 'A user'), v_count),
      'profiles', interval '60 minutes');
  end if;
  return null;
end;
$$;

create trigger prompt_log_blocked_burst
  after insert on public.prompt_log
  for each row when (new.decision = 'blocked')
  execute function private.notify_blocked_burst();
create table private.seen_app_versions (
  app_version text primary key check (char_length(app_version) between 1 and 40),
  first_seen timestamptz not null default now(),
  first_device_id text check (first_device_id is null or first_device_id ~ '^[0-9a-f]{32}$')
);

comment on table private.seen_app_versions is
  'App versions this backend has seen (first PC and time); a new one notifies the Admin (new_version).';

alter table private.seen_app_versions enable row level security;
revoke all on table private.seen_app_versions from public, anon, authenticated;
grant select, insert on table private.seen_app_versions to service_role;
insert into private.seen_app_versions (app_version, first_seen, first_device_id)
select d.app_version, min(d.first_seen), (array_agg(d.device_id order by d.first_seen, d.device_id))[1]
from public.devices d
where d.app_version is not null
group by d.app_version
on conflict (app_version) do nothing;
create function private.notify_new_app_version()
returns trigger
language plpgsql
set search_path = ''
as $$
declare
  v_inserted integer;
begin
  insert into private.seen_app_versions (app_version, first_device_id)
  values (new.app_version, new.device_id)
  on conflict (app_version) do nothing;
  get diagnostics v_inserted = row_count;
  if v_inserted = 1 then
    perform private.notify(
      'new_version',
      left('New app version ' || new.app_version || ' in use', 200),
      left('First seen on PC ' || coalesce(new.device_name, new.device_id) || '.', 2000),
      'devices', new.device_id);
  end if;
  return null;
end;
$$;

create trigger devices_new_app_version
  after insert or update of app_version on public.devices
  for each row when (new.app_version is not null)
  execute function private.notify_new_app_version();
create function public.log_session_end(p_event text)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_uid uuid := auth.uid();
  v_domain text;
  v_device text := nullif(auth.jwt() ->> 'device_id', '');
  v_device_name text;
  v_app_version text;
  v_id uuid;
begin
  select p.domain_id into v_domain from public.profiles p where p.id = v_uid and p.status = 'active';
  if not found then
    raise exception 'Not signed in' using errcode = '42501';
  end if;
  if p_event is null or p_event not in ('logout', 'timeout') then
    raise exception 'Unknown session event' using errcode = '22023';
  end if;
  if v_device is not null and v_device !~ '^[0-9a-f]{32}$' then
    v_device := null;
  end if;
  if not private.rate_limit_hit('session-end:' || v_uid::text, 3600, 30) then
    return null;
  end if;

  select d.device_name, d.app_version into v_device_name, v_app_version
  from public.devices d
  where d.device_id = v_device;

  insert into public.login_events (user_id, domain_id, event, device_id, device_name, app_version)
  values (v_uid, v_domain, p_event, v_device, v_device_name, v_app_version)
  returning id into v_id;
  return v_id;
end;
$$;

comment on function public.log_session_end(text) is
  'Desktop: records logout / timeout of the caller in login_events (CONTRACTS 20).';
create function public.report_seat_warning(p_kind text, p_since timestamptz)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_uid uuid := auth.uid();
  v_username text;
  v_device text := nullif(auth.jwt() ->> 'device_id', '');
  v_device_name text;
  v_tz text := coalesce((select s.timezone from public.tenant_settings s), 'Asia/Kolkata');
  v_day text;
  v_title text;
begin
  select p.username into v_username from public.profiles p where p.id = v_uid and p.status = 'active';
  if not found then
    raise exception 'Not signed in' using errcode = '42501';
  end if;
  if v_device is null or v_device !~ '^[0-9a-f]{32}$' then
    raise exception 'This session is not bound to a PC' using errcode = '42501';
  end if;
  if p_since is null then
    raise exception 'A time is required' using errcode = '22023';
  end if;

  select coalesce(d.device_name, v_device) into v_device_name from public.devices d where d.device_id = v_device;
  v_device_name := coalesce(v_device_name, v_device);
  v_day := to_char(p_since at time zone v_tz, 'DD-MM-YYYY');

  if p_kind = 'renewal_failing' then
    if p_since > now() or p_since > now() - interval '7 days' then
      raise exception 'Renewals must have failed for at least 7 days' using errcode = '22023';
    end if;
    v_title := format('PC %s: cannot reach the N Automations licence service since %s', v_device_name, v_day);
  elsif p_kind = 'certificate_expiring' then
    if p_since < now() or p_since > now() + interval '7 days' then
      raise exception 'The certificate must expire within the next 7 days' using errcode = '22023';
    end if;
    v_title := format('PC %s: licence seat expires on %s', v_device_name, v_day);
  else
    raise exception 'Unknown seat warning' using errcode = '22023';
  end if;

  return private.notify_once(
    'seat', p_kind || ':' || v_device, left(v_title, 200),
    format('Reported by the app on PC %s (signed in: %s).', v_device_name, v_username),
    'devices', interval '24 hours');
end;
$$;

comment on function public.report_seat_warning(text, timestamptz) is
  'Desktop: seat warning of the caller''s PC (renewal_failing / certificate_expiring), once per PC and kind per day.';
create function public.log_upload_opened(p_upload_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_row public.upload_log%rowtype;
  v_id uuid;
begin
  if not public.is_admin() then
    raise exception 'Only an Administrator can do this' using errcode = '42501';
  end if;
  select * into v_row from public.upload_log u where u.id = p_upload_id;
  if not found then
    raise exception 'Unknown upload' using errcode = 'P0002';
  end if;

  insert into public.admin_actions (admin_id, action, target_type, target_id, details)
  values (auth.uid(), 'audit.open_upload', 'upload', v_row.id::text,
          jsonb_build_object('fileName', v_row.file_name, 'userId', v_row.user_id, 'sha256', v_row.sha256))
  returning id into v_id;

  return jsonb_build_object(
    'actionId', v_id,
    'storagePath', v_row.storage_path,
    'fileName', v_row.file_name,
    'mimeType', v_row.mime_type,
    'sizeBytes', v_row.size_bytes,
    'sha256', v_row.sha256
  );
end;
$$;

comment on function public.log_upload_opened(uuid) is
  'Admin: logs the opening of an uploaded file (admin_actions audit.open_upload) and returns its storage path.';
create function public.log_audit_export(
  p_tab text,
  p_format text,
  p_filter jsonb,
  p_row_count integer,
  p_file_name text,
  p_sha256 text
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_id uuid;
begin
  if not public.is_admin() then
    raise exception 'Only an Administrator can do this' using errcode = '42501';
  end if;
  if p_tab is null or p_tab not in ('logins', 'prompts', 'uploads', 'exports', 'blocked', 'admin_actions',
                                    'deletions', 'full_export') then
    raise exception 'Unknown audit tab' using errcode = '22023';
  end if;
  if p_format is null or p_format not in ('xlsx', 'pdf', 'csv', 'json') then
    raise exception 'Unknown export format' using errcode = '22023';
  end if;
  if (p_tab = 'full_export') <> (p_format = 'json') then
    raise exception 'This format does not belong to this export' using errcode = '22023';
  end if;
  if p_filter is null or jsonb_typeof(p_filter) <> 'object' or octet_length(p_filter::text) > 4096 then
    raise exception 'The filter must be a JSON object of at most 4 KB' using errcode = '22023';
  end if;
  if p_row_count is null or p_row_count < 0 then
    raise exception 'Invalid row count' using errcode = '22023';
  end if;
  if p_file_name is null or char_length(p_file_name) not between 1 and 255
     or p_file_name ~ '[\\/:*?"<>|[:cntrl:]]' then
    raise exception 'Invalid file name' using errcode = '22023';
  end if;
  if p_sha256 is null or p_sha256 !~ '^[0-9a-f]{64}$' then
    raise exception 'Invalid SHA-256' using errcode = '22023';
  end if;

  insert into public.admin_actions (admin_id, action, target_type, target_id, details)
  values (auth.uid(), 'audit.export', 'audit', p_tab,
          jsonb_build_object('tab', p_tab, 'format', p_format, 'filter', p_filter, 'rowCount', p_row_count,
                             'fileName', p_file_name, 'sha256', p_sha256))
  returning id into v_id;
  return v_id;
end;
$$;

comment on function public.log_audit_export(text, text, jsonb, integer, text, text) is
  'Admin: records a saved audit export / full data export in admin_actions (audit.export).';
create function private.purge_preview(p_table text, p_filter jsonb)
returns jsonb
language plpgsql
stable
set search_path = ''
as $$
declare
  v_pred text;
  v_hold text;
  v_matching bigint;
  v_held bigint;
begin
  if p_table is null or not (p_table = any (private.purgeable_tables())) then
    raise exception 'Records of % cannot be deleted', coalesce(p_table, 'this table') using errcode = '42501';
  end if;
  v_pred := private.purge_predicate(p_table, p_filter, false);
  v_hold := private.legal_hold_predicate(p_table);
  execute format(
    'select count(*), count(*) filter (where coalesce((%s), false)) from public.%I where %s',
    v_hold, p_table, v_pred)
  into v_matching, v_held;
  return jsonb_build_object('matching', v_matching, 'held', v_held);
end;
$$;
create function private.retention_purge()
returns jsonb
language plpgsql
set search_path = ''
as $$
declare
  v_days integer;
  v_filter jsonb;
  v_reason text;
  v_table text;
  v_due boolean;
  v_out jsonb := '[]'::jsonb;
begin
  select s.log_retention_days into v_days from public.tenant_settings s;
  if v_days is null then
    return v_out;
  end if;
  v_filter := jsonb_build_object('before', now() - make_interval(days => v_days));
  v_reason := format('Log retention period ended (%s days)', v_days);

  foreach v_table in array array['export_log', 'prompt_log', 'upload_log', 'login_events', 'usage_daily',
                                 'notifications'] loop
    execute format(
      'select exists (select 1 from public.%I where (%s) and not coalesce((%s), false))',
      v_table, private.purge_predicate(v_table, v_filter, false), private.legal_hold_predicate(v_table))
    into v_due;
    if v_due then
      v_out := v_out || jsonb_build_array(public.admin_purge(v_table, v_filter, v_reason, null));
    end if;
  end loop;
  return v_out;
end;
$$;
create function private.orphan_upload_objects(p_limit integer default 1000)
returns table (object_name text, owner_id uuid)
language plpgsql
stable
set search_path = ''
as $$
declare
  v_hold text := private.legal_hold_predicate('upload_log');
begin
  if p_limit is null or p_limit not between 1 and 10000 then
    raise exception 'Invalid limit' using errcode = '22023';
  end if;
  return query execute format(
    $q$
    select x.object_name, x.user_id
    from (
      select o.name::text as object_name,
             null::uuid as id,
             c.user_id,
             p.domain_id,
             o.created_at
      from storage.objects o
      cross join lateral (
        select case when split_part(o.name, '/', 1)
                         ~ '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
                    then split_part(o.name, '/', 1)::uuid end as user_id
      ) c
      left join public.profiles p on p.id = c.user_id
      where o.bucket_id = 'uploads'
        and o.created_at < now() - interval '1 day'
        and not exists (select 1 from public.upload_log ul where ul.storage_path = o.name)
    ) x
    where not coalesce((%s), false)
    order by x.created_at, x.object_name
    limit %s
    $q$,
    v_hold, p_limit);
end;
$$;

comment on function private.orphan_upload_objects(integer) is
  'purge: uploads-bucket objects older than a day without an upload_log row, not under a legal hold.';
create function private.protect_legal_hold()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  if tg_op = 'DELETE' then
    raise exception 'Legal holds are never deleted; release them with a reason' using errcode = '42501';
  end if;
  if tg_op = 'INSERT' then
    if new.released_at is not null or new.released_by is not null or new.release_reason is not null then
      raise exception 'A new legal hold cannot be released already' using errcode = '22023';
    end if;
    new.created_at := now();
    return new;
  end if;
  if old.released_at is not null then
    raise exception 'This legal hold was already released' using errcode = '42501';
  end if;
  if new.id is distinct from old.id or new.filter is distinct from old.filter
     or new.reason is distinct from old.reason or new.created_by is distinct from old.created_by
     or new.created_at is distinct from old.created_at or new.released_at is null then
    raise exception 'Only the release of a legal hold can be recorded' using errcode = '42501';
  end if;
  new.released_at := now();
  return new;
end;
$$;

comment on function private.protect_legal_hold() is
  'legal_holds: never deleted, never edited; released once with a reason (server time).';

create trigger legal_holds_protect
  before insert or update or delete on public.legal_holds
  for each row execute function private.protect_legal_hold();

create trigger legal_holds_no_truncate
  before truncate on public.legal_holds
  for each statement execute function private.log_guard_truncate();
revoke execute on function private.notify_once(text, text, text, text, text, interval) from public, anon, authenticated, service_role;
revoke execute on function private.notify_failed_login_burst() from public, anon, authenticated, service_role;
revoke execute on function private.notify_blocked_burst() from public, anon, authenticated, service_role;
revoke execute on function private.notify_new_app_version() from public, anon, authenticated, service_role;
revoke execute on function public.log_session_end(text) from public, anon, authenticated, service_role;
revoke execute on function public.report_seat_warning(text, timestamptz) from public, anon, authenticated, service_role;
revoke execute on function public.log_upload_opened(uuid) from public, anon, authenticated, service_role;
revoke execute on function public.log_audit_export(text, text, jsonb, integer, text, text) from public, anon, authenticated, service_role;
revoke execute on function private.purge_preview(text, jsonb) from public, anon, authenticated, service_role;
revoke execute on function private.retention_purge() from public, anon, authenticated, service_role;
revoke execute on function private.orphan_upload_objects(integer) from public, anon, authenticated, service_role;
revoke execute on function private.protect_legal_hold() from public, anon, authenticated, service_role;

grant execute on function public.log_session_end(text) to authenticated;
grant execute on function public.report_seat_warning(text, timestamptz) to authenticated;
grant execute on function public.log_upload_opened(uuid) to authenticated;
grant execute on function public.log_audit_export(text, text, jsonb, integer, text, text) to authenticated;
grant execute on function private.notify_once(text, text, text, text, text, interval) to service_role;
grant execute on function private.purge_preview(text, jsonb) to service_role;
grant execute on function private.retention_purge() to service_role;
grant execute on function private.orphan_upload_objects(integer) to service_role;
grant execute on function private.legal_hold_predicate(text) to service_role;
