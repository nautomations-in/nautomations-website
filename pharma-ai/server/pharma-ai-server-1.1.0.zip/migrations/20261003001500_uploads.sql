create table private.upload_tickets (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles (id) on delete cascade,
  device_id text not null check (device_id ~ '^[0-9a-f]{32}$'),
  token_sha256 text not null unique check (token_sha256 ~ '^[0-9a-f]{64}$'),
  created_at timestamptz not null default now(),
  expires_at timestamptz not null default (now() + interval '5 minutes'),
  used_at timestamptz,
  prepared_at timestamptz,
  upload_id uuid unique,
  storage_path text unique check (storage_path is null or char_length(storage_path) between 1 and 1024),
  file_name text check (file_name is null or char_length(file_name) between 1 and 255),
  mime_type text check (mime_type is null or char_length(mime_type) between 1 and 200),
  size_bytes bigint check (size_bytes is null or size_bytes > 0),
  sha256 text check (sha256 is null or sha256 ~ '^[0-9a-f]{64}$'),
  constraint upload_tickets_expiry_check
    check (expires_at > created_at and expires_at <= created_at + interval '5 minutes'),
  constraint upload_tickets_prepared_check check (
    (prepared_at is null and upload_id is null and storage_path is null and file_name is null
      and mime_type is null and size_bytes is null and sha256 is null)
    or (prepared_at is not null and upload_id is not null and storage_path is not null and file_name is not null
      and mime_type is not null and size_bytes is not null and sha256 is not null)
  ),
  constraint upload_tickets_used_check check (used_at is null or prepared_at is not null)
);

comment on table private.upload_tickets is
  'Level-2 upload tokens (CONTRACTS 16 / 17): SHA-256 only, 5 minutes, one upload, bound to user and PC. '
  'Edge Functions only; removed after one day by private.cleanup_expired().';
create index upload_tickets_user_created_idx on private.upload_tickets (user_id, created_at desc);
create index upload_tickets_created_at_idx on private.upload_tickets (created_at);

alter table private.upload_tickets enable row level security;
revoke all on table private.upload_tickets from public, anon, authenticated;
grant select, insert, update, delete on table private.upload_tickets to service_role;
create function private.upload_ticket_create(p_user_id uuid, p_device_id text, p_token_sha256 text)
returns timestamptz
language plpgsql
set search_path = ''
as $$
declare
  v_expires timestamptz;
begin
  insert into private.upload_tickets (user_id, device_id, token_sha256)
  values (p_user_id, p_device_id, p_token_sha256)
  returning expires_at into v_expires;
  return v_expires;
end;
$$;
create function private.upload_ticket_check(p_token_sha256 text, p_user_id uuid, p_device_id text)
returns jsonb
language sql
stable
set search_path = ''
as $$
  select jsonb_build_object(
    'id', t.id,
    'expires_at', extract(epoch from t.expires_at)::bigint,
    'prepared', t.prepared_at is not null,
    'upload_id', t.upload_id,
    'storage_path', t.storage_path,
    'file_name', t.file_name,
    'mime_type', t.mime_type,
    'size_bytes', t.size_bytes,
    'sha256', t.sha256
  )
  from private.upload_tickets t
  where t.token_sha256 = p_token_sha256
    and t.user_id = p_user_id
    and t.device_id = p_device_id
    and t.used_at is null
    and t.expires_at > now();
$$;
create function private.upload_ticket_prepare(
  p_token_sha256 text,
  p_user_id uuid,
  p_device_id text,
  p_upload_id uuid,
  p_storage_path text,
  p_file_name text,
  p_mime_type text,
  p_size_bytes bigint,
  p_sha256 text
)
returns boolean
language plpgsql
set search_path = ''
as $$
begin
  update private.upload_tickets t
  set prepared_at = now(), upload_id = p_upload_id, storage_path = p_storage_path, file_name = p_file_name,
      mime_type = p_mime_type, size_bytes = p_size_bytes, sha256 = p_sha256
  where t.token_sha256 = p_token_sha256
    and t.user_id = p_user_id
    and t.device_id = p_device_id
    and t.used_at is null
    and t.prepared_at is null
    and t.expires_at > now();
  return found;
end;
$$;
create function private.upload_ticket_consume(
  p_token_sha256 text,
  p_user_id uuid,
  p_device_id text,
  p_upload_id uuid
)
returns boolean
language plpgsql
set search_path = ''
as $$
begin
  update private.upload_tickets t
  set used_at = now()
  where t.token_sha256 = p_token_sha256
    and t.user_id = p_user_id
    and t.device_id = p_device_id
    and t.upload_id = p_upload_id
    and t.prepared_at is not null
    and t.used_at is null;
  return found;
end;
$$;

comment on function private.upload_ticket_create(uuid, text, text) is
  'verify-level2: stores a new upload ticket (token SHA-256 only), valid 5 minutes. Edge Functions only.';
comment on function private.upload_ticket_check(text, uuid, text) is
  'register-upload: the usable ticket of a token for this user and PC, or NULL. Edge Functions only.';
comment on function private.upload_ticket_prepare(text, uuid, text, uuid, text, text, text, bigint, text) is
  'register-upload prepare: records the file facts once on a usable ticket. Edge Functions only.';
comment on function private.upload_ticket_consume(text, uuid, text, uuid) is
  'register-upload confirm: marks a prepared ticket used (first call only). Edge Functions only.';

revoke execute on function private.upload_ticket_create(uuid, text, text) from public, anon, authenticated, service_role;
revoke execute on function private.upload_ticket_check(text, uuid, text) from public, anon, authenticated, service_role;
revoke execute on function private.upload_ticket_prepare(text, uuid, text, uuid, text, text, text, bigint, text)
  from public, anon, authenticated, service_role;
revoke execute on function private.upload_ticket_consume(text, uuid, text, uuid) from public, anon, authenticated, service_role;
grant execute on function private.upload_ticket_create(uuid, text, text) to service_role;
grant execute on function private.upload_ticket_check(text, uuid, text) to service_role;
grant execute on function private.upload_ticket_prepare(text, uuid, text, uuid, text, text, text, bigint, text)
  to service_role;
grant execute on function private.upload_ticket_consume(text, uuid, text, uuid) to service_role;
do $$
declare
  v_name text;
begin
  for v_name in
    select c.conname
    from pg_constraint c
    where c.conrelid = 'public.login_events'::regclass
      and c.contype = 'c'
      and pg_get_constraintdef(c.oid) like '%recovery_used%'
  loop
    execute format('alter table public.login_events drop constraint %I', v_name);
  end loop;
end;
$$;
alter table public.login_events add constraint login_events_event_check check (event in (
  'success', 'fail', 'locked', 'refused', 'logout', 'timeout', 'forced_logout', 'recovery_used',
  'level2_ok', 'level2_fail', 'level2_locked', 'level2_success'
));
insert into public.notification_rules (type, label, enabled, locked)
values
  ('level2_used', 'Level-2 password used', true, true),
  ('level2_locked', 'Uploads locked after wrong Level-2 passwords', true, false)
on conflict (type) do nothing;
create or replace function private.cleanup_expired()
returns jsonb
language plpgsql
set search_path = ''
as $$
declare
  v_tickets integer;
  v_changes integer;
  v_uploads integer;
  v_nonces integer;
  v_rates integer;
  v_sessions integer;
  v_answers integer;
  v_hours integer;
begin
  delete from private.login_tickets t where t.created_at < now() - interval '1 day';
  get diagnostics v_tickets = row_count;
  delete from private.change_tickets t where t.created_at < now() - interval '1 day';
  get diagnostics v_changes = row_count;
  delete from private.upload_tickets t where t.created_at < now() - interval '1 day';
  get diagnostics v_uploads = row_count;
  delete from private.used_nonces n where n.created_at < now() - interval '1 hour';
  get diagnostics v_nonces = row_count;
  delete from private.rate_limits r where r.window_start < now() - interval '1 day';
  get diagnostics v_rates = row_count;
  select s.session_max_hours + 12 into v_hours from public.tenant_settings s;
  delete from private.session_devices d
  where d.created_at < now() - make_interval(hours => coalesce(v_hours, 24));
  get diagnostics v_sessions = row_count;

  delete from public.answer_store a where a.expires_at < now();
  get diagnostics v_answers = row_count;
  if v_answers > 0 then
    insert into public.deletion_log (admin_id, table_name, filter, record_count, reason)
    values (null, 'answer_store', jsonb_build_object('expired_before', now()), v_answers,
            'Answer retention period ended');
  end if;

  return jsonb_build_object(
    'login_tickets', v_tickets, 'change_tickets', v_changes, 'upload_tickets', v_uploads,
    'used_nonces', v_nonces, 'rate_limits', v_rates, 'session_devices', v_sessions, 'answer_store', v_answers
  );
end;
$$;

revoke execute on function private.cleanup_expired() from public, anon, authenticated, service_role;
grant execute on function private.cleanup_expired() to service_role;
