create function public.custom_access_token_hook(event jsonb)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_refused constant jsonb := jsonb_build_object(
    'error', jsonb_build_object('http_code', 400, 'message', 'Invalid login credentials'));
  v_claims jsonb := coalesce(event -> 'claims', '{}'::jsonb);
  v_method text := event ->> 'authentication_method';
  v_user uuid;
  v_session uuid;
  v_role text;
  v_device text;
  v_bound text;
begin
  begin
    v_user := (event ->> 'user_id')::uuid;
    v_session := (v_claims ->> 'session_id')::uuid;
  exception when others then
    return v_refused;
  end;
  if v_user is null or v_session is null then
    return v_refused;
  end if;

  select p.role into v_role from public.profiles p where p.id = v_user and p.status = 'active';
  if v_role is null then
    return v_refused;
  end if;

  if v_method = 'password' then
    update private.login_tickets t
    set used_at = now()
    where t.id = (
      select lt.id
      from private.login_tickets lt
      where lt.user_id = v_user
        and lt.used_at is null
        and lt.expires_at > now()
        and lt.created_at > now() - interval '60 seconds'
      order by lt.created_at desc
      limit 1
      for update skip locked
    )
    returning t.device_id into v_device;

    if v_device is null then
      return v_refused;
    end if;

    insert into private.session_devices (session_id, user_id, device_id)
    values (v_session, v_user, v_device)
    on conflict (session_id) do nothing;

    select d.device_id into v_bound
    from private.session_devices d
    where d.session_id = v_session and d.user_id = v_user;
    if v_bound is distinct from v_device then
      return v_refused;
    end if;
  else
    select d.device_id into v_device
    from private.session_devices d
    where d.session_id = v_session and d.user_id = v_user;
    if v_device is null then
      return v_refused;
    end if;
  end if;

  v_claims := v_claims || jsonb_build_object('device_id', v_device, 'app_role', v_role);
  return jsonb_set(event, '{claims}', v_claims);
end;
$$;
create function private.consume_change_ticket(p_user_id uuid, p_kind text)
returns void
language plpgsql
set search_path = ''
as $$
declare
  v_id uuid;
begin
  update private.change_tickets t
  set used_at = now()
  where t.id = (
    select ct.id
    from private.change_tickets ct
    where ct.user_id = p_user_id
      and ct.kind = p_kind
      and ct.used_at is null
      and ct.expires_at > now()
      and ct.created_at > now() - interval '60 seconds'
    order by ct.created_at desc
    limit 1
    for update skip locked
  )
  returning t.id into v_id;

  if v_id is null then
    raise exception 'Passwords and e-mail addresses are changed only by the Administrator'
      using errcode = '42501';
  end if;
end;
$$;
create function private.guard_auth_user_change()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if new.encrypted_password is distinct from old.encrypted_password then
    perform private.consume_change_ticket(new.id, 'password');
  end if;
  if new.email is distinct from old.email then
    perform private.consume_change_ticket(new.id, 'email');
  end if;
  return new;
end;
$$;

create trigger pharmaai_guard_user_change
  before update on auth.users
  for each row execute function private.guard_auth_user_change();
revoke execute on function public.custom_access_token_hook(jsonb) from public, anon, authenticated, service_role;
grant execute on function public.custom_access_token_hook(jsonb) to supabase_auth_admin;

revoke execute on function private.consume_change_ticket(uuid, text) from public, anon, authenticated, service_role;
revoke execute on function private.guard_auth_user_change() from public, anon, authenticated, service_role;
grant usage on schema public to supabase_auth_admin;
grant usage on schema private to supabase_auth_admin;
grant select, insert, update on private.login_tickets to supabase_auth_admin;
grant select, insert, update on private.session_devices to supabase_auth_admin;
revoke all on public.profiles from supabase_auth_admin;
grant select on public.profiles to supabase_auth_admin;

create policy login_tickets_select_auth_admin on private.login_tickets
  for select to supabase_auth_admin using (true);
create policy login_tickets_update_auth_admin on private.login_tickets
  for update to supabase_auth_admin using (true) with check (true);
create policy login_tickets_insert_auth_admin on private.login_tickets
  for insert to supabase_auth_admin with check (true);
create policy session_devices_select_auth_admin on private.session_devices
  for select to supabase_auth_admin using (true);
create policy session_devices_update_auth_admin on private.session_devices
  for update to supabase_auth_admin using (true) with check (true);
create policy session_devices_insert_auth_admin on private.session_devices
  for insert to supabase_auth_admin with check (true);
create policy profiles_select_auth_admin on public.profiles
  for select to supabase_auth_admin using (true);
