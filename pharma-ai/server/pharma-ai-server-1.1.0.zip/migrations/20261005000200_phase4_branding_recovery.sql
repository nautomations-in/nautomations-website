alter table public.branding
  add column logo_seq integer not null default 0,
  add column previous jsonb,
  add constraint branding_logo_seq_check check (logo_seq >= 0 and logo_seq >= logo_version),
  add constraint branding_previous_check check (previous is null or jsonb_typeof(previous) = 'object');

comment on column public.branding.logo_seq is
  'Highest logo version reserved by admin-settings prepareLogoUpload (branding/logo-v{n}.png).';
comment on column public.branding.previous is
  'Branding before the last applyBranding: {companyName, appDisplayName, logoVersion, logoPath}; used by revertBranding.';
create function private.break_glass_check(p_witness_1 text, p_witness_2 text, p_reference text)
returns void
language plpgsql
immutable
set search_path = ''
as $$
declare
  v_value text;
begin
  foreach v_value in array array[coalesce(p_witness_1, ''), coalesce(p_witness_2, ''), coalesce(p_reference, '')] loop
    if char_length(btrim(v_value)) not between 3 and 80 or v_value ~ '[[:cntrl:]]' then
      raise exception 'Two witness names and a reference of 3 to 80 characters each are required'
        using errcode = '22023';
    end if;
  end loop;
  if lower(btrim(p_witness_1)) = lower(btrim(p_witness_2)) then
    raise exception 'The two witnesses must be two different people' using errcode = '22023';
  end if;
end;
$$;
create function private.break_glass_reset_admin(
  p_username text,
  p_new_password text,
  p_witness_1 text,
  p_witness_2 text,
  p_reference text
)
returns jsonb
language plpgsql
set search_path = ''
as $$
declare
  v_profile public.profiles%rowtype;
  v_factors integer;
begin
  perform private.break_glass_check(p_witness_1, p_witness_2, p_reference);
  if p_new_password is null or char_length(p_new_password) not between 10 and 72
     or p_new_password !~ '[A-Za-z]' or p_new_password !~ '[0-9]' then
    raise exception 'The new password needs 10 to 72 characters with letters and numbers' using errcode = '22023';
  end if;

  select * into v_profile from public.profiles p where lower(p.username) = lower(btrim(coalesce(p_username, '')));
  if not found or v_profile.role not in ('admin', 'backup_admin') then
    raise exception 'No Admin or Backup Admin account has this username' using errcode = '22023';
  end if;
  if exists (select 1 from private.level2_secrets s
             where s.user_id = v_profile.id and extensions.crypt(p_new_password, s.hash) = s.hash) then
    raise exception 'The new password must be different from the Level-2 password' using errcode = '22023';
  end if;
  perform private.create_change_ticket(v_profile.id, 'password', null);
  update auth.users u
  set encrypted_password = extensions.crypt(p_new_password, extensions.gen_salt('bf', 10)),
      banned_until = null,
      updated_at = now()
  where u.id = v_profile.id;
  if not found then
    raise exception 'The Auth user of this account is missing' using errcode = 'P0002';
  end if;

  update public.profiles p set status = 'active', failed_logins = 0 where p.id = v_profile.id;
  delete from auth.sessions s where s.user_id = v_profile.id;
  delete from private.session_devices d where d.user_id = v_profile.id;
  delete from auth.mfa_factors f where f.user_id = v_profile.id;
  get diagnostics v_factors = row_count;

  insert into public.admin_actions (admin_id, action, target_type, target_id, details, reason)
  values (null, 'break_glass.reset_admin', 'user', v_profile.id::text,
          jsonb_build_object('username', v_profile.username, 'previousStatus', v_profile.status,
                             'mfaFactorsRemoved', v_factors,
                             'witness1', btrim(p_witness_1), 'witness2', btrim(p_witness_2),
                             'reference', btrim(p_reference)),
          'Break-glass recovery');
  perform private.notify(
    'break_glass', 'Break-glass recovery used',
    format('The password of %s was reset by the backend owner (reference %s; witnesses %s and %s).',
           v_profile.username, btrim(p_reference), btrim(p_witness_1), btrim(p_witness_2)),
    'profiles', v_profile.id::text);

  return jsonb_build_object('ok', true, 'userId', v_profile.id, 'username', v_profile.username,
                            'role', v_profile.role, 'mfaFactorsRemoved', v_factors);
end;
$$;
create function private.break_glass_create_admin(
  p_username text,
  p_display_name text,
  p_witness_1 text,
  p_witness_2 text,
  p_reference text
)
returns jsonb
language plpgsql
set search_path = ''
as $$
declare
  v_username text := lower(btrim(coalesce(p_username, '')));
  v_display text := btrim(coalesce(p_display_name, ''));
  v_slug text := (select s.client_slug from public.tenant_settings s);
  v_email text;
  v_user uuid;
begin
  perform private.break_glass_check(p_witness_1, p_witness_2, p_reference);
  if v_username !~ '^[a-z0-9][a-z0-9._-]{2,31}$' then
    raise exception 'The username needs 3 to 32 characters: a-z, 0-9, dot, dash or underscore' using errcode = '22023';
  end if;
  if char_length(v_display) not between 1 and 80 or v_display ~ '[[:cntrl:]]' then
    raise exception 'The display name needs 1 to 80 characters on one line' using errcode = '22023';
  end if;

  v_email := v_username || '@' || v_slug || '.pharmaai.local';
  select u.id into v_user from auth.users u where lower(u.email) = v_email;
  if v_user is null then
    raise exception 'Create the Auth user % in the dashboard first', v_email using errcode = 'P0002';
  end if;
  if exists (select 1 from public.profiles p where p.id = v_user) then
    raise exception 'This account already has a profile; use break_glass_reset_admin' using errcode = '22023';
  end if;
  if exists (select 1 from public.profiles p where lower(p.username) = v_username) then
    raise exception 'This username is already in use' using errcode = '22023';
  end if;

  insert into public.profiles (id, username, display_name, role, domain_id, status)
  values (v_user, v_username, v_display, 'admin', null, 'active');

  insert into public.admin_actions (admin_id, action, target_type, target_id, details, reason)
  values (null, 'break_glass.create_admin', 'user', v_user::text,
          jsonb_build_object('username', v_username, 'witness1', btrim(p_witness_1),
                             'witness2', btrim(p_witness_2), 'reference', btrim(p_reference)),
          'Break-glass recovery');
  perform private.notify(
    'break_glass', 'Break-glass recovery used',
    format('The Admin account %s was created by the backend owner (reference %s; witnesses %s and %s).',
           v_username, btrim(p_reference), btrim(p_witness_1), btrim(p_witness_2)),
    'profiles', v_user::text);

  return jsonb_build_object('ok', true, 'userId', v_user, 'username', v_username, 'role', 'admin');
end;
$$;

comment on function private.break_glass_reset_admin(text, text, text, text, text) is
  'Break-glass (REC-03): reset an Admin / Backup Admin password with two witnesses. SQL editor (postgres) only.';
comment on function private.break_glass_create_admin(text, text, text, text, text) is
  'Break-glass (REC-03): give a dashboard-created Auth user the Admin role with two witnesses. SQL editor only.';
create function private.recovery_code_redeem(p_user_id uuid, p_code text)
returns jsonb
language plpgsql
set search_path = ''
as $$
declare
  v_code text := private.normalise_recovery_code(p_code);
  v_row record;
  v_same boolean;
  v_match uuid;
  v_done integer := 0;
  v_left integer := 0;
begin
  for v_row in
    select r.id, r.code_hash, r.used_at
    from private.recovery_codes r
    where p_user_id is not null and r.user_id = p_user_id
    order by r.created_at, r.id
    for update
  loop
    v_done := v_done + 1;
    v_same := extensions.crypt(v_code, v_row.code_hash) = v_row.code_hash;
    if v_same and v_row.used_at is null and v_match is null then
      v_match := v_row.id;
    end if;
  end loop;
  while v_done < 10 loop
    perform extensions.crypt(v_code, extensions.gen_salt('bf', 10));
    v_done := v_done + 1;
  end loop;

  if v_match is not null then
    update private.recovery_codes r set used_at = now() where r.id = v_match;
  end if;
  if p_user_id is not null then
    select count(*)::int into v_left from private.recovery_codes r where r.user_id = p_user_id and r.used_at is null;
  end if;
  return jsonb_build_object('ok', v_match is not null, 'codes_left', v_left);
end;
$$;

comment on function private.recovery_code_redeem(uuid, text) is
  'admin-recovery: uses up one recovery code with constant bcrypt work; {ok, codes_left}. Edge Functions only.';
revoke execute on function private.break_glass_check(text, text, text) from public, anon, authenticated, service_role;
revoke execute on function private.break_glass_reset_admin(text, text, text, text, text) from public, anon, authenticated, service_role;
revoke execute on function private.break_glass_create_admin(text, text, text, text, text) from public, anon, authenticated, service_role;

revoke execute on function private.recovery_code_redeem(uuid, text) from public, anon, authenticated, service_role;
grant execute on function private.recovery_code_redeem(uuid, text) to service_role;
